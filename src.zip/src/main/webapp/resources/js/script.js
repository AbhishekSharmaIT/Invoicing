$(document).ready(function () {
    console.log("ready!");

//   client dropdown on change fires a ajax call to server to return client purchases order
//   and populate purchase order dropdown fields

    $('#client').on('change', function () {
        var selectedValue = this.selectedOptions[0].value;
        var selectedText = this.selectedOptions[0].text;
        //console.log("Seleced Option: " +selectedText+" Seleced Option value: "+selectedValue);

        if (selectedValue === "0") {
            console.log("inside if.");
            $('#client').removeClass("is-invalid is-vaild").addClass("is-invalid");
             $('input[type=submit]').attr('disabled', 'disabled');
        } else {
            console.log("Seleced Option: " + selectedText + " Seleced Option value: " + selectedValue);
            $('#client').removeClass("is-invalid is-valid").addClass("is-vaild");
            $('input[type=submit]').removeAttr("disabled");
            // ajax call start here
            $.ajax({
                type: "GET",
                url: "getClientPurchaseOrder",
                data: {
                    "clientId": selectedValue
                },
                success: function (data) {
                    console.log("response comes " + data);

                    // json data is retrun 
                     //var json = JSON.parse(data);
                     var json = JSON.parse(JSON.stringify(data))
                     console.log(json);
                    //var json = $.parseJSON(data);
                    //now json variable contains the cliect purchase orders data in json format
                    //let's display a few items

                    let dropdown = $('#purchase-order');

                    dropdown.empty();

                    //dropdown.append('<option selected="true" disabled>Select Purchase order</option>');
                     dropdown.append('<option selected="true" value="0">Select Purchase order</option>');
                    dropdown.prop('selectedIndex', 0);

                    // populating the purchase order dropdown
                    $.each(json.purchaseOrders, function (key, entry) {
                        dropdown.append($('<option></option>').attr('value', entry.id).text(entry.title));
                    });
                    
                    $('#sub-total-div').empty();
                    $.each(json.tax, function (key, entry) {
                       
                        $('#sub-total-div').append(`<div class="row">
                            <div class="col-4">
                                <label for="${entry.name}">${entry.name}(${entry.rate})</label>
                            </div>
                            <div class="col-8">
                            <input type="hidden" name="taxItems[${key}].tax.id" value="${entry.id}" />
                                <input type="number" name="taxItems[${key}].amount" class="form-control form-control-sm text-right tax"
                                       value="0.00" rate="${entry.rate}" readonly/>
                            </div>
                        </div>`);
                    });


                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("response textStatus " + textStatus);
                    console.log("response jqXHR " + jqXHR);
                    console.log("response errorThrown " + errorThrown);
                }
            });
        }

    });

    $('#purchase-order').on('change', function () {
        var selectedValue = this.selectedOptions[0].value;
        var selectedText = this.selectedOptions[0].text;
        //console.log("Seleced Option: " +selectedText+" Seleced Option value: "+selectedValue);

        if (selectedValue === "0") {
            console.log("inside if.");
            $('#purchase-order').removeClass("is-invalid is-vaild").addClass("is-invalid");
             $('input[type=submit]').attr('disabled', 'disabled');
        } else {
            console.log("Seleced Option: " + selectedText + " Seleced Option value: " + selectedValue);
            $('#purchase-order').removeClass("is-invalid is-valid").addClass("is-vaild");
            $('input[type=submit]').removeAttr("disabled");
            // ajax call start here
            $.ajax({
                type: "GET",
                url: "getClientPurchaseOrderItems",
                data: {
                    "purchaseOrderId": selectedValue
                },
                success: function (data) {
                    console.log("response comes " + data);

                    // json data is retrun 
                    //var json = $.parseJSON(data);
                    var json = JSON.parse(JSON.stringify(data));
                     console.log(json);
                    //now json variable contains the purchase orders with appropiate ClientPOItems data in json format

                    console.log(json.advancePaid);
                    console.log(json.balanceDue);
                    console.log(json.deliveryDate);
                    var javadateTime = new Date(json.deliveryDate);
                   
                    var day = ("0" + javadateTime.getDate()).slice(-2);
                    var month = ("0" + (javadateTime.getMonth() + 1)).slice(-2);

                    var dueDate = javadateTime.getFullYear() + "-" + (month) + "-" + (day);



                    $('#invoice-due-date').val(dueDate);
                    //$('#invoice-advance-paid').val(json.advancePaid);
                    //$('#invoice-balance-due').val(json.balanceDue);
                    //alert(str);

                    //let dropdown = $('#purchase-order-item');
                    let dropdown = $('.dm');
                    dropdown.empty();

                    //dropdown.append('<option selected="true" disabled>Select Purchase Order Items</option>');
                     dropdown.append('<option selected="true" value="0">Select Purchase Order Items</option>');
                    
                    dropdown.prop('selectedIndex', 0);

                    // populating the purchase order dropdown
                    $.each(json.clientPurchaseOrderItem, function (key, entry) {
                        console.log(entry);
                        console.log(entry.id);
                        console.log(entry.name);
                        dropdown.append($('<option></option>').attr('value', entry.id).text(entry.name));
                    });


                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("response textStatus " + textStatus);
                    console.log("response jqXHR " + jqXHR);
                    console.log("response errorThrown " + errorThrown);
                }
            });
        }

    });



       //#purchase-order-item
    $(document).on("change", ".dm", function (e) {
        console.log($(this).attr("id"));
         console.log($(this).parent().parent().children());
         var elements = $(this).parent().parent().children();
         console.log(elements[0].children[0]);
         var quantity = elements[0].children[0];
         var item = elements[1].children[2];
         var description = elements[2].children[0];
         var amount = elements[4].children[0];
         
         
         console.log(elements[1].children[1]);
         
         
        var selectedValue = this.selectedOptions[0].value;
        var selectedText = this.selectedOptions[0].text;
        //console.log("Seleced Option: " +selectedText+" Seleced Option value: "+selectedValue);

        if (selectedValue === "0") {
            console.log("inside if.");
            $(this).removeClass("is-invalid is-vaild").addClass("is-invalid");
            $('input[type=submit]').attr('disabled', 'disabled');
        } else {
            console.log("Seleced Option: " + selectedText + " Seleced Option value: " + selectedValue);
            $(this).removeClass("is-invalid is-valid").addClass("is-vaild");
            $('input[type=submit]').removeAttr("disabled");

            // ajax call start here
            $.ajax({
                type: "GET",
                url: "getClientPurchaseOrderItem",
                data: {
                    "ClientPurchaseOrderItemId": selectedValue
                },
                success: function (data) {
                    console.log("response comes " + data);

         
                    //json data is retrun 
                    //var json = $.parseJSON(data);
                    var json = JSON.parse(JSON.stringify(data));
                     console.log(json);
                    //now json variable contains the cliect purchase orders data in json format
                    //let's display a few items

                    console.log(json.description);
                   // $('#invoice-item-description').val(json.description);
                    description.value = json.description;
                    
                    console.log(json.amount);
                   // $('#invoice-item-amount').val(json.amount);
                     amount.value = json.amount;

                    console.log(json.quantity);
                  //  $('#invoice-item-quantity').val(json.quantity);
                     quantity.value = json.qty;
                    console.log(json.name);
                  //  $('#invoice-item-name').val(json.description);
                     item.value = json.name;
                     
                     calculateSubTotal();
                     calculateTaxRate();
                     calculateGrandTotal();
                     calculateAmountReceived();

                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("response textStatus " + textStatus);
                    console.log("response jqXHR " + jqXHR);
                    console.log("response errorThrown " + errorThrown);
                }
            });
        }

    });
     //$( "#invoice-item-amount" ).keyup(function()
    $(document).on("keyup", "#invoice-item-amount", function (){
	  console.log("inside amount:");
                     calculateSubTotal();
                     calculateTaxRate();
                     calculateGrandTotal();
                     calculateAmountReceived();
    });
    
    $('#currency').on('change', function () {
        var selectedValue = this.selectedOptions[0].value;
        var selectedText = this.selectedOptions[0].text;
        //console.log("Seleced Option: " +selectedText+" Seleced Option value: "+selectedValue);

        if (selectedValue === "0") {
            console.log("inside if.");
            $('#currency').removeClass("is-invalid is-vaild").addClass("is-invalid");
            $('input[type=submit]').attr('disabled', 'disabled');
        } else {
            console.log("Seleced Option: " + selectedText + " Seleced Option value: " + selectedValue);
            $('#currency').removeClass("is-invalid is-valid").addClass("is-vaild");
              $('input[type=submit]').removeAttr("disabled");
              }
       });
       
       $('#invoice-date').on('change', function () {
        var date = $(this).val();
        
         if (!validateDate(date)) {
			        console.log($('#invoice-date').val());
			        $(this).removeClass("is-invalid is-vaild").addClass("is-invalid");
                    $('input[type=submit]').attr('disabled', 'disabled');
			    }
			     else {
              $('#invoice-date').removeClass("is-invalid is-valid").addClass("is-vaild");
              $('input[type=submit]').removeAttr("disabled");
             }
       });
       
       $('#invoice-due-date').on('change', function () {
        var date = $(this).val();
        
         if (!validateDate(date)) {
			        console.log($('#invoice-date').val());
			        $(this).removeClass("is-invalid is-vaild").addClass("is-invalid");
                    $('input[type=submit]').attr('disabled', 'disabled');
			    }
			     else {
              $(this).removeClass("is-invalid is-valid").addClass("is-vaild");
              $('input[type=submit]').removeAttr("disabled");
             }
       });
       
       
       $('#invoice-advance-paid').blur(function() {
          calculateAmountReceived();
     });

    // set invoice date input to current date
    setInvoiceDate();

    addTableRow();
    
    $("#success-alert").fadeTo(2000, 500).slideUp(500, function(){
    $("#success-alert").slideUp(500);
    });
    
    $('[data-toggle="tooltip"]').tooltip();
    saveInvoice();
});

function saveInvoice(){
    $("#invoice-form").submit(function(e){
		    	console.log( "Inside invoice Form." );
		    	e.preventDefault();
		    	 var valid = true;  
		    	 console.log("printing purchase order "+$('#purchase-order').val()); 
		    	 console.log("printing purchase order items"+$('#purchase-order-item').val());
				if (valid && $('#client').val() == 0) {
			        console.log($('#client').val());
			        $('#client').removeClass("is-invalid is-vaild").addClass("is-invalid");
                    $('input[type=submit]').attr('disabled', 'disabled');
			        valid = false;
			    }
			    if (valid && ($('#purchase-order').val() == 0 || $('#purchase-order').val() == null)) {
			        console.log($('#purchase-order').val());
			        $('#purchase-order').removeClass("is-invalid is-vaild").addClass("is-invalid");
                    $('input[type=submit]').attr('disabled', 'disabled');
			        valid = false;
			    }
			    if (valid && !validateDate($('#invoice-date').val())) {
			        console.log($('#invoice-date').val());
			        $('#invoice-date').removeClass("is-invalid is-vaild").addClass("is-invalid");
                    $('input[type=submit]').attr('disabled', 'disabled');
			        valid = false;
			    }
			    if (valid && !validateDate($('#invoice-due-date').val())) {
			        console.log($('#invoice-due-date').val());
			        $('#invoice-date').removeClass("is-invalid is-vaild").addClass("is-invalid");
                    $('input[type=submit]').attr('disabled', 'disabled');
			        valid = false;
			    }
			    if (valid && $('#currency').val() == 0) {
			        console.log($('#currency').val());
			        $('#currency').removeClass("is-invalid is-vaild").addClass("is-invalid");
                    $('input[type=submit]').attr('disabled', 'disabled');
			        valid = false;
			    }
			    $.each($('.dm'),function (key,entry) {
			       if (valid && ($(this).val() == 0 || $(this).val() == null)) {
				        console.log($('#purchase-order-item').val());
				        $(this).removeClass("is-invalid is-vaild").addClass("is-invalid");
	                    $('input[type=submit]').attr('disabled', 'disabled');
				        valid = false;
			        }
   				 });
			    
			    if(valid){
			     console.log("form is valid");
			     $.ajax({
	                 url: 'save',
	                 type: 'POST',
	                 data:$(this).serialize(),
	                 success: function(data) {
	                     var json = JSON.parse(JSON.stringify(data))
	                     console.log(json);
	                     if(json.msg != null){
	                    	 console.log("inside if");
	                    	 $("#invoice-form").get(0).reset();
	                    	 $('#success-alert').addClass( "alert alert-info" ).css({
								    "opacity":"500",
								    "display":"block" 
								}).text(json.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('#success-alert').slideUp(500);
				                    $('#success-alert').removeClass( "alert alert-info" ).css({
								    "opacity":"0",
								    "display":"none" 
								}).empty();
			                       });
			                      
			                       window.listInvoice(window.getDataTable().clear());
			                       $("#myModal .close").click();
	                     }
	                 },error: function (jqXHR, textStatus, errorThrown) {
	                	 var json = JSON.parse(JSON.stringify(jqXHR))
	                     console.log(json);
	                     console.log("response textStatus " + textStatus);
	                     console.log("response jqXHR " + jqXHR);
	                     console.log("response errorThrown " + errorThrown);
	                 }
	             });
			    }else{
			    console.log("form is invalid");
			    }
	        });
}


/*function saveInvoice(){
    $("#invoice-form").submit(function(e){
		    	console.log( "Inside invoice Form." );
		    	e.preventDefault(); 

	            $.ajax({
	                 url: 'save',
	                 type: 'POST',
	                 data:$(this).serialize(),
	                 success: function(data) {
	                     var json = JSON.parse(JSON.stringify(data))
	                     console.log(json);
	                     if(json.msg != null){
	                    	 console.log("inside if");
	                    	 $("#invoice-form").get(0).reset();
	                    	 $('#success-alert').addClass( "alert alert-info" ).css({
								    "opacity":"500",
								    "display":"block" 
								}).text(json.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('#success-alert').slideUp(500);
			                       });
			                       $("#myModal .close").click();
			                       console.log($('#data-table'));
			                       window.listInvoice(window.getDataTable().clear());
	                     }
	                 },error: function (jqXHR, textStatus, errorThrown) {
	                	 var json = JSON.parse(JSON.stringify(jqXHR))
	                     console.log(json);
	                     console.log("response textStatus " + textStatus);
	                     console.log("response jqXHR " + jqXHR);
	                     console.log("response errorThrown " + errorThrown);
	                 }
	             })  
	        });
}*/

function validateDate(date){
   console.log("inside validation .");
   var dateFormat = new RegExp(/^([0-9]{2})-([0-9]{2})-([0-9]{4})$/);
   console.log("printing date "+date);
   date = date.split("-").reverse().join("-");
   console.log("printing reverse date "+date);
   if (dateFormat.test(date)) {
   console.log("inside validation if .");
            return true;
       }else{
       console.log("inside validation else.");
       return false;
  }
}

function calculateGrandTotal(){
    var totalTax = 0;
    $.each($('.tax'),function (key,entry) {
        console.log($(this).attr("rate"));
      console.log($(this).val());
                  totalTax =  totalTax + Number($(this).val());
                   
    });
    console.log("Total tax"+ totalTax);
    $('#grand-total').val(parseFloat($('#sub-total').val()) + totalTax);
    
}

function calculateTaxRate(){
    
    $.each($('.tax'),function (key,entry) {
        console.log($(this).attr("rate"));
       var rate = parseFloat($(this).attr("rate")) / 100;
       $(this).val(parseFloat($('#sub-total').val())*rate);
    });
    
}

function calculateSubTotal(){
    var amount=0;
     $.each($('.amount'), function (key, entry) {
         console.log(amount);
         console.log($(this).val());
                  amount =  amount + Number($(this).val());
                    });
                    
                $('#sub-total').val(amount);
}

function calculateAmountReceived(){
    
      var grandTotal = $('#grand-total').val();
      var advancePaid = $('#invoice-advance-paid').val();
      /*var balanceDue = $('#invoice-balance-due').val();
      console.log((parseInt(grandTotal) + parseInt(balanceDue)));
      var totalAmount = (parseInt(grandTotal) + parseInt(balanceDue));
      console.log((totalAmount - parseInt(advancePaid)));
      $('#amount-received').val(((parseInt(grandTotal) + parseInt(balanceDue)) - parseInt(advancePaid)));*/
    
    $('#invoice-balance-due').val(parseInt(grandTotal)-parseInt(advancePaid));
}

function setInvoiceDate() {
    var now = new Date();

    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear() + "-" + (month) + "-" + (day);


    $('#invoice-date').val(today);

}

function addTableRow() {
   var index = 0;
    $("#add-row").click(function () {
      var index = $('#invoice-item tr').length - 1;
      console.log("printing index :"+index);
         // index += 1;
        var select =  $('#purchase-order-item').clone();
            select.attr("name","invoiceItems["+index+"].clientPurchaseOrderItem.id");
            //select.removeAttr("disabled");
            console.log(select);
        console.log(select[0].outerHTML);
       
        $('#invoice-item tr:last').after(`<tr>
                            <td scope="row" class="align-middle">
                                <input id="invoice-item-quantity" name="invoiceItems[${index}].quantity" class="form-control form-control-sm" type="text" value="0">
                            </td>
                            <td>${select[0].outerHTML}<div class="invalid-feedback">Please select a purchase order item.</div>                  
                                <textarea id="invoice-item-name" name="invoiceItems[${index}].name" class="form-control" rows="2"></textarea>
                            </td>
                            <td class="align-middle">
                                <textarea id="invoice-item-description" name="invoiceItems[${index}].descrition" class="form-control" rows="2"></textarea>
                            </td>
                            <td class="align-middle">
                               <input id="invoiceItems0.part" name="invoiceItems[${index}].part" class="form-control form-control-sm" type="number" value="100">
                            </td>
                            <td class="align-middle">
                                <input id="invoice-item-amount" name="invoiceItems[${index}].amount" class="form-control form-control-sm amount" type="number" value="0.0">
                            </td>
                        </tr>`);
    });
}
