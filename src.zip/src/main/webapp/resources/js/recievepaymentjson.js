$(document).ready(function () {
    console.log("ready!");



    $('#client').on('change', function () {
        var selectedValue = this.selectedOptions[0].value;
        var selectedText = this.selectedOptions[0].text;
       

        if (selectedValue === "0") {
            console.log("inside if.");
           
        } else {
	
            console.log("Selected Option: " + selectedText + " Selected Option value: " + selectedValue);
       
            $.ajax({
                type: "GET",
                url: "/RecievePayment/getClientInvoiceNo",
                data: {
                    "clientId": selectedValue
                },
                success: function (data) {
                    console.log("response comes " + data);

                   
                     var json = JSON.parse(JSON.stringify(data))
                     console.log(json);
                    

                    let dropdown = $('#invoice');

                    dropdown.empty();

                    
                     dropdown.append('<option selected="true" value="0">Select Invoice</option>');
                    dropdown.prop('selectedIndex', 0);
                  
                   /* dropdown.append($('<option></option>').attr('value', json.id).text(json.invoiceNo));*/
                    $.each(json, function (key, entry) {
	                     
                        dropdown.append($('<option></option>').attr('value', entry.id).text(entry.invoiceNo));
                    });
                    
                   
                    


                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("response textStatus " + textStatus);
                    console.log("response jqXHR " + jqXHR);
                    console.log("response errorThrown " + errorThrown);
                }
            });
        }

    });
    
    $('#invoice').on('change', function () {
        var selectedValue = this.selectedOptions[0].value;
        var selectedText = this.selectedOptions[0].text;
        

        if (selectedValue === "0") {
            console.log("inside if.");
            
        } else {
	
            console.log("Selected Option: " + selectedText + " Selected Option value: " + selectedValue);
         
            $.ajax({
                type: "GET",
                url: "/RecievePayment/getInvoiceNo",
                data: {
                    "invoiceId": selectedValue
                },
                success: function (data) {
                    console.log("response comes " + data);

                    
                     var json = JSON.parse(JSON.stringify(data))
                     console.log(json);
                     
                      $('#amountReceived').val(json.subTotal);
                      $('#balanceDue').val(json.balanceDue);
                      $('#amountPaid').val(json.amountPaid);
                      $('#payableTotal').val(json.grandTotal);
                      
                       $("#payable").html('Payable Total('+json.currency+')');
                       $("#amount").html('Amount Paid('+json.currency+')');
                       $("#balance").html('Balance Due('+json.currency+')');
                        $("#recieved").html('Amount Recieved('+json.currency+')');
                        
                        
                         $('#amountPaid'). attr('readonly',true);
                          $('#balanceDue'). attr('readonly',true);
                           $('#payableTotal'). attr('readonly',true);
                        
                        /* $('#payableTotal'). attr('disabled',true);
                        it prevent data to store in database
                        */
                      /*  Using javascript*/
                        /*/* document.getElementById('payable').innerHTML = 'Payable Total('+json.currency+')';
	                     document.getElementById('amount').innerHTML ='Amount Paid('+json.currency+')';
	                     document.getElementById('balance').innerHTML ='Balance Due('+json.currency+')';
	                     document.getElementById('recieved').innerHTML ='Amount Recieved('+json.currency+')';*/
	                     
                      if(json.currency=='Rupee'||json.currency=='rupee'||json.currency=='Rupees'||json.currency=='INR' ){
	                   $('#exchangeRate'). attr('disabled',true);
	                  
                         }
                       else{
	                      $('#exchangeRate').attr('disabled',false);
	                     
                            }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("response textStatus " + textStatus);
                    console.log("response jqXHR " + jqXHR);
                    console.log("response errorThrown " + errorThrown);
                }
            });
        }

    });
   }) 