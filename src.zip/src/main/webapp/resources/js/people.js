if (window.jQuery) { 
	 
       $(document).ready(function(){
    	var tab= $('#peopleTable').DataTable();
         getPeopleList(tab);
         tab.clear().draw();
          window.getDataTable = function() {
		        return tab;
		    }
		    
	  });  
	 
 function addPeople() {
        
		$('.modal-body').load("new",function(){
			$('#myModal').modal({show:true});
		});
  }


  function updatePeople(id) {
      console.log(id)
		$('.modal-body').load("update/"+id,function(){
			$('#myModal').modal({show:true});
		});
}

function getPeopleList(table){

			var tab = table;
			$.getJSON("jlist", function(json) {
				for (var i = 0; i < json.length; i++) { 
					var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="javascript:updatePeople(' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deletePeople(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
					 tab.row.add( [
						    i+1,
				            json[i].firstName,
			                json[i].lastName,
			                json[i].enabled,
			                
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				}	
			});
			


			}

    	   $("#add_people").validate({
			
           rules: { 
        	   firstName: {
        		   required: true 
        	   },
        	   fatherName: {
        		   required: true 
        	   },
        	   motherName: {
        		   required: true 
        	   },
        	  
        	   lastName:{
			    	   required: true   
				       } ,
			  
		           lastDesignation:{
		           required: true,
		          
		           
		           },
		          
		           mobileNo: {
				        required: true,
				       
		               },
		      
			    },
			  
			    messages: {
			       firstName: "First Name is required",
			       lastName:"Last Name is required",
			      lastDesignation: "  Designation Detail is required",
			       mobileNo: "Mobile number is  required",
			        fatherName:"Father Name is required",
			        motherName:"Mother Name is required"
			    },
			  
			    submitHandler: function (form) {
			    	 $.ajax({
			      		 url: 'add',
			      		 type: 'GET',
			      		 data:$("#add_people").serialize(),
			      		 success: function(data) {
					     		 
			      			$("#myModal .close").click();
			      			window.getPeopleList(window.getDataTable().clear());
			      		$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });
		                     	
								
								 
			      		 
			      		 },error: function (jqXHR, textStatus, errorThrown) {
			      		 var json = JSON.parse(JSON.stringify(jqXHR))
			      		 console.log(json);
			      		 console.log("response textStatus " + textStatus);
			      		 console.log("response jqXHR " + jqXHR);
			      		 console.log("response errorThrown " + errorThrown);
			      		 }
			      		 })
		            
		         }
  
			 }); 
            
    
        

  function deletePeople(id,btn){
	if(confirm("are you sure you want to delete record ??")==true){

		 $.ajax({
	          url: 'delete/'+id,
	          method: 'GET',
	          success: function (data) {
                  console.log(data)
	        	
                  $(btn).closest("tr").remove();
                 
                
                 	$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });
                  $(".alert").children("p").text(data);
	          },
	          error: function (jqXHR, textStatus, errorThrown) {
	              
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              console.log(json);
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	      })

		}
	else{
          alert("your record is safe now!!");
		}
     

  }


   } 




