 
$(document).ready(function(){
	
	
	var tab= $('#dayBokTable').DataTable();
   getDayBookList(tab);
   window.getDataTable = function() {
       return tab;
   }
   $("#DateForm").submit(function(e){
		 e.preventDefault(); 
		 var fromDate = $("input[name='fromDate']",this).val();
		 var toDate= $("input[name='toDate']",this).val();
		console.log(toDate)
			   $.ajax({
			         type: 'get',
			         url: 'getDayBookTillDate/'+fromDate+'/'+toDate,
			        
			         success : function(data) {
			        	 tab.clear().draw();
			        	 var json = JSON.parse(JSON.stringify(data));
			       
	                 	    console.log("data book"+data)   
		                 	    
			                 for (var i = 0; i < json.length; i++) { 
								var editButton='<button class="btn btn-warning btn-xs" style="display:inline;" onclick=editDayBook('+ json[i].id + ') ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
								var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteDayBook(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';	
				          	 	console.log("hello")
								tab.row.add( [
							    i+1,
							    json[i].serialNo,
							    json[i].createdDate,
							    json[i].debitCredit,
					            json[i].amount,
					            convertDate(json[i].paymentDate),
					            json[i].accountHead.name,
					            json[i].payee,
					            json[i].runingBalance,
					            editButton+" "+deleteButton, 
					        ] ).draw( false );	
			}	
	                 	    
	                 	    
			        	// window.getPaymentList(window.getDataTable().clear());
			          }, 
			          error: function(xhr, status, error) {
		                   
		                }
			  });  
	 }); 
   
    
});

 

function getDayBookList(table){

	var tab = table;
	$.getJSON("jlist", function(json) {
		var debitCredit="";
		console.log(json)
		for (var i = 0; i < json.length; i++) { 
			var editButton='<button class="btn btn-warning btn-xs" style="display:inline;" onclick=editDayBook('+ json[i].id + ') ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>| ' ;
			var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteDayBook(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';	
			 if(json[i].debitCredit==-1)
				  debitCredit="Debit"
			else if(json[i].debitCredit==1)
				debitCredit="Credit"
			tab.row.add( [
				    i+1,
				    json[i].serialNo,
				    json[i].createdDate,
				    debitCredit,
		            json[i].amount,
		            convertDate(json[i].paymentDate),
		            json[i].accountHead.name,
		            json[i].payee,
		            json[i].runingBalance,
		            editButton+" "+deleteButton, 
		        ] ).draw( false );	
		}	
	});
	
	

}



  

function deleteDayBook(id,btn){
	if(confirm("are you sure you want to delete record ??")==true){

		 $.ajax({
	          url: 'delete/'+id,
	          method: 'GET',
	          success: function (data) {
                console.log(data)
	        	
                $(btn).closest("tr").remove();
               
              
                $(".msg").addClass("alert alert-success").text(data).fadeTo(2000, 500).slideUp(500, function() {
	                   $('.msg').slideUp(500);
                });
                //$(".alert").children("p").text(data);
	          },
	          error: function (jqXHR, textStatus, errorThrown) {
	              
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              console.log(json);
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	      })

		}
	else{
        alert("your record is safe now!!");
		}
   

}


function editDayBook(id) {
  
	
		$('.modal-body').load("update/"+id, function() {
			
			$('#myModal').modal({
				show : true
			});
			
		});
	
}

function convertDate(date) {
	var javadateTime = new Date(date);
	var day = ("0" + javadateTime.getDate()).slice(-2);
	var month = ("0" + (javadateTime.getMonth() + 1)).slice(-2);
	return javadateTime.getFullYear() + "-" + (month) + "-" + (day);
}

  