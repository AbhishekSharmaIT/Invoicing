
$(document).ready(function () {
   



    $('#client').on('change', function () {
        var selectedValue = this.selectedOptions[0].value;
        var selectedText = this.selectedOptions[0].text;
       

        if (selectedValue === "0") {
           
        } else {
            console.log("Selected Option: " + selectedText + " Selected Option value: " + selectedValue);
           
            $.ajax({
                type: "GET",
                url: "getClientPurchaseOrder",
                data: {
                    "clientId": selectedValue
                },
                success: function (data) {
                    console.log("response comes " + data);

                    
                     var json = JSON.parse(JSON.stringify(data))
                     console.log(json);
                   
                     
                    let dropdown = $('#purchase-order');

                    dropdown.empty();
                    
                    dropdown.append('<option selected="true" disabled>Select Purchase order</option>');
                    dropdown.prop('selectedIndex', 0);
                    
                   
                    
                    $.each(json, function (key, entry) {
                      dropdown.append($('<option></option>').attr('value', entry.id).text(entry.title));
                    });
                    
                   


                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log("response textStatus " + textStatus);
                    console.log("response jqXHR " + jqXHR);
                    console.log("response errorThrown " + errorThrown);
                }
            });
        }

    });
    }) 
    