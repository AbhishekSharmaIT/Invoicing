/**
 * 
 */
$(document).ready(function() {
	var tab=$('#example').DataTable();
	tab.clear().draw();
	getConsultantList();
});


function getConsultantList()
	{
	var tab=$('#example').DataTable();
	$.getJSON('jlist', function(json){
	//console.log(json);
if(json !== 'undefined'){
		for (var i = 0; i < json.length; i++) { 
			var actionButton="<button class='btn btn-warning' style='display:inline;'  onclick='updateconsultant("+ json[i].id +")'><i class='fa fa-pencil-square-o' aria-hidden='true'></i></button> | "
			var deleteButton="<button class='btn btn-danger' style='display:inline;' onclick='deleteconsultant(event,"+ json[i].id + ")'><i class='fa fa-trash-o' aria-hidden='true'></i></button>";
			 tab.row.add( [i+1,json[i].name,json[i].businessname,json[i].company.name,json[i].registeredDate,json[i].enabled,actionButton+" "+deleteButton,] ).draw( false );	
		}	}
	});
}   
function newConsultant() {
	$('.modal-body').load('add',function(){
		$('#myModal').modal({show:true});
	});
}
function updateconsultant(id) {
	$('.modal-body').load('update?id='+id,function(){
		$('#myModal').modal({show:true});
	});
}
function deleteconsultant(event,id)
	{
	if(confirm('are you sure you want to delete this record permanently?')==true){
	var table=$('#example').DataTable();
	var tableRow = $(event.target).parent();
		$.ajax({
			url:'delete/'+id,
			method:'get',
			success:function(data){
			var json = JSON.parse(JSON.stringify(data))
				console.log(json);
                  if(json == 'Delete') { 
                  table.row(tableRow).remove().draw();
   $('#success-alert').fadeIn('slow', function(){
               $('#success-alert').delay(3000).fadeOut(); 
            });
            }
		  	},
			error:function(jqXHR,status,errorThrown){
				var json=JSON.parse(JSON.stringify(jqXHR));
				console.log(json);
				console.log(jqXHR);
				console.log(status);
				console.log(errorThrown);
			}
		})
	}
	else
	{
		alert('Your record is safe now!');
	}
	}
	
$("#form_data").submit(function(e){
	 e.preventDefault(); 
	var name=nameCheck();	 var businessname=businessnameCheck();	 var company=companyCheck();	 var email=emailCheck();
	var contactno=contactnoCheck();	 var registrationdate=registrationdateCheck();   var taxdocno=taxdocnoCheck();
	  if((name == true) && (businessname == true) && (company == true) && (email == true) && (contactno == true) && (registrationdate == true) && (taxdocno == true)){
		 //console.log(name + businessname);
		 $.ajax({
	         type: 'POST',
	         url: 'save',
	         data : $(this).serialize(),	            
	         success : function(data) {			
	             //console.log(data);  		
	             //console.log(data.statusMessage);  
	              $('#myModal').modal('hide');
	             if(data.statusMessage=='Updated'){ 
	             $('#update-alert').fadeIn('slow', function(){
               $('#update-alert').delay(3000).fadeOut(); 
            });}
	             else{
	            
	             $('#add-alert').fadeIn('slow', function(){
               $('#add-alert').delay(3000).fadeOut(); 
            });}
	             var tab=$('#example').DataTable();
	             tab.clear().draw();
	             getConsultantList();
	          }, 
	          error: function (jqXHR, textStatus, errorThrown) {
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              //console.log(json);
	              $.each(json.responseJSON,function(key, value) {
			      console.log(value.fieldName+value.errorMsg);                          
			               	});
							for (var i = 0; i < json.responseJSON.length; ++i) {
			                    console.log(json.responseJSON[i].fieldName);
			                    console.log(json.responseJSON[i].errorMsg);
			                    $('input[name='+json.responseJSON[i].fieldName+']').after('<span class="error d-block mx-0 text-danger">'+json.responseJSON[i].errorMsg+'</span>');
			                    //$('#' + json.responseJSON[i].fieldName).html(json.responseJSON[i].errorMsg);
			                    setTimeout(function(){
			                    	  $('.error').remove();
			                    }, 20000);
			                }
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	 }); 
		 return true;
	 }
	 else{
	 return false;
	 }
		 
});    
function nameCheck(){
	 var name = $('#name').val();
	 if(name == ''){
	 $('#cname').show();
		$('#cname').html("Please Enter Consultant Name");
		$('#cname').focus();
		$('#cname').css("color","red");
		name=false;
		return false;
	 }
	 else{
		 $('#cname').hide();
		 return true;
	 }
	 }
function businessnameCheck(){
	 var businessname = $('#businessname').val();
	 if(businessname == ''){
	 $('#cbusinessname').show();
		$('#cbusinessname').html("Please Enter Consultant Business Name");
		$('#cbusinessname').focus();
		$('#cbusinessname').css("color","red");
		businessname=false;
		return false;
	 }
	 else{
		 $('#cbusinessname').hide();
		 return true;
	 }
	 }
function companyCheck(){
	 var company = $('#companyt').val();
	 if(company == ''){
	 $('#ctype').show();
		$('#ctype').html("Please Select Type of Company");
		$('#ctype').focus();
		$('#ctype').css("color","red");
		company=false;
		return false;
	 }
	 else{
		 $('#ctype').hide();
		 return true;
	 }
	 }
function emailCheck(){
	 var email = $('#email').val();
	 if(email == ''){
	 $('#cemail').show();
		$('#cemail').html("Please Write Consultant Email-ID");
		$('#cemail').focus();
		$('#cemail').css("color","red");
		email=false;
		return false;
	 }
	 else if(IsEmail(email)==false){
	 $('#cemail').show();
		$('#cemail').html("Please Write Correct Consultant Email-ID");
		$('#cemail').focus();
		$('#cemail').css("color","red");
		email=false;
		return false;
	 }
	 else{
		 $('#cemail').hide();
		 return true;
	 }
	 }
	  function IsEmail(email) {
  var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  if(!regex.test(email)) {
    return false;
  }else{
    return true;
  }
}
function contactnoCheck(){
	 var contactno = $('#contactno').val();
	 var number=$.isNumeric(contactno);
	 if(contactno == '' ){
	 $('#ccontactno').show();
		$('#ccontactno').html("Please Fill Consultant Contact Number");
		$('#ccontactno').focus();
		$('#ccontactno').css("color","red");
		contactno=false;
		return false;
	 }
	 else if(!number){
	 $('#ccontactno').show();
		$('#ccontactno').html("Please Fill Correct Consultant Contact Number");
		$('#ccontactno').focus();
		$('#ccontactno').css("color","red");
		contactno=false;
		return false;
	 }
	 else{
		 $('#ccontactno').hide();
		 return true;
	 }
	 }
	 function registrationdateCheck(){
		 var registrationdate = $('#registrationdate').val();
		 if(registrationdate == ''){
		 $('#cregistrationdate').show();
			$('#cregistrationdate').html("Please Select Registration Date");
			$('#cregistrationdate').focus();
			$('#cregistrationdate').css("color","red");
			registrationdate=false;
			return false;
		 }
		 else{
			 $('#cregistrationdate').hide();
			 return true;
		 }
		 }
	 function taxdocnoCheck(){
		 var taxdocno1 = $('#taxdocno1').val();
		 if(taxdocno1 == ''){
		 $('#ctaxdocno1').show();
			$('#ctaxdocno1').html("Please Enter Your Tax Document Number");
			$('#ctaxdocno1').focus();
			$('#ctaxdocno1').css("color","red");
			taxdocno1=false;
			return false;
		 }
		 else{
			 $('#ctaxdocno1').hide();
			 return true;
		 }
		 }