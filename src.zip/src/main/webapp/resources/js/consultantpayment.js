
if (window.jQuery) { 
	 
       $(document).ready(function(){
    	var tab= $('#consultantpaymentTable').DataTable();
         getConsultantList(tab);
         tab.clear().draw();
          window.getDataTable = function() {
		        return tab;
		    }
		    
	  });  
	 
 function addConsultantPayment() {
        
		$('.modal-body').load("new",function(){
			$('#myModal').modal({show:true});
		});
  }


  function updateConsultantPayment(id) {
      
		$('.modal-body').load("update/"+id,function(){
			$('#myModal').modal({show:true});
		});
}

function getConsultantList(table){

			var tab = table;
			$.getJSON("jlist", function(json) {
				for (var i = 0; i < json.length; i++) { 
					var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="javascript:updateConsultantPayment(' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteConsultantPayment(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
					 tab.row.add( [
						    i+1,
				            json[i].amount,
			               convertDate(json[i].paymentDate),
			                json[i].trnDetails,
			                json[i].consultantinvoicing.invoiceNo,
			                json[i].paymentmode.name,
			            
				            
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				}	
			});
			


			}

    	   $("#add_consultant").validate({
           rules: { 
        	   amount: {
        		   required: true 
        	   },
        	   paymentmode:"required",
        	   trnDetails:{
			    	   required: true   
				       } ,
			      consultantinvoicing: "required",
			  
		           paymentDate:{
		           required: true,
		          
		           
		           },
		           taxPaid:"required",
		           taxDeducted: {
				        required: true,
				       
		               },
		      
			    },
			  
			    messages: {
			      amount: "Amount is requiered",
			      paymentmode:"PaymentMode is required",
			      trnDetails: " Transaction Detail is required",
			      consultantinvoicing: "ConsultantInvoicing is required",
			    
			      paymentDate:"PaymentDate  is required",
			      taxDeducted:"TaxDeducted is required",
			      taxPaid: "TaxPaid is required",
	                      
			    },
			  
			    submitHandler: function (form) {
			    	 $.ajax({
			      		 url: 'add',
			      		 type: 'GET',
			      		 data:$("#add_consultant").serialize(),
			      		 success: function(data) {
			      		 
			      			$("#myModal .close").click();
			      			window.getConsultantList(window.getDataTable().clear());
			      		 $(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
	                   $('.msg').slideUp(500);
                });
		                     	
								
								 
			      		 
			      		 },error: function (jqXHR, textStatus, errorThrown) {
			      		 var json = JSON.parse(JSON.stringify(jqXHR))
			      		 console.log(json);
			      		 console.log("response textStatus " + textStatus);
			      		 console.log("response jqXHR " + jqXHR);
			      		 console.log("response errorThrown " + errorThrown);
			      		 }
			      		 })
		            
		         }
  
			  }); 
            
    
        

  function deleteConsultantPayment(id,btn){
	if(confirm("are you sure you want to delete record ??")==true){

		 $.ajax({
	          url: 'delete/'+id,
	          method: 'GET',
	          success: function (data) {
                  console.log(data)
	        	
                  $(btn).closest("tr").remove();
                 
                $(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
	                   $('.msg').slideUp(500);
                });
	          },
	          error: function (jqXHR, textStatus, errorThrown) {
	              
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              console.log(json);
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	      })

		}
	else{
          alert("your record is safe now!!");
		}
     

  }

 function convertDate(date) {
	var javadateTime = new Date(date);

	var day = ("0" + javadateTime.getDate()).slice(-2);
	var month = ("0" + (javadateTime.getMonth() + 1)).slice(-2);

	return (day)+ "-" + (month)+ "-" +javadateTime.getFullYear();

}

   } 




		