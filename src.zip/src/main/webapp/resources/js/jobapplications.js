if (window.jQuery) { 
	 
       $(document).ready(function(){
    	var tab= $('#jobapplicationTable').DataTable();
         getJobApplicationList(tab);
         tab.clear().draw();
          window.getDataTable = function() {
		        return tab;
		    }
		    
	  });  
	 
 function addJobApplication() {
        
		$('.modal-body').load("new",function(){
			$('#myModal').modal({show:true});
		});
  }


  function updateJobApplication(id) {
      console.log(id)
		$('.modal-body').load("update/"+id,function(){
			$('#myModal').modal({show:true});
		});
}

function getJobApplicationList(table){

			var tab = table;
			$.getJSON("jlist", function(json) {
				for (var i = 0; i < json.length; i++) { 
					var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="javascript:updateJobApplication(' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteJobApplication(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
					 tab.row.add( [
						    i+1,
				            json[i].name,
			                json[i].phone,
			                json[i].email,
			                json[i].relevantExp,
			                json[i].jobOpening.name,
			                json[i].currentCompany,
			                json[i].currentLocation,
			                json[i].noticePeroid,
			                json[i].currentSalary,
			                json[i].expectedSalary,
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				}	
			});
			


			}

    	   $("#add_jobapplication").validate({
			
           rules: { 
        	   name: {
        		   required: true 
        	   },
        	   phone: {
        		   required: true 
        	   },
        	   email: {
        		   required: true 
        	   },
        	  
        	   currentCompany:{
			    	   required: true   
				       } ,
			  
		           currentLocation:{
		           required: true,
		          
		           
		           },
		          
		           noticePeroid: {
				        required: true,
				       
		               },
		            currentSalary:{
			    	   required: true   
				       } ,
				    expectedSalary:{
			    	   required: true   
				       } ,
		      
			    },
			  
			    messages: {
			       name: " Name is required",
			       email:" Email is required",
			       phone: "  Phone number is required",
			       currentCompany: "Current Company is  required",
			       currentLocation:"Current Location is required",
			       noticePeroid:"Notice Period is required",
			       currentSalary: "Current Salary is  required",
			       expectedSalary: "Expected Salary is  required",
			    },
			  
			    submitHandler: function (form) {
			    	 $.ajax({
			      		 url: 'add',
			      		 type: 'GET',
			      		 data:$("#add_jobapplication").serialize(),
			      		 success: function(data) {
					     		 
			      			$("#myModal .close").click();
			      			window.getJobApplicationList(window.getDataTable().clear());
			      		$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });
		                     	
								
								 
			      		 
			      		 },error: function (jqXHR, textStatus, errorThrown) {
			      		 var json = JSON.parse(JSON.stringify(jqXHR))
			      		 console.log(json);
			      		 console.log("response textStatus " + textStatus);
			      		 console.log("response jqXHR " + jqXHR);
			      		 console.log("response errorThrown " + errorThrown);
			      		 }
			      		 })
		            
		         }
  
			 }); 
            
    
        

  function deleteJobApplication(id,btn){
	if(confirm("are you sure you want to delete record ??")==true){

		 $.ajax({
	          url: 'delete/'+id,
	          method: 'GET',
	          success: function (data) {
                  console.log(data)
	        	
                  $(btn).closest("tr").remove();
                 
                
                 	$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });
                  $(".alert").children("p").text(data);
	          },
	          error: function (jqXHR, textStatus, errorThrown) {
	              
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              console.log(json);
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	      })

		}
	else{
          alert("your record is safe now!!");
		}
     

  }


   } 




