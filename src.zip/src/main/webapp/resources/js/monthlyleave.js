if (window.jQuery) { 
	 
       $(document).ready(function(){
    	var tab= $('#monthlyleaveTable').DataTable();
         getMonthlyLeaveList(tab);
         tab.clear().draw();
          window.getDataTable = function() {
		        return tab;
		    }
		    
	  });  
	 
 function addMonthlyLeave() {
        
		$('.modal-body').load("new",function(){
			$('#myModal').modal({show:true});
		});
  }


  function updateMonthlyLeave(id) {
      console.log(id)
		$('.modal-body').load("update/"+id,function(){
			$('#myModal').modal({show:true});
		});
}

function getMonthlyLeaveList(table){

			var tab = table;
			$.getJSON("jlist", function(json) {
				for (var i = 0; i < json.length; i++) { 
					var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="javascript:updateMonthlyLeave(' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteMonthlyLeave(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
					 tab.row.add( [
						    i+1,
				            json[i].people.firstName,
			                json[i].processMonth,
			                json[i].totalCount,
			                json[i].fullDay,
			                json[i].halfDay,
			                json[i].ciCount,
			                json[i].piCount,
			                json[i].avgWorkingHour,
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				}	
			});
			


			}

    	   $("#add_monthlyleave").validate({
			
           rules: { 
        	   processMonth: {
        		   required: true 
        	   },
        	   leaveDates: {
        		   required: true 
        	   },
        	   
			    },
			  
			    messages: {
			       processMonth: "Process Month is required",
			       leaveDates:"Leave Dates is required",
			     
			    },
			  
			    submitHandler: function (form) {
			    	 $.ajax({
			      		 url: 'add',
			      		 type: 'GET',
			      		 data:$("#add_monthlyleave").serialize(),
			      		 success: function(data) {
					     		 
			      			$("#myModal .close").click();
			      			window.getMonthlyLeaveList(window.getDataTable().clear());
			      		$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });
		                     	
								
								 
			      		 
			      		 },error: function (jqXHR, textStatus, errorThrown) {
			      		 var json = JSON.parse(JSON.stringify(jqXHR))
			      		 console.log(json);
			      		 console.log("response textStatus " + textStatus);
			      		 console.log("response jqXHR " + jqXHR);
			      		 console.log("response errorThrown " + errorThrown);
			      		 }
			      		 })
		            
		         }
  
			 }); 
            
    
        

  function deleteMonthlyLeave(id,btn){
	if(confirm("are you sure you want to delete record ??")==true){

		 $.ajax({
	          url: 'delete/'+id,
	          method: 'GET',
	          success: function (data) {
                  console.log(data)
	        	
                  $(btn).closest("tr").remove();
                 
                
                 	$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });
                  $(".alert").children("p").text(data);
	          },
	          error: function (jqXHR, textStatus, errorThrown) {
	              
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              console.log(json);
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	      })

		}
	else{
          alert("your record is safe now!!");
		}
     

  }


   } 




