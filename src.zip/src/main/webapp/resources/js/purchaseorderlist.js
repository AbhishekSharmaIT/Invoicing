$(document).ready(function() {

	var tab=$('#data-table').DataTable();
	window.getDataTable = function(){
		return tab;
	}
	purchaseOrderList(tab);
});

function deletePurchaseOrder(event, id) {

	console.log(event.target);
	console.log(id);
	var tableRow = $(event.target).parent().parent().parent();
	var table =  window.getDataTable();
	console.log(tableRow);
	if (confirm("Are you sure you want to delete this?")) {

		$.ajax({
			url : 'delete',
			type : 'GET',
			data : {
				poid : id
			},
			success : function(data) {
				console.log('success' + data);
				$(".msg").addClass("alert alert-success").text(data).fadeTo(2000, 500).slideUp(500, function() {
	                   $('.msg').slideUp(500);
                });
				table.row(tableRow).remove().draw();
			},
			error : function(jqXHR, textStatus, errorThrown) {
				var json = JSON.parse(JSON.stringify(jqXHR));

				console.log(json);
				console.log("response textStatus " + textStatus);
				console.log("response jqXHR " + jqXHR);
				console.log("response errorThrown " + errorThrown);
			}
		})
	} else {

		console.log("in side else");
		return false;
	}

}


function purchaseOrderList(table) {
	var tab = table;
	
	
	$.ajax({
				url : 'load',
				type : 'GET',
				success : function(data) {
					var json = JSON.parse(JSON.stringify(data));
					console.log(json);

					$.each(json,function(key, value) {

										console.log("PO NUmber"
												+ value.poNumber);
										console.log("PurchaseOrder Date"
												+ value.poDate);
										console.log("Client Name"
												+ value.client.name);
										console.log
										console.log("Amount"
														+ value.grandTotal);
										var updateButton = "<button  class='btn btn-warning' id='update'><i class='fa fa-pencil' onclick=update('"+ value.id +"')></i></button>";
										var deleteButton = "<button  class='btn btn-danger' id='delete'><i class='fa fa-trash' onclick=deletePurchaseOrder(event," + value.id + ")></i></button>";
									
										var projectName;
										if (value.project == null) {

											projectName="<td>Not Available</td>";
										} else {
											projectName="<td>"+value.project.name+ "</td>";
										}
										
										tab.row.add([
												key+1,
												value.poNumber,
												convertDate(value.poDate),
												value.client.name,
												//projectName,
												value.grandTotal,
												updateButton+ " | "
														+ deleteButton, ]) .draw(false);
									});

				},
				error : function(jqXHR, textStatus, errorThrown) {
					var json = JSON.parse(JSON.stringify(jqXHR))
					console.log(json);
					console.log("response textStatus " + textStatus);
					console.log("response jqXHR " + jqXHR);
					console.log("response errorThrown " + errorThrown);
				}
			})
}


function convertDate(date) {
	var javadateTime = new Date(date);

	var day = ("0" + javadateTime.getDate()).slice(-2);
	var month = ("0" + (javadateTime.getMonth() + 1)).slice(-2);

	return (day)+ "-" + (month)+ "-" +javadateTime.getFullYear();

}
