$(document).ready(function(){
	
	var tab= $('#paymentTable').DataTable();
    getPaymentList(tab);
    tab.clear().draw();
    window.getDataTable = function() {
        return tab;
    }
   /* 
    $("form[name='utilityPayment_form']").validate({
        rules: {
		     
		      
		       utilityType: "required",
		       	billNo:"required",
		       //	toDate:"required",
		    	fromDate:"required",
		       	amount:"required",
		    	dueDate:"required",
		       	paymentDate:"required",
		       	paymentMode:"required",
		       	
		    },
		  
		    messages: {
		    	   utilityType: "type is required",
			       	billNo:"Please enter bill number",
			       //	toDate:"Please choose date",
			    	fromDate:"Please choose date",
			       	amount:"Please enter amount",
			    	dueDate:"Please choose date",
			       	paymentDate:"Please choose date",
			      	paymentMode:"Please choose payment mode",
			       	
		      },
		  
		    submitHandler: function (form) {
		    	 e.preventDefault(); 
		    	 var form = $(this)[0];
		    	    var data = new FormData(form);
		    	   
		    		  $.ajax({
		    		         type: 'POST',
		    		         url: 'add',
		    		         data:data,
		    		         processData: false, 
		    		         contentType: false,
		    		         enctype : 'multipart/form-data',
		    		         success : function(data) {
		    		        	 var json = JSON.parse(JSON.stringify(data));
		    		         console.log(data);
		    		        	 //$("#form_data").get(0).reset(); 
		    		        	 $("#myModal").modal('hide');
		    		        	 if(data.statusMessage=='Updated'){
		    		        		 $('#update-alert').addClass( "alert alert-info" ).css({"opacity":"500","display":"block" 
		    						}).text(json.msg).fadeTo(2000, 500).slideUp(500, function() {
		    			                   $('#add-alert').slideUp(500);
		    		                       }); }
		    		        	 else{
		                     	$('#add-alert').addClass( "alert alert-info" ).css({"opacity":"500","display":"block" 
		    						}).text(json.msg).fadeTo(2000, 500).slideUp(500, function() {
		    		                   $('#add-alert').slideUp(500);
		    	                       });
		    		        	 }
		                     	       
		    		        	 window.getPaymentList(window.getDataTable().clear());
		    		          }, 
		    		          error: function(xhr, status, error) {
		    	                     var err = JSON.parse(xhr.responseText);
		    	                    
		    	                   }
		    		  }); 
	            
	         }
		    
		    
		    
		  }); 
*/
   
    
})

  function addUtilityPayment() {
        
		$('.modal-body').load("form",function(){
			$('.error').remove();
			$('#myModal').modal({show:true});
		});
  }

function redirecturl(path)
{// var path1=path
	alert("hello"+path)
window.location.href = path;

}

function getPaymentList(table){

	var tab = table;
	$.getJSON("jlist", function(json) {
		
		for (var i = 0; i < json.length; i++) { 
			console.log(i);
			var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="javascript:updateUtilityPayment(' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
			var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteUtilityPayment(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
			var path=json[i].consultantInvoicDocument.path+"\\"+json[i].consultantInvoicDocument.name; 
	
			tab.row.add( [
				    i+1,
		            json[i].utilityType.name,
		            json[i].billNo,
		            convertDate(json[i].fromDate),
		            convertDate(json[i].toDate),
		            json[i].amount,
		            "<a  href=download?path="+encodeURIComponent(path)+"> download</a>",
		     
		            convertDate(json[i].dueDate),
		            convertDate(json[i].paymentDate),
		            json[i].remark,
			           
		            editButton+" "+deleteButton,   
		        ] ).draw( false );	
		}	
	});
	
	

}


function deleteUtilityPayment(id,btn){
	if(confirm("are you sure you want to delete record ??")==true){

		 $.ajax({
	          url: 'delete/'+id,
	          method: 'GET',
	          success: function (data) {
                console.log(data)
	        	
                $(btn).closest("tr").remove();
               
              
                $(".msg").addClass("alert alert-success").text(data).fadeTo(2000, 500).slideUp(500, function() {
	                   $('.msg').slideUp(500);
                });
                //$(".alert").children("p").text(data);
	          },
	          error: function (jqXHR, textStatus, errorThrown) {
	              
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              console.log(json);
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	      })

		}
	else{
        alert("your record is safe now!!");
		}
   

}


function updateUtilityPayment(id) {
    
	$('.modal-body').load("update/"+id,function(){
		$('#myModal').modal({show:true});
	});
}

function convertDate(date) {
	var javadateTime = new Date(date);
	var day = ("0" + javadateTime.getDate()).slice(-2);
	var month = ("0" + (javadateTime.getMonth() + 1)).slice(-2);
	return javadateTime.getFullYear() + "-" + (month) + "-" + (day);
}

