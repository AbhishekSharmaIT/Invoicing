$(document).ready(function(){
	
	var tab= $('#dayBookList').DataTable();
	
	
   getTodaysList(tab);
  
    tab.clear().draw();
    window.getDataTable = function() {
        return tab;
    }
   
    
    $("#paymentModeId").change(function () {
	    //var checkInputs = $(this).val();
    	var checkInputs= $("#paymentModeId option:selected").text()
    	
	  var inputfield="";
	
	  $(".addInput").empty();
	   
	  console.log(checkInputs.localeCompare("Cheque/Draft"));
	  if(checkInputs.localeCompare("Cheque/Draft")==0){
		  alert("hello")
	  inputfield=" <div class='form-group row'> " +
	 		"<label for='inputText' class='col-sm-3 col-form-label required'>Cheque/Draft#</label>" +
	 		"<div class='col-sm-3'> <input  class='form-control input-field' name='chqDrftTrnRefNo' placeholder=''  />" +
	 		
	 		"</div>  <label for='inputText' class='col-sm-3 col-form-label'>Cheque/Draft Date</label> <div class='col-sm-3'> " +
	 		" <input type=date  class='form-control input-field' name='chqDrftTrnDate' placeholder='' /> </div></div>" +
	 		
	 		"<div class='form-group row' ><label for='inputText' class='col-sm-3 col-form-label required'>Drawn on</label>" +
	 		" <div class='col-sm-9'> <input  type=date class='form-control input-field' name='chqDrftTrnDrawnDate' placeholder='' /> </div> </div>"+
	 		
	 		
	 		"<div class='form-group row'> <label for='inputText' class='col-sm-3 col-form-label required'>Bank & Branch</label>" +
	 		" <div class='col-sm-9'> <input  class='form-control input-field' name='bankName' placeholder='' /> </div> </div>";
	 
	 $(".addInput").append(inputfield);
	  }
	  else if(checkInputs.localeCompare("NEFT/RTGS")==0){
		  
		  inputfield=" <div class='form-group row'> " +
	 		"<label for='inputText' class='col-sm-3 col-form-label required'>Trans. Ref#</label>" +
	 		"<div class='col-sm-3'> <input  class='form-control input-field' name='chqDrftTrnRefNo' placeholder=''  />" +
	 		
	 		"</div>  <label for='inputText' class='col-sm-3 col-form-label'>Trans. Date</label> <div class='col-sm-3'> " +
	 		" <input type=date  class='form-control input-field' name='chqDrftTrnDate' placeholder='' /> </div></div>" +
	 		
	 		"<div class='form-group row' ><label for='inputText' class='col-sm-3 col-form-label required'>Drawn on</label>" +
	 		" <div class='col-sm-9'> <input  type=date class='form-control input-field' name='chqDrftTrnDrawnDate' placeholder='' /> </div> </div>"+
	 		
	 		
	 		"<div class='form-group row'> <label for='inputText' class='col-sm-3 col-form-label required'>Bank & Branch</label>" +
	 		" <div class='col-sm-9'> <input  class='form-control input-field' name='bankName' placeholder='' /> </div> </div>";
	 
	 $(".addInput").append(inputfield);
		  
	  }
    	
	});
	
	 $("form[name='dayBook']").validate({
	        rules: {
			     
			      
			        debitCredit: "required",
			       	accountHeadCode:"required",
			       	description:"required",
			    	payee:"required",
			       	amount:"required",
			       	billRefNo:"required",
			       	paymentDate:"required",
			       	paymentMode:"required",
			       	
			    },
			  
			    messages: {
			    	    debitCredit: "please select debit Or credit",
				        accountHeadCode:"Please Select Account Head Code",
				       	description:"Please fill the Description",
				       	payee:"please fill payee",
				       	amount:"Amount is required",
				    	
				      	paymentDate:"Select Payment Date"
				      
				       	
			      },
			  
			    submitHandler: function (form) {
				   alert("hello")
				   valid=true;
				if (valid && $('#accountHeadId').val() == 0) {
			        console.log($('#accountHeadId').val());
			        $('#accountHeadId').removeClass("is-invalid is-vaild").addClass("is-invalid");
                   // $('input[type=submit]').attr('disabled', 'disabled');
			        valid = false;
			    }
				
				if (valid && $('#amount').val()<=0) {
			        console.log($('#accountHeadId').val());
			        $('#accountHeadId').removeClass("is-invalid is-vaild").addClass("is-invalid");
                   // $('input[type=submit]').attr('disabled', 'disabled');
			        valid = false;
			    }
				var data=$("#dayBook-form").serialize();
				console.log(data);
				console.log(data);
			    	$.ajax({
			    		 type: 'POST',
			                
			    		 url: "add",
		                
		                 data:data,
		              
		  		    	
		                     success: function (data) {
		                    	 
/*
		                     	//$(".msg").addClass("alert alert-success").text(data.msg)
		                    		$(".msg").addClass("alert alert-success").text(data.statusMessage).fadeTo(2000, 500).slideUp(500, function() {
						                   $('.msg').slideUp(500);
				                       });
		                     	*/
		                    	
		                         $("#dayBook-form").get(0).reset();
		                         window.getTodaysList(window.getDataTable().clear());
		                         
		                     	
		                     },
		              error: function (jqXHR, textStatus, errorThrown,data) {
	              	 var json = JSON.parse(JSON.stringify(jqXHR));
	              	 console.log("error"+json);
	              		
	              		
	                  
	               }

					   })
		            
		         }
			    
			    
			    
			  }); 
	 
	 
	 
	 
	 $("#debitCredit").on("change",function(){
		 
		 var type=$(this).val();
	 	
		 $.ajax({
			 type: "GET",
             url: "accoountHeads/"+type,
             
             success: function (data) {
                 console.log("response comes " + data);

                  var json = JSON.parse(JSON.stringify(data))
                  console.log(json[0].code);
                
                 let dropdown = $('#accountHeadId');

                 dropdown.empty();

                  dropdown.append('<option selected="true" value="0" >Select Account Head</option>');
                  dropdown.prop('selectedIndex', 0);

                
                 $.each(json, function (key, entry) {
                     dropdown.append($('<option></option>').attr('value', entry.id).text(entry.name));
                 });
             }   
		 })
	 	
	 })
	 
	 
	 $('#accountHeadId').on('change', function () {
	        var selectedValue = this.selectedOptions[0].value;
	        var selectedText = this.selectedOptions[0].text;
	        //console.log("Seleced Option: " +selectedText+" Seleced Option value: "+selectedValue);

	        if (selectedValue === "0") {
	            console.log("inside if.");
	            $('#accountHeadId').removeClass("is-invalid is-vaild").addClass("is-invalid");
	            $('input[type=submit]').attr('disabled', 'disabled');
	        } else {
	            console.log("Seleced Option: " + selectedText + " Seleced Option value: " + selectedValue);
	            $('#accountHeadId').removeClass("is-invalid is-valid").addClass("is-vaild");
	              $('input[type=submit]').removeAttr("disabled");
	              }
	       });
	 
	 $("#amount").focusout(function(){
		
		    if ($(this).val()<=0) {
	            console.log("inside if.");
	            $('#amount').removeClass("is-invalid is-vaild").addClass("is-invalid");
	            $('input[type=submit]').attr('disabled', 'disabled');
	        } else {
	            
	            $('#amount').removeClass("is-invalid is-valid").addClass("is-vaild");
	              $('input[type=submit]').removeAttr("disabled");
	              }
		    
		  });
	 
})



function getTodaysList(table){

	var tab = table;
	var debitCredit='';
	$.getJSON("TodaysList", function(json) {
		console.log("todays"+json)
		
		for (var i = 0; i < json.length; i++) { 
			
		  if(json[i].debitCredit==-1)
			  debitCredit="Debit"
		else if(json[i].debitCredit==1)
			debitCredit="Credit"
			tab.row.add( [
				    i+1,
				    debitCredit,
		            json[i].amount,
		            convertDate(json[i].paymentDate),
		            json[i].description,
		        ] ).draw( false );	
		}	
	});
	
	
	function convertDate(date) {
		var javadateTime = new Date(date);
		var day = ("0" + javadateTime.getDate()).slice(-2);
		var month = ("0" + (javadateTime.getMonth() + 1)).slice(-2);
		return javadateTime.getFullYear() + "-" + (month) + "-" + (day);
	}
}