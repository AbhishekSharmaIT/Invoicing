if (window.jQuery) { 
	 
       $(document).ready(function(){
    	var tab= $('#projectTable').DataTable();
         getprojectList(tab);
         tab.clear().draw();
          window.getDataTable = function() {
		        return tab;
		    }
		    
	  });  
	  	  function addProject() {
        
		$('.modal-body').load("new",function(){
			$('#myModal').modal({show:true});
		});
  }


  function updateProject(id) {
      
		$('.modal-body').load("update/"+id,function(){
			$('#myModal').modal({show:true});
		});
}

	function getprojectList(table){

			var tab = table;
			$.getJSON("jlist", function(json) {
				
				
				$.each(json,function(key, entry) {
					
					var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="javascript:updateProject(' + entry.id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteProject(' + entry.id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
					var technologyArray = [];
					
					$.each(entry.technology,function(key, entry) {
						console.log(entry.name);
					  technologyArray.push(" "+entry.name.toUpperCase());
					});
					
					tab.row.add( [
						    key+1,
				           entry.name,
			                entry.client.name,
			                entry.purchaseorder.title,
			               
			               technologyArray,
			               
			               
			     
			             convertDate(entry.startDate),
			            
				            
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				});
				
			});
			}
	/*
		function getprojectList(table){

			var tab = table;
			$.getJSON("jlist", function(json) {
				for (var i = 0; i < json.length; i++) { 
					
					var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="javascript:updateProject(' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteProject(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
					 tab.row.add( [
						    i+1,
				            json[i].name,
			                json[i].client.name,
			                json[i].purchaseorder.title,
			                json[i].startDate,
			            
				            
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				}	
			});
			}
			
        
	 
	 
 
    	  $("#add_project").validate({
           rules: { 
        	   name: {
        		   required: true 
        	   },
        	   "client":"required",
        	   
        	   "purchaseorder":"required",
        	   createdDate:{
		           required: true,
		          
		           
		           },
		           startDate:{
			           required: true,
			          
			           
			           },
        	   endDate:{
			    	   required: true   
				       } ,
			      "billingcycle": "required",
			  
		          
		           "billingtype":"required",
		           
		      
			    },
			  
			    messages: {
			    	name: " Project Name is required",
			    	"client":" Client is required",
			    	"purchaseorder": " PurchaseOrder is required",
			    	createdDate: "CreatedDate is required",
			    
			    	startDate:"StartDate  is required",
			    	endDate:"EndDate is required",
			    	 "billingcycle": "BillingCycle is required",
			    	 "billingtype": "BillingType is required",
			    },
			    submitHandler: function (form) {
			    	 $.ajax({
			      		 url: 'saveProject',
			      		 type: 'GET',
			      		 data:$("#add_project").serialize(),
			      		 processData: false, 
		                 contentType: false,
		                 enctype : 'multipart/form-data',
			      		
			      		 success: function(data) {
				          
			      		 },error: function (jqXHR, textStatus, errorThrown,data) {
				              
				            $("#myModal .close").click();
				            window.getprojectList(window.getDataTable().clear());
				           
			      		 $(".msg").addClass("alert alert-error").text(data.msg)

			      		 var json = JSON.parse(JSON.stringify(jqXHR))
			      		 console.log(json);
			      		 console.log("response textStatus " + textStatus);
			      		 console.log("response jqXHR " + jqXHR);
			      		 console.log("response errorThrown " + errorThrown);
			      		 }
			      		 })
		            
		         }
  
			  }); 
            
   */
 
               
   
      
        

  function deleteProject(id,btn){
	if(confirm("are you sure you want to delete record ??")==true){

		 $.ajax({
	          url: 'delete/'+id,
	          method: 'GET',
	          success: function (data) {
                  console.log(data)
	        	
                  $(btn).closest("tr").remove();
                 $(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
	                   $('.msg').slideUp(500);
                });
                
                 	
	          },
	          error: function (jqXHR, textStatus, errorThrown) {
	              
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              console.log(json);
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	      })

		}
	else{
          alert("your record is safe now!!");
		}
     

  }
  function convertDate(date) {
	var javadateTime = new Date(date);

	var day = ("0" + javadateTime.getDate()).slice(-2);
	var month = ("0" + (javadateTime.getMonth() + 1)).slice(-2);

	return (day)+ "-" + (month)+ "-" +javadateTime.getFullYear();

}

  }



