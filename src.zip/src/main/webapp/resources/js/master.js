 
function create() {
	
		 $(".modal-title").html("Create");
		 $("#myModal").modal('show');
		 $("form").prop('id','add');
		 $('#type').val('');
		 $('.rowid').remove();
		 $('.error').remove();
	    }

		$(document).ready(function() {
			var tablerow;
			$("#msg").after('<hr width="100%" />');
			var tab = 	$('#data-table').DataTable();
			
            $.getJSON(url+"/list", function(json) {
	     
        
				for (var i = 0; i < json.length; i++) {
					var jsonData=json[i]; 
					
					var editButton='<button class="btn btn-success btn-xs" style="display:inline;" onclick="javascript:editMaster(event,' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </button>&nbsp;|&nbsp;';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteMaster(event,' + json[i].id + ')"><i class="fa fa-trash-o" aria-hidden="true"></i> </button>';
					 tab.row.add( [
				            i+1,
				            jsonData[key],
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				}	
				
			});
		
		});
		function editMaster(e,id){
			  var tab = 	$('#data-table').DataTable();
		      $('.error').remove();
			  $('.rowid').remove();
			  var tableRow = $(e.target).parent();
			  var d = tab.row( tableRow ).data();
			  tablerow=d;
			// var tr = $(e.target).closest("tr");
           //   var rowindex = tr.index();
            var rowindex=tab.row(  tableRow ).index()
         // alert( 'Row index: '+tab.row(  tableRow ).index() );
          //    alert(index);
           //   alert(tablerow[0]);
			  var value=d[1];
			
			$(".modal-title").html("Update");
			   $("#myModal").modal('show');   
			   $("#type").val(value); 
			   $("form").attr('id','edit');
			   $('.inputid').append('<input type="hidden"  class="rowid" id='+ rowindex +' name="id" value='+id+' />');
			   
		}
		function deleteMaster(e,id){
			if (confirm('Do you really want to delete record?')) {
				$('.rowid').remove();
			    var tableRow = $(e.target).parent();
		     	var tab = 	$('#data-table').DataTable();
			    
				$.ajax({
					type: "get",
					url: url+"/delete/" + id,
					cache: false,
					success: function() {
						
						tab.row(tableRow).remove().draw(false);
						var msg='<div class="alert alert-primary" style="width:100%" role="alert">Deleted successfully </div>'
						$("#msg").after(msg).fadeIn().fadeOut(3000, function() {
							$(".alert").remove();
							});
						
					},
					error: function() {
						$('#err').html('<span style=\'color:red; font-weight: bold; font-size: 30px;\'>Error deleting record').fadeIn().fadeOut(4000, function() {
							$(this).remove();
						});
					}
				});
			}
			   
		}
	
		$(document).on("submit","#add",function(event){
		$('.error').remove();
			var tab = 	$('#data-table').DataTable();
	        	event.preventDefault();
	        	
	        	var check=true;
				var name = $('#type').val();
				var data = tab.column(1).data();
				 data.each(function (value, index) {
				     if(value==name ){
				    	 check= false;
				    	 $('#type').val('');
				    	 $(".modal-title").html("already exit ");
				    	 return false;	 
				     }
				     
				 });
				 if(check){
				$.ajax({
					type: "post",
					url: url+"/save",
					data : $('form[name=companyForm]').serialize(),

					success: function(result) {
					
					
						var last_row = tab.row(':last').data();
						
						var tabindex;
						console.log(result['id']);
						//console.log(result.name);
						try{
						 tabindex=last_row[0]+1;
						}catch(err) { 
						    
						}
						
						if(last_row === undefined){
							
							tabindex=1;
						}
						var msg='<div class="alert alert-primary" style="width:100%" role="alert">Added successfully </div>'
						$("#msg").after(msg).fadeIn().fadeOut(3000, function() {
							$(".alert").remove();
							});
						  var editButton='<button class="btn btn-success btn-xs"  onclick="javascript:editMaster(event,' + result['id'] + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </button>&nbsp;|&nbsp;';
						  var deleteButton='<button class="btn btn-danger btn-xs" onclick="deleteMaster(event,' + result['id'] + ')"><i class="fa fa-trash-o" aria-hidden="true"></i> </button>';
						  $("#myModal").modal('hide');
						 
						  tab.row.add( [
							    tabindex,
					            result[key],
					            editButton+" "+deleteButton,
					           
					        ] ).draw( false );
						    tab.page('last').draw(false);
						  
					},
					
				
					error: function(xhr) {
                     var err = JSON.parse(xhr.responseText);
                     $.each(err.errorMessages, function (key, value) {
                        $('input[name=' + key + ']').after('<span class="error">' + value + '</span>');
                    });
                   }
				});
				 }
			
		});
		$(document).on("submit","#edit",function(event){
		
		$('.error').remove();
			var tabl = 	$('#data-table').DataTable();

	        	event.preventDefault();
	        	var check=true;
				var name = $('#type').val();
				var data = tabl.column(1).data();
				 data.each(function (value) {
				     if(value==name){
				    	 check= false;
				    	 $('#type').val('');
				    	 $(".modal-title").html("already exit");
				    	 return false;	 
				     }
				     
				 });
				 if(check){
					 
					var id= $(".rowid").attr("id");
					
					console.log(id);
				    $.ajax({
					type: "POST",
					
					url: url+"/save",
					data : $('form[name=companyForm]').serialize(),
					cache: false,
					success: function(result) {
						
                       var msg='<div class="alert alert-primary" style="width:100%" role="alert">Updated successfully </div>'
						$("#msg").after(msg).fadeIn().fadeOut(3000, function() {
							$(".alert").remove();
							});						
							  var editButton='<button class="btn btn-success btn-xs"  onclick="javascript:editMaster(event,' + result.id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>  </button>&nbsp;|&nbsp;';
						  var deleteButton='<button class="btn btn-danger btn-xs delete" onclick="deleteMaster(event,' + result.id + ')"><i class="fa fa-trash-o" aria-hidden="true"></i> </button>';
						  $("#myModal").modal('hide');	
                           var newData=[tablerow[0],result[key],editButton+" "+ deleteButton];
				           tabl.row( id ).data( newData ).draw(false);
	                    //  $('#data-table').dataTable().fnUpdate([tablerow[0],result[key],editButton+" "+ deleteButton],id,undefined,false);       
					},
					error: function(xhr) {
                     var err = JSON.parse(xhr.responseText);
                     $.each(err.errorMessages, function (key, value) {
                        $('input[name=' + key + ']').after('<span class="error">' + value + '</span>');
                    });
                   }
					
				});
				 }
			
 
  
		});