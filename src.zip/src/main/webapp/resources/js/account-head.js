$(document).ready(function(){
	
	
    	var tab= $('#accountHeadList').DataTable();
    	getAccountHeadList(tab);
         tab.clear().draw();
          window.getDataTable = function() {
		        return tab;
 }
          
          $(document).on("submit","#accountHeadForm",function(event){
        	  
        	 
        	  event.preventDefault();
        	  var data=$("#accountHeadForm").serialize();
				console.log(data);
			    	$.ajax({
			    		 
			    		 url: "add",
		                 type: 'POST',
		               
		                   data:data,

		                     success: function (data) {
		                         console.log(data);
		                         $("#close-button").click();
		                     	
		                    		$(".msg").addClass("alert alert-success").text(data.statusMessage).fadeTo(2000, 500).slideUp(500, function() {
						                   $('.msg').slideUp(500);
				                       });
		                     	window.getAccountHeadList(window.getDataTable().clear());
			                
		                     },
		                     error: function (jqXHR, textStatus, errorThrown) {
		                    	 console.log("error")
		                     }
			    	});
			})
});

	function getAccountHeadList(table){
		 
			var tab = table;
			var type="";
			$.getJSON("jlist", function(json) {
				console.log(json)
				for (var i = 0; i < json.length; i++) { 
					var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="updateAccountHead(' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteAccountHead(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
					if(json[i].type==-1)
						type="Debit"
					else if(json[i].type==1)
						type="Credit"
					tab.row.add( [
						    i+1,
				            json[i].name,
				            type,
				           json[i].code,
				           
				           
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				}	
			});
			
			

}
	

	  function deleteAccountHead(id,btn){
		if(confirm("are you sure you want to delete record ??")==true){

			 $.ajax({
		          url: 'delete/'+id,
		          method: 'GET',
		          success: function (data) {
	                  console.log(data)
		        	
	                  $(btn).closest("tr").remove();
	                 
	                
	                  $(".msg").addClass("alert alert-success").text(data).fadeTo(2000, 500).slideUp(500, function() {
		                   $('.msg').slideUp(500);
	                  });
	                  //$(".alert").children("p").text(data);
		          },
		          error: function (jqXHR, textStatus, errorThrown) {
		              
		         	 var json = JSON.parse(JSON.stringify(jqXHR));
		              console.log(json);
		              console.log("response textStatus " + textStatus);
		              console.log("response jqXHR " + jqXHR);
		              console.log("response errorThrown " + errorThrown);
		          }
		      })

			}
		else{
	          alert("your record is safe now!!");
			}
	     

	  }
	  
	  
	  function updateAccountHead(id)
	  {
		 
		  $.getJSON(""+id, function(json){
			  $("#myModal").modal('show');
			 $("#code").val(json.code);
			 $("#name").val(json.name);
			 $("#type").val(json.type)
			  $("#id").val(json.id)
			
					 
		  })
		  
	  }
	
	  function create(){
		
		  $("#myModal").modal('show');
			
		  $("#code").val('');
			 $("#name").val('');
			 $("#type").val('')
			  $("#id").val('')
			
	  }