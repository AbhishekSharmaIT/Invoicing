if (window.jQuery) { 
	 
       $(document).ready(function(){
    	var tab= $('#jobopeningTable').DataTable();
         getJobOpeningList(tab);
         tab.clear().draw();
          window.getDataTable = function() {
		        return tab;
		    }
		    
	  });  
	 
 function addJobOpening() {
        
		$('.modal-body').load("new",function(){
			$('#myModal').modal({show:true});
		});
  }


  function updateJobOpening(id) {
      console.log(id)
		$('.modal-body').load("update/"+id,function(){
			$('#myModal').modal({show:true});
		});
}

function getJobOpeningList(table){

			var tab = table;
			$.getJSON("jlist", function(json) {
				for (var i = 0; i < json.length; i++) { 
					var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="javascript:updateJobOpening(' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteJobOpening(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
					 tab.row.add( [
						    i+1,
				            json[i].name,
			                json[i].minExp,
			                json[i].maxExp,
			                json[i].minSalary,
			                json[i].maxSalary,
			                json[i].description,
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				}	
			});
			


			}

    	   $("#add_jobopening").validate({
			
           rules: { 
        	   name: {
        		   required: true 
        	   },
        	   minExp: {
        		   required: true 
        	   },
        	    maxExp: {
        		   required: true 
        	   },
        	    minSalary: {
        		   required: true 
        	   },
        	    maxSalary: {
        		   required: true 
        	   },
        	   
			    },
			  
			    messages: {
			       name: "First Name is required",
			       minExp:"Minimum Experience is required",
			       maxExp:"Maximum Experience is required",
			       minSalary:"Minimum Salary is required",
			       maxSalary:"Maximum Salary is required",
			      
			    },
			  
			    submitHandler: function (form) {
			    	 $.ajax({
			      		 url: 'add',
			      		 type: 'GET',
			      		 data:$("#add_jobopening").serialize(),
			      		 success: function(data) {
					     		 
			      			$("#myModal .close").click();
			      			window.getJobOpeningList(window.getDataTable().clear());
			      		$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });
		                     	
								
								 
			      		 
			      		 },error: function (jqXHR, textStatus, errorThrown) {
			      		 var json = JSON.parse(JSON.stringify(jqXHR))
			      		 console.log(json);
			      		 console.log("response textStatus " + textStatus);
			      		 console.log("response jqXHR " + jqXHR);
			      		 console.log("response errorThrown " + errorThrown);
			      		 }
			      		 })
		            
		         }
  
			 }); 
            
    
        

  function deleteJobOpening(id,btn){
	if(confirm("are you sure you want to delete record ??")==true){

		 $.ajax({
	          url: 'delete/'+id,
	          method: 'GET',
	          success: function (data) {
                  console.log(data)
	        	
                  $(btn).closest("tr").remove();
                 
                
                 	$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });
                  $(".alert").children("p").text(data);
	          },
	          error: function (jqXHR, textStatus, errorThrown) {
	              
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              console.log(json);
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	      })

		}
	else{
          alert("your record is safe now!!");
		}
     

  }


   } 




