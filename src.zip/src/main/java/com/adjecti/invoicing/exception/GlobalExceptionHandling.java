package com.adjecti.invoicing.exception;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.adjecti.invoicing.controller.AddressTypeController;
import com.adjecti.invoicing.controller.BillingTypeController;
import com.adjecti.invoicing.controller.CompanyController;
import com.adjecti.invoicing.controller.CountryController;
import com.adjecti.invoicing.controller.CurrencyController;
import com.adjecti.invoicing.controller.PaymentModeController;
import com.adjecti.invoicing.controller.TechnologyController;
import com.adjecti.invoicing.response.ValidationResponse;

@ControllerAdvice(assignableTypes = {BillingTypeController.class,TechnologyController.class,CurrencyController.class,CompanyController.class,AddressTypeController.class,PaymentModeController.class,CountryController.class,})
public class GlobalExceptionHandling {

	@Autowired 
	private ValidationResponse response;
	
	@ExceptionHandler(BindException.class)
    public ResponseEntity<?> validationError(BindException ex){																	
	 Map<String, String> errors = ex.getBindingResult().getFieldErrors().stream()
                 .collect(
                         Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage)
                 );
         response.setValidated(false);
         response.setErrorMessages(errors);
	   return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
		
		
	 
 }

}
