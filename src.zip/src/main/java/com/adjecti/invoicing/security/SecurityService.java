package com.adjecti.invoicing.security;

public interface SecurityService {
	String findLoggedInUsername();

	void autoLogin(String username, String password);
}
