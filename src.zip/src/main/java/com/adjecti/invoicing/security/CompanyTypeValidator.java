package com.adjecti.invoicing.security;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.adjecti.invoicing.dto.CompanyTypeDto;


@Component
public class CompanyTypeValidator implements Validator{
	
	
	@Override
	public boolean supports(Class<?> clazz) {
		return CompanyTypeDto.class.equals(clazz);
	}

	@Override
	public void validate(Object company, Errors errors) {
		
		CompanyTypeDto companyTypeDto = (CompanyTypeDto)company;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "NotEmpty");
		
		if(companyTypeDto.getName().length()<2 || companyTypeDto.getName().length() > 30) {
			errors.rejectValue("name", "Size.company.name");
		}
		
	}

}
