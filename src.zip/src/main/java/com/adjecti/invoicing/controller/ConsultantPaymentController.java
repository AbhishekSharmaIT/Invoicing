package com.adjecti.invoicing.controller;

import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.dto.ClientDto;
import com.adjecti.invoicing.dto.ConsultantInvoicingDto;
import com.adjecti.invoicing.dto.ConsultantPaymentDto;
import com.adjecti.invoicing.dto.InvoiceDto;
import com.adjecti.invoicing.dto.PaymentModeDto;
import com.adjecti.invoicing.dto.TaxDto;
import com.adjecti.invoicing.service.ConsultantInvoicingService;
import com.adjecti.invoicing.service.ConsultantPaymentService;

import com.adjecti.invoicing.service.PaymentModeService;
@Controller
@RequestMapping("/ConsultantPayment")
public class ConsultantPaymentController {
    @Autowired
	private PaymentModeService paymentmodeservice;
    @Autowired
	private ConsultantInvoicingService consultantinvoicingservice;
    @Autowired
    private ConsultantPaymentService consultantpaymentservice;
    
    
    
    @RequestMapping("/list")
	public String getProject(Model model) {
		List<ConsultantPaymentDto>ConsultantPayment=consultantpaymentservice.getConsultantPayment();
		model.addAttribute("ConsultantPayment",ConsultantPayment);
		return "ConsultantPaymentList";
	}
    @GetMapping("/jlist")
	@ResponseBody
	public List<ConsultantPaymentDto> JConsultantPaymentList() {
    	List<ConsultantPaymentDto>ConsultantPayment=consultantpaymentservice.getConsultantPayment();
		
		return ConsultantPayment;
	}
    
    
    @RequestMapping("/new")
	public String getNewProject(Model model) {
    	
    	List<ConsultantPaymentDto>ConsultantPayment=consultantpaymentservice.getConsultantPayment();
		List<PaymentModeDto>paymentmode= paymentmodeservice.getAllPayment();
		List<ConsultantInvoicingDto>invoicedto=consultantinvoicingservice.findAll();
		model.addAttribute("paymentmode",paymentmode);
		model.addAttribute("invoicedto",invoicedto);
		model.addAttribute("ConsultantPayment",ConsultantPayment); 
		model.addAttribute("consultantpayment",new ConsultantPaymentDto());
		return "newConsultantPayment";
	}
        
    @RequestMapping("/delete/{id}") 
    @ResponseBody
	  public ConsultantPaymentResponse delete(@PathVariable("id") int id) {		
    	consultantpaymentservice.delete(id);		  
    	return new ConsultantPaymentResponse(null,"Sucessfully Deleted Consultant Payment...");
	  }
	 
    @RequestMapping(value = "/add", method = { RequestMethod.GET, RequestMethod.POST }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ConsultantPaymentResponse saveProject(@Valid @ModelAttribute("consultantpayment")  ConsultantPaymentDto consultantpaymentdto,BindingResult result) {
		System.out.println(consultantpaymentdto);
    	ConsultantPaymentResponse consultantpaymentresponse=new ConsultantPaymentResponse();
		consultantpaymentservice.save(consultantpaymentdto);
		if(consultantpaymentdto.getId()>0) {
		
		return new ConsultantPaymentResponse(null,"Sucessfully Updated Consultant Payment...");
		}
		else {
			return new ConsultantPaymentResponse(null,"Sucessfully Saved Consultant Payment...");
		}		
	}
    	
    @RequestMapping("/update/{id}")
    public String clientUpdate(@PathVariable("id") int id,Model model) {    	
    	List<ConsultantPaymentDto>ConsultantPayment=consultantpaymentservice.getConsultantPayment();
		List<PaymentModeDto>paymentmode= paymentmodeservice.getAllPayment();
		List<ConsultantInvoicingDto>invoicedto=consultantinvoicingservice.findAll();
		model.addAttribute("paymentmode",paymentmode);
		model.addAttribute("invoicedto",invoicedto);
		model.addAttribute("ConsultantPayment",ConsultantPayment);
		ConsultantPaymentDto consultantpayment = consultantpaymentservice.getConsultantPayment(id);		
    	model.addAttribute("consultantpayment", consultantpayment);    	
    	return "newConsultantPayment";
    }
    
    @RequestMapping("/addPayment")
    public String addConsultantPayment(@RequestParam("id") int id,Model model) {
    	System.out.println(id);
		List<PaymentModeDto>paymentmode= paymentmodeservice.getAllPayment();
		model.addAttribute("paymentmode",paymentmode);
		ConsultantInvoicingDto invoicedto=consultantinvoicingservice.findByid(id);
		model.addAttribute("invoicedto",invoicedto);
		System.out.println(invoicedto);
		return "getConsultantPayment";
    }
    
  //  @RequestMapping("/updateproject")
  // 	@Transactional
   //	public String updateProject(@Valid @ModelAttribute("consultantpayment") ConsultantPaymentDto consultantpaymentdto,BindingResult result) {
   		
   		
    //   	consultantpaymentservice.save(consultantpaymentdto);
   		
     //  	 return "redirect:/ConsultantPayment/list";
   //	}
    
    
    
    private class  ConsultantPaymentResponse {
		private   ConsultantPaymentDto consultantpaymentDto;
		private String msg;
		public ConsultantPaymentResponse() {
			
		}
		public ConsultantPaymentResponse(ConsultantPaymentDto consultantpaymentDto, String msg) {
			
			this.consultantpaymentDto = consultantpaymentDto;
			this.msg = msg;
		}
		public ConsultantPaymentDto getConsultantpaymentDto() {
			return consultantpaymentDto;
		}
		public void setConsultantpaymentDto(ConsultantPaymentDto consultantpaymentDto) {
			this.consultantpaymentDto = consultantpaymentDto;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		
    }
    
}
