package com.adjecti.invoicing.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.adjecti.invoicing.dto.ClientDto;
import com.adjecti.invoicing.dto.UtilityTypeDto;
import com.adjecti.invoicing.response.Response;
import com.adjecti.invoicing.service.UtilityService;

@Controller
@RequestMapping("/utilityType")
public class UtilityTypeController {
	@Autowired
	private UtilityService utilityservice;
	

	@GetMapping("/list")
	public ModelAndView utilityTypeList() {

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("UtilityType");
		//List<UtilityTypeDto> utilityTypeDto = utilityservice.getUtilityType();
		//modelAndView.addObject("utilityTypeDto", utilityTypeDto);
		return modelAndView;
	}

	@GetMapping("/jlist")
	@ResponseBody
	public ResponseEntity<List<UtilityTypeDto>> getList() {
		
		return new ResponseEntity<List<UtilityTypeDto>>(utilityservice.getUtilityTypes(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	@ResponseBody
	public ResponseEntity<UtilityTypeDto> getById(@PathVariable Integer id) {
		return new ResponseEntity<UtilityTypeDto>(utilityservice.getUtilityType(id), HttpStatus.OK);
	}

	@PostMapping("/add")
	@ResponseBody
	public ResponseEntity<?> saveOrUpdateBillingType( @Valid @ModelAttribute("utilityTypeDto")  UtilityTypeDto utilityTypeDto,BindingResult result) {
		UtilityTypeDto save = utilityservice.save(utilityTypeDto);
		System.out.println(save);
		Response response=new Response();
          if (utilityTypeDto.getId() > 0) {
			
			response.setStatusMessage("utility payment  has been Updated Successfully!!");
		 }
		else 
			response.setStatusMessage("utility payment  has been Added Successfully!!");
		return new ResponseEntity<>(response,HttpStatus.OK);
		
		
	}
	@GetMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable String id) {
		System.out.println(id);
		utilityservice.delete(Integer.parseInt(id));
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	
	
	
}
