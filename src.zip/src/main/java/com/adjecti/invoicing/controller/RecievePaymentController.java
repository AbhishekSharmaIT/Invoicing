
package com.adjecti.invoicing.controller;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.dto.ClientDto;
import com.adjecti.invoicing.dto.InvoiceDto;

import com.adjecti.invoicing.dto.PaymentModeDto;
import com.adjecti.invoicing.dto.RecievePaymentDto;
import com.adjecti.invoicing.model.Invoice;
import com.adjecti.invoicing.service.ClientService;
import com.adjecti.invoicing.service.InvoiceService;

import com.adjecti.invoicing.service.PaymentModeService;
import com.adjecti.invoicing.service.RecievePaymentService;

@Controller
@RequestMapping("/RecievePayment")
public class RecievePaymentController {
	@Autowired
	private RecievePaymentService recievepaymentservice;

	@Autowired
	private ClientService clientservice;
	
	@Autowired
	private InvoiceService invoiceservice;

	@Autowired
	private PaymentModeService paymentmodeservice;
	
	@Autowired
	private ModelMapper mapper;



	@RequestMapping("/list")
	public String getRecievePaymentList(Model model) {
		List<RecievePaymentDto> recievepayment = recievepaymentservice.getRecievePayment();
		model.addAttribute("recievepayment", recievepayment);
		return "recievepayment-list";
	}

	@GetMapping("/jlist")
	@ResponseBody
	public List<RecievePaymentDto> JRecievePaymentList() {
		List<RecievePaymentDto> recievepayment = recievepaymentservice.getRecievePayment();
		
		List<RecievePaymentDto> recievepaymentDto=new ArrayList<>();
		for( RecievePaymentDto recievepaymentdto:recievepayment) {
			recievepaymentdto.getInvoice().setTaxItems(null);
			recievepaymentdto.getInvoice().setPurchaseOrder(null);
			recievepaymentdto.getInvoice().setInvoiceItems(null);
			recievepaymentdto.getInvoice().getClient().setTax(null);
			recievepaymentdto.getInvoice().getClient().setPurchaseOrders(null);
			recievepaymentdto.getInvoice().getClient().setContact(null);
			recievepaymentdto.getInvoice().getClient().setCompany(null);
			recievepaymentdto.getClient().setTax(null);
			recievepaymentdto.getClient().setPurchaseOrders(null);
			recievepaymentdto.getClient().setContact(null);
			recievepaymentdto.getClient().setCompany(null);
			recievepaymentDto.add(recievepaymentdto);
		}
		
		return recievepaymentDto;
	}

	
	
	@RequestMapping("/new")
	public String getNewRecievePayment(Model model) {

		
		List<ClientDto> clientdto = clientservice.getClients();
		List<InvoiceDto> invoicedto = invoiceservice.findAll();
		List<PaymentModeDto> paymentmodedto = paymentmodeservice.getAllPayment();
		
		model.addAttribute("paymentmodedto", paymentmodedto);
		model.addAttribute("clientdto", clientdto);
		model.addAttribute("invoicedto", invoicedto);
		model.addAttribute("recievepayment", new RecievePaymentDto());
		return "recievepayment-form";
	}

	@RequestMapping("/create")
	public String createPayment(@RequestParam("invoiceId") int theInvoiceId,Model model) {
		
       List<PaymentModeDto> paymentmodedto = paymentmodeservice.getAllPayment();
		model.addAttribute("paymentmodedto", paymentmodedto);
		
		
		InvoiceDto invoicedto=invoiceservice.findById(theInvoiceId);
		model.addAttribute("invoice", invoicedto);
		
		 Invoice invoice = mapper.map(invoicedto, Invoice.class);
		 RecievePaymentDto recievePaymentDto =new RecievePaymentDto();

		 recievePaymentDto.setPayableTotal(invoice.getGrandTotal());
		 recievePaymentDto.setAmountReceived(invoice.getSubTotal());
		 recievePaymentDto.setBalanceDue(invoice.getBalanceDue());
		 recievePaymentDto.setAmountPaid(invoice.getAdvancePaid());
		model.addAttribute("recievepayment", recievePaymentDto);
		return "create-payment";
	}
	
	@RequestMapping("/delete/{id}")
	@ResponseBody
	public RecievePaymentResponse delete(@PathVariable("id") int id) {
		recievepaymentservice.delete(id);
		return new RecievePaymentResponse(null, "Sucessfully Deleted RecievePayment...");
	}

	
	@RequestMapping(value = "/add", method = { RequestMethod.GET, RequestMethod.POST }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public RecievePaymentResponse saveRecievePayment(
			@Valid @ModelAttribute("recievepayment") RecievePaymentDto recievepaymentdto, BindingResult result) {
		
		recievepaymentservice.save(recievepaymentdto);
		if (recievepaymentdto.getId() > 0) {

			return new RecievePaymentResponse(null, "Sucessfully Updated RecievePayment...");
		} else {
			return new RecievePaymentResponse(null, "Sucessfully Saved RecievePayment...");
		}
	}

	
	
	@RequestMapping("/update/{id}")
	public String recievePaymentUpdate(@PathVariable("id") int id, Model model) {

		
		List<ClientDto> clientdto = clientservice.getClients();
		List<InvoiceDto> invoicedto = invoiceservice.findAll();
		List<PaymentModeDto> paymentmodedto = paymentmodeservice.getAllPayment();
		
		model.addAttribute("paymentmodedto", paymentmodedto);
		model.addAttribute("clientdto", clientdto);
		model.addAttribute("invoicedto", invoicedto);

		RecievePaymentDto recievepaymentdto = recievepaymentservice.getRecievePayment(id);
		model.addAttribute("recievepayment", recievepaymentdto);
		return "recievepayment-form";
	}

	
	@GetMapping(value = "/getClientInvoiceNo", produces = "application/json")
	public @ResponseBody List<InvoiceDto> findClientInvoiceById(@RequestParam(value = "clientId") int id) {
		
		List<InvoiceDto> invoicedto = invoiceservice.findAll();
		List<InvoiceDto> invoiceDto = new ArrayList<>();
		for(InvoiceDto invoice:invoicedto) {
			if(id==invoice.getClient().getId()) {
				invoice.setTaxItems(null);
				invoice.setPurchaseOrder(null);
				invoice.setInvoiceItems(null);
				invoice.setClient(null);
				invoiceDto.add(invoice);
			}
		}
		System.out.println("invoiceDto"+invoiceDto);
		return invoiceDto;
	}
	
	
	@GetMapping(value ="/getInvoiceNo", produces = "application/json")
	public @ResponseBody InvoiceDto findInvoiceById(@RequestParam(value = "invoiceId") int id) {
	
		InvoiceDto invoicedto = invoiceservice.findById(id);
		InvoiceDto invoice= new InvoiceDto();
		invoice.setBalanceDue(invoicedto.getBalanceDue());
		invoice.setSubTotal(invoicedto.getSubTotal());
		invoice.setGrandTotal(invoicedto.getGrandTotal());
		invoice.setAdvancePaid(invoicedto.getAdvancePaid());
		invoice.setCurrency(invoicedto.getCurrency());
		return invoice;
	}
	
	@RequestMapping(value = "/addCreatePayment", method = { RequestMethod.GET, RequestMethod.POST })
	
	public String saveCreatePayment(
			@Valid @ModelAttribute("recievepayment") RecievePaymentDto recievepaymentdto, BindingResult result) {
 System.out.println(recievepaymentdto);
		
		recievepaymentservice.save(recievepaymentdto);
		return "redirect:/invoice/list";
	}
	
	private class RecievePaymentResponse {
		private RecievePaymentDto recievepaymentDto;
		private String msg;

		public RecievePaymentResponse() {

		}

		public RecievePaymentResponse(RecievePaymentDto recievepaymentDto, String msg) {

			this.recievepaymentDto = recievepaymentDto;
			this.msg = msg;
		}

		public RecievePaymentDto getRecievePaymentDto() {
			return recievepaymentDto;
		}

		public void setRecievePaymentDto(RecievePaymentDto recievepaymentDto) {
			this.recievepaymentDto = recievepaymentDto;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

	}

}
