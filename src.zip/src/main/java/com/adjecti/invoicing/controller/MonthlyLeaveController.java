package com.adjecti.invoicing.controller;

import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.dto.MonthlyLeaveDto;
import com.adjecti.invoicing.dto.PeopleDto;
import com.adjecti.invoicing.service.MonthlyLeaveService;
import com.adjecti.invoicing.service.PeopleService;


@Controller
@RequestMapping("/monthlyleave")
public class MonthlyLeaveController {
    @Autowired
	private MonthlyLeaveService   monthlyleaveservice;
    
    @Autowired
    private PeopleService peopleservice;
    
    
    
    @RequestMapping("/list")
	public String getMonthlyLeave(Model model) {
		List<MonthlyLeaveDto> monthlyleave= monthlyleaveservice.getMonthlyLeave();
		model.addAttribute("monthlyleave", monthlyleave);
		return "monthlyleave-list";
	}
    @GetMapping("/jlist")
	@ResponseBody
	public List<MonthlyLeaveDto> JMonthlyLeaveList() {
    	List<MonthlyLeaveDto> monthlyleave= monthlyleaveservice.getMonthlyLeave();
		
		return  monthlyleave;
	}
    
    
    @RequestMapping("/new")
	public String getNewMonthlyLeave(Model model) {
    	
    	List<PeopleDto>peopledto=peopleservice.getPeople();
		List<MonthlyLeaveDto> monthlyleavedto=  monthlyleaveservice.getMonthlyLeave();
		model.addAttribute("monthlyleave", monthlyleavedto);
		model.addAttribute("peopledto",peopledto); 
		model.addAttribute("monthlyleavedto",new MonthlyLeaveDto());
		return "monthlyleave-form";
	}
        
    @RequestMapping("/delete/{id}") 
    @ResponseBody
	  public MonthlyLeaveResponse delete(@PathVariable("id") int id) {		
    	 monthlyleaveservice.delete(id);		  
    	return new MonthlyLeaveResponse(null,"Sucessfully Deleted People...");
	  }
	 
    @RequestMapping(value = "/add", method = { RequestMethod.GET, RequestMethod.POST }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public MonthlyLeaveResponse saveMonthlyLeave(@Valid @ModelAttribute("people")  MonthlyLeaveDto  monthlyleavedto,BindingResult result) {
		
    	MonthlyLeaveResponse monthlyleaveresponse=new MonthlyLeaveResponse();
    	 monthlyleaveservice.save( monthlyleavedto);
		if( monthlyleavedto.getId()>0) {
		
		return new MonthlyLeaveResponse(null,"Sucessfully Updated  MonthlyLeave...");
		}
		else {
			return new MonthlyLeaveResponse(null,"Sucessfully Saved  MonthlyLeave...");
		}		
	}
    	
    @RequestMapping("/update/{id}")
    public String  monthlyleaveUpdate(@PathVariable("id") int id,Model model) {    	
    	
		List<PeopleDto>people= peopleservice.getPeople();
		
		model.addAttribute("peopledto",people);
		
		 MonthlyLeaveDto  monthlyleavedto =  monthlyleaveservice.getMonthlyLeave(id);		
   	model.addAttribute("monthlyleavedto",  monthlyleavedto);    	
    	return "monthlyleave-form";
    }
    
    @RequestMapping("/addMonthlyLeave")
    public String addMonthlyLeave(@RequestParam("id") int id,Model model) {
    	
		List<PeopleDto> people= peopleservice.getPeople();
		model.addAttribute("people",people);
		
		return "people-form";
    }
    
  
    
    
    private class MonthlyLeaveResponse {
		private   MonthlyLeaveDto peopleDto;
		private String msg;
		
		public MonthlyLeaveResponse() {
			
		}
		public MonthlyLeaveResponse(MonthlyLeaveDto peopleDto, String msg) {
			
			this.peopleDto = peopleDto;
			this.msg = msg;
		}
		public MonthlyLeaveDto getPeopleDto() {
			return peopleDto;
		}
		public void setPeopleDto(MonthlyLeaveDto peopleDto) {
			this.peopleDto = peopleDto;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		
    }
    
}

