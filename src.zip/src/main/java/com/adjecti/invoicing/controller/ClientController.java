package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.adjecti.invoicing.dto.AddressTypeDto;
import com.adjecti.invoicing.dto.ClientDto;
import com.adjecti.invoicing.dto.CompanyTypeDto;
import com.adjecti.invoicing.dto.CountryDto;
import com.adjecti.invoicing.dto.TaxDto;
import com.adjecti.invoicing.helper.FileUploadHelper;
import com.adjecti.invoicing.response.Response;
import com.adjecti.invoicing.service.AddressTypeService;
import com.adjecti.invoicing.service.ClientService;
import com.adjecti.invoicing.service.CompanyTypeService;
import com.adjecti.invoicing.service.CountryService;
import com.adjecti.invoicing.service.TaxService;

@Controller
@RequestMapping("/client")
public class ClientController {

	@Autowired

	private CompanyTypeService companyTypeService;

	@Autowired
	private TaxService taxService;

	@Autowired
	private AddressTypeService addressTypeSerive;

	@Autowired
	private CountryService countryService;

	@Autowired
	private ClientService clientService;

	@Autowired
	private FileUploadHelper fileUploadHelper;

	/*
	 * // save data into database
	 * 
	 * @RequestMapping("/process") public String
	 * processClientForm(@Valid @ModelAttribute("client") ClientDto
	 * client,BindingResult result,MultipartFile file,Model model,HttpSession
	 * session) {
	 * 
	 * if(client.getId()!=0) { session.setAttribute("msg",
	 * "Client has been updated successfully!!"); } else {
	 * session.setAttribute("msg", "Client  has been added succeccfully");
	 * 
	 * } try {
	 * 
	 * boolean uploadClientFile = fileUploadHelper.uploadClientFile(file);
	 * System.out.println(uploadClientFile );
	 * 
	 * } catch(Exception e) { System.out.println("file not found ");
	 * 
	 * }
	 * 
	 * clientService.createClient(client);
	 * 
	 * return "redirect:/client/list";
	 * 
	 * }
	 */

	@RequestMapping(value = "/form")
	public ModelAndView clientForm() {

		ModelAndView modelAndView = new ModelAndView();

		List<CompanyTypeDto> companyTypes = companyTypeService.getCompanyList();
		List<TaxDto> taxes = taxService.findAll();
		List<AddressTypeDto> addressTypes = addressTypeSerive.getAddressTypes();
		List<CountryDto> countries = countryService.getCountryList();

		modelAndView.addObject("companyTypes", companyTypes);
		modelAndView.addObject("taxes", taxes);
		modelAndView.addObject("addressTypes", addressTypes);
		modelAndView.addObject("client", new ClientDto());
		modelAndView.addObject("countries", countries);

		modelAndView.setViewName("client_form");
		return modelAndView;
	}

	@GetMapping("/list")
	public ModelAndView ClientList() {

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("client_list");
		List<ClientDto> clients = clientService.getClients();
		modelAndView.addObject("clients", clients);
		return modelAndView;
	}

	@GetMapping("/jlist")
	@ResponseBody
	public List<ClientDto> JClientList() {
		List<ClientDto> clients = clientService.getClients();
		clients.forEach(client -> {
			client.setPurchaseOrders(null);
			client.setTax(null);
		});
		return clients;
	}

	@GetMapping("/get/{id}")
	@ResponseBody
	public ClientDto getClient(@PathVariable int id) {

		return clientService.getClient(id);
	}

	@RequestMapping("/delete/{id}")
	@ResponseBody
	public String clientDelete(@PathVariable("id") int id) {

		clientService.deleteClient(id);
		return "Client has been deleted successfully!!";
	}

	@RequestMapping(value = "/update/{id}", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView clientUpdate(@PathVariable("id") int id) {

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("client_form");
		List<CompanyTypeDto> companyTypes = companyTypeService.getCompanyList();
		List<TaxDto> taxes = taxService.findAll();
        List<AddressTypeDto> addressTypes = addressTypeSerive.getAddressTypes();
		List<CountryDto> countries = countryService.getCountryList();
        modelAndView.addObject("companyTypes", companyTypes);
		modelAndView.addObject("taxes", taxes);
		modelAndView.addObject("addressTypes", addressTypes);
		modelAndView.addObject("countries", countries);
		ClientDto client = clientService.getClient(id);
		modelAndView.addObject("client", client);

		return modelAndView;
	}

	@RequestMapping(value = "/add", method = { RequestMethod.POST, RequestMethod.GET }, produces = {
			MediaType.APPLICATION_JSON_VALUE })

	public @ResponseBody ResponseEntity<?> clientSave( @Valid @ModelAttribute("client") ClientDto client,
			BindingResult result) {
	    
		
		List<Response> responseList = new ArrayList<>();
		if (result.hasErrors()) {
			System.out.println("inside  error");
			List<FieldError> fieldErrors = result.getFieldErrors();
			System.out.println(fieldErrors);
			for (FieldError temp : fieldErrors) {
				String s=temp.getField();
				String field = s.substring(s.lastIndexOf(".")+1);
				System.out.println(field);
                  System.out.println();
				responseList.add(new Response(field, temp.getDefaultMessage(), null));
			}

			return new ResponseEntity<>(responseList, HttpStatus.BAD_REQUEST);
		}

		Response response = new Response();

		clientService.createClient(client);
		response.setStatusMessage("Client  has been Added Successfully!!");
		if (client.getId() > 0) {
			response.setStatusMessage("Client has been Updated successfully !!");
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
/*
	
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(CompanyType.class, new CustomPropertyEditor());
    }
*/

}
