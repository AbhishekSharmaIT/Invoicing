package com.adjecti.invoicing.controller;

import java.security.Principal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.adjecti.invoicing.dto.AccountHeadDto;
import com.adjecti.invoicing.dto.DayBookDto;
import com.adjecti.invoicing.model.User;
import com.adjecti.invoicing.response.Response;
import com.adjecti.invoicing.service.AccountHeadService;
import com.adjecti.invoicing.service.DayBookService;
import com.adjecti.invoicing.service.PaymentModeService;
import com.adjecti.invoicing.service.UserService;

@Controller
@RequestMapping("/dayBook")
public class DayBookController {
	
	@Autowired
	DayBookService dayBookService;
	
	@Autowired
	AccountHeadService accountHeadService;
	
	@Autowired
	PaymentModeService paymentModeService;
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value="/form")
	private ModelAndView createDaybook() {
		System.out.println("helloo");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("accountHeads",accountHeadService.getByType(-1));
		modelAndView.addObject("paymentModes", paymentModeService.getAllPayment());
		modelAndView.addObject("dayBook", new DayBookDto());

		modelAndView.setViewName("day-book-form");
		return modelAndView;
	}
	
	
	
	@RequestMapping(value="/add", method = {RequestMethod.POST,RequestMethod.GET}, produces = "application/json")
	@ResponseBody
	private ResponseEntity<?> saveDayBook(@Valid @ModelAttribute("dayBook")DayBookDto dayBook, BindingResult result) {
		System.out.println("add"+dayBook.getCreatedDate());
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	      String username = auth.getName();
	      long userId =userService.findByUsername(username).getId();
	      int user=(int)userId ;
	      dayBook.setUserId(user);
		Response response=new Response();
		dayBookService.createDayBook(dayBook);
		
		
		if (dayBook.getId() > 0) {
			
			response.setStatusMessage("Day Book  has been Updated Successfully!!");
		}
		else 
			response.setStatusMessage("Day Book  has been Added Successfully!!");
		return new ResponseEntity<>(response, HttpStatus.OK);
		
	}
	
	@GetMapping("/list")
	@ResponseBody
	private ModelAndView getDayBook(){
		
	     
		ModelAndView modelAndView=new ModelAndView("day-book-list");
	   
		return modelAndView;
	}

	/*
	 * @GetMapping("/jlist")
	 * 
	 * @ResponseBody private List<DayBookDto> jgetDayBooks(){ return
	 * dayBookService.getDayBooks(); }
	 */
	@GetMapping("/jlist")
	@ResponseBody
	private List<DayBookDto> jgetDayBooks(Principal principal){
		
		
		return dayBookService.getDayBooks();
	}
	
	@GetMapping("/{id}")
	private DayBookDto getDayBook(long id) {
		return dayBookService.getDayBook(id);
	}
	@RequestMapping("/delete/{id}")
	@ResponseBody
	private String deleteDayBook(@PathVariable("id")long id)
	{
		dayBookService.deleteDayBook(id);
		return "Day Book has been deleted successfully!!";	
		
	}
	
	@RequestMapping(value = "/update/{id}", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView dayBookUpdate(@PathVariable("id") long id) {
		System.out.println(id+"update controller");
		ModelAndView modelAndView = new ModelAndView();
		
		DayBookDto dayBook = dayBookService.getDayBook(id);
		System.out.println("controller create date "+dayBook.getCreatedDate());
		modelAndView.addObject("dayBook", dayBook);
		modelAndView.addObject("paymentModes",paymentModeService.getAllPayment());
		modelAndView.addObject("accountHeads",accountHeadService.getByType(Integer.parseInt(dayBook.getDebitCredit())));
		modelAndView.addObject("updateModel","updateModel");
		modelAndView.setViewName("day-book update-form");
		return modelAndView;
	}
	@GetMapping("/TodaysList")
	@ResponseBody
	public List<DayBookDto> getTodaysDayBook(){
		System.out.println(LocalDate.now());
		List<DayBookDto> todaysDayBookList = dayBookService.getTodaysDayBookList(LocalDate.now());
		todaysDayBookList.forEach(a->System.out.println("date "+a.getCreatedDate()));
		return todaysDayBookList;
	}
	@GetMapping("/getDayBookTillDate/{fromDate}/{toDate}")
	@ResponseBody
	public List<DayBookDto>getDayBookTillDate(@PathVariable("fromDate")@DateTimeFormat(pattern = "yyyy-MM-dd")LocalDate fromDate,@PathVariable("toDate")@DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate toDate){
		System.out.println(fromDate +"   "+toDate);
		return dayBookService.getDayBookTillDate(fromDate, toDate);
		
	}
	@GetMapping("/accoountHeads/{type}")
	@ResponseBody
	public List<AccountHeadDto> getAccountHead(@PathVariable("type") int type){
		return accountHeadService.getByType(type);
		
	}
	
	
	@PostMapping("/reconcile")
	public String dayBookReconcile(@RequestParam("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd")LocalDate fromDate) {
		System.out.println("hello to controller");
		dayBookService.reconcile(fromDate);
		return "redirect:list";
	}
	
	@RequestMapping("/reconcile")
	public String dayBookReconcileForm() {
		return "daybook-reconcile";
	}
	
}
