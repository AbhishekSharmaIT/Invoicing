package com.adjecti.invoicing.controller;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Currency;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.adjecti.invoicing.dto.CompanyTypeDto;
import com.adjecti.invoicing.dto.ConsultantDto;
import com.adjecti.invoicing.model.Consultant;
import com.adjecti.invoicing.response.Response;
import com.adjecti.invoicing.service.CompanyTypeService;
import com.adjecti.invoicing.service.ConsultantService;

import javassist.expr.NewArray;


@SuppressWarnings("unused")
@Controller
@RequestMapping("/consultant")
public class ConsultantController {

	@Autowired
	CompanyTypeService companyTypeService;
	
	@Autowired
	private ConsultantService consultantService;
	
	@GetMapping("/list")
	public String getConsultantListView(Model model) {
		//List<ConsultantDto> consultantList = consultantService.findAll();	
	    //System.out.println(consultantDto);
	//model.addAttribute("consultant", consultantList);
		return "consultant";
	}
	
	@RequestMapping(value="/jlist",method = RequestMethod.GET, produces="application/json")
	  public ResponseEntity<List<ConsultantDto>> getConsultantList() {
		//MoneyConverters converter = MoneyConverters.ENGLISH_BANKING_MONEY_VALUE;
       //String money= converter.asWords(new BigDecimal("123456"));
	   // System.out.println(money);
	   // Integer mon=123456798; 
	   // Locale indiaLocale = new Locale("en", "IN");
	   // NumberFormat india  = NumberFormat.getCurrencyInstance(indiaLocale);
	   // System.out.println("India: "  + india.format(mon));		 
	   // Optional<Currency> currency = Currency.getAvailableCurrencies().stream().filter(c -> c.getNumericCode() == 356).findAny();
	  //  System.out.println(currency);
	    try {
	      List<ConsultantDto> consulatnts = consultantService.findAll();
	      if (consulatnts.isEmpty()) {
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	      }
	      return new ResponseEntity<>(consulatnts, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }

	
	@RequestMapping(value="/add", method = RequestMethod.GET, produces = "application/json")
	public String addConsultantView(@ModelAttribute("consultant") ConsultantDto consultantDto,Model model,BindingResult result) {
		List<CompanyTypeDto> companyList=companyTypeService.getCompanyList();
		System.out.println(companyList);	
		model.addAttribute("companyList",companyList);	
		return "consultant-form";
	}
	
	/*@RequestMapping(value="/save", method = {RequestMethod.POST,RequestMethod.GET}, produces = "application/json")
	public @ResponseBody AddConsultantResponse saveConsultant(@Valid @ModelAttribute ConsultantDto consultantDto, BindingResult bindingResult,Model m) {
		System.out.println(consultantDto.getName());
		ConsultantDto consultantDto1=null;
		AddConsultantResponse addConsultantResponse = null ;
		if(consultantDto.getId() == 0) {
			consultantDto1 = this.consultantService.save(consultantDto);
			if(consultantDto1 != null) {addConsultantResponse = new AddConsultantResponse(consultantDto1,"Created, Consultant Successfully!!");}
			else {addConsultantResponse = new AddConsultantResponse(consultantDto1,"Consultant not added!");}
		}
		else {
			consultantDto1 = this.consultantService.save(consultantDto);
			if (consultantDto1 != null) {addConsultantResponse = new AddConsultantResponse(consultantDto1, "Updated, Consultant Successfully!!");	} 
			else {addConsultantResponse = new AddConsultantResponse(consultantDto1, "Consultant not updated");}
		}
		return addConsultantResponse;
	}*/
	@RequestMapping(value="/save", method = {RequestMethod.POST,RequestMethod.GET}, produces = "application/json")
	public @ResponseBody ResponseEntity<?> saveConsultant(@Valid @ModelAttribute ConsultantDto consultantDto, BindingResult bindingResult,Model m) {
		System.out.println(consultantDto.getName());
		List<Response> responseList = new ArrayList<>();
		if (bindingResult.hasErrors()) {
			System.out.println("inside binding result");
			List<FieldError> fieldErrors = bindingResult.getFieldErrors();
			for (FieldError temp : fieldErrors) {
				System.out.println(temp.getField() + "  " + temp.getDefaultMessage());
				responseList.add(new Response(temp.getField(), temp.getDefaultMessage(), null));
			}
			return new ResponseEntity<>(responseList, HttpStatus.BAD_REQUEST);
		}
		
		Response response=new Response();
		this.consultantService.save(consultantDto);
		response.setStatusMessage("Created");
		if(consultantDto.getId()>0) {
			response.setStatusMessage("Updated");
		}
	 return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	
	@RequestMapping("/delete/{id}")
	public @ResponseBody String deleteConsultant(@PathVariable("id") Integer id, Model m,RedirectAttributes redirectAttributes) {
		System.out.println(id);
		this.consultantService.delete(id);
		redirectAttributes.addFlashAttribute("msg", "Successfully Deleted Consultant!!!");
		return "Delete";
	}
	
	/*@PostMapping("/update/{id}")
	public String updateConsultant( @PathVariable("id") Integer id,Model m) {
	        	List<CompanyTypeDto> companyType=companyTypeService.getCompanyList();	
	        	m.addAttribute("companyType",companyType);	
	            ConsultantDto consultantDto = consultantService.findById(id);
	        	m.addAttribute("consultant",consultantDto);
		        return "consultant-form";
	}*/
	
	@GetMapping("/update")
	public String updateConsultantView(@RequestParam("id") int id,Model m) {
	    System.out.println(id);   
	    ConsultantDto consultant = consultantService.findById(id);
	    List<CompanyTypeDto> companyList=companyTypeService.getCompanyList();
	    m.addAttribute("consultant", consultant);
	    m.addAttribute("companyList", companyList);
		return "consultant-form";
	}
	
	/*private class AddConsultantResponse {
		private String msg;
		private ConsultantDto consultantDto;

		public AddConsultantResponse() {
		}

		public AddConsultantResponse(ConsultantDto consultantDto, String msg) {
			this.consultantDto = consultantDto;
			this.msg = msg;
		}

		public ConsultantDto getConsultantDto() {
			return consultantDto;
		}

		public void setConsultantDto(ConsultantDto consultantDto) {
			this.consultantDto = consultantDto;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

	}*/
}
