package com.adjecti.invoicing.controller;

import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.dto.CountryDto;
import com.adjecti.invoicing.dto.PeopleDto;

import com.adjecti.invoicing.service.CountryService;
import com.adjecti.invoicing.service.PeopleService;

import com.adjecti.invoicing.service.PaymentModeService;
@Controller
@RequestMapping("/People")
public class PeopleController {
    @Autowired
	private CountryService countryservice;
    
    @Autowired
    private PeopleService peopleservice;
    
    
    
    @RequestMapping("/list")
	public String getPeople(Model model) {
		List<PeopleDto>people=peopleservice.getPeople();
		model.addAttribute("People",people);
		return "people-list";
	}
    @GetMapping("/jlist")
	@ResponseBody
	public List<PeopleDto> JPeopleList() {
    	List<PeopleDto>people=peopleservice.getPeople();
		
		return people;
	}
    
    
    @RequestMapping("/new")
	public String getNewPeople(Model model) {
    	
    	List<PeopleDto>peopledto=peopleservice.getPeople();
		List<CountryDto>countrydto= countryservice.getCountryList();
		model.addAttribute("country",countrydto);
		model.addAttribute("peopledto",peopledto); 
		model.addAttribute("people",new PeopleDto());
		return "people-form";
	}
        
    @RequestMapping("/delete/{id}") 
    @ResponseBody
	  public PeopleResponse delete(@PathVariable("id") int id) {		
    	peopleservice.delete(id);		  
    	return new PeopleResponse(null,"Sucessfully Deleted People...");
	  }
	 
    @RequestMapping(value = "/add", method = { RequestMethod.GET, RequestMethod.POST }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public PeopleResponse savePeople(@Valid @ModelAttribute("people")  PeopleDto peopledto,BindingResult result) {
		
    	PeopleResponse peopleresponse=new PeopleResponse();
		peopleservice.save(peopledto);
		if(peopledto.getId()>0) {
		
		return new PeopleResponse(null,"Sucessfully Updated People...");
		}
		else {
			return new PeopleResponse(null,"Sucessfully Saved People...");
		}		
	}
    	
    @RequestMapping("/update/{id}")
    public String clientUpdate(@PathVariable("id") int id,Model model) {    	
    	//List<PeopleDto>people=peopleservice.getPeople();
		List<CountryDto>country= countryservice.getCountryList();
		
		model.addAttribute("country",country);
		//model.addAttribute("people",people);
		PeopleDto peopledto = peopleservice.getPeople(id);		
   	model.addAttribute("people", peopledto);    	
    	return "people-form";
    }
    
    @RequestMapping("/addPeople")
    public String addPeople(@RequestParam("id") int id,Model model) {
    	System.out.println(id);
		List<CountryDto>country= countryservice.getCountryList();
		model.addAttribute("country",country);
		
		return "people-form";
    }
    
  //  @RequestMapping("/updateproject")
  // 	@Transactional
   //	public String updateProject(@Valid @ModelAttribute("consultantpayment") ConsultantPaymentDto consultantpaymentdto,BindingResult result) {
   		
   		
    //   	consultantpaymentservice.save(consultantpaymentdto);
   		
     //  	 return "redirect:/ConsultantPayment/list";
   //	}
    
    
    
    private class  PeopleResponse {
		private   PeopleDto peopleDto;
		private String msg;
		
		public PeopleResponse() {
			
		}
		public PeopleResponse(PeopleDto peopleDto, String msg) {
			
			this.peopleDto = peopleDto;
			this.msg = msg;
		}
		public PeopleDto getPeopleDto() {
			return peopleDto;
		}
		public void setPeopleDto(PeopleDto peopleDto) {
			this.peopleDto = peopleDto;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		
    }
    
}
