package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartRequest;

import com.adjecti.invoicing.dto.BillingCycleDto;
import com.adjecti.invoicing.dto.BillingTypeDto;
import com.adjecti.invoicing.dto.ClientDto;
import com.adjecti.invoicing.dto.ClientPurchaseOrderItemDto;
import com.adjecti.invoicing.dto.ProjectDto;
import com.adjecti.invoicing.dto.TechnologyDto;
import com.adjecti.invoicing.helper.FileUploadHelper;
import com.adjecti.invoicing.model.ClientPurchaseOrderItem;
import com.adjecti.invoicing.model.PurchaseOrder;
import com.adjecti.invoicing.response.ValidationResponse;
import com.adjecti.invoicing.dto.PurchaseOrderDto;
import com.adjecti.invoicing.service.BillingCycleService;
import com.adjecti.invoicing.service.BillingTypeService;
import com.adjecti.invoicing.service.ClientPurchaseOrderItemSerice;
import com.adjecti.invoicing.service.ClientService;
import com.adjecti.invoicing.service.ProjectService;
import com.adjecti.invoicing.service.TechnologyService;
import com.adjecti.invoicing.service.PurchaseOrderService;





@Controller
@RequestMapping("/project")
public class ProjectController {
	
@Autowired
private FileUploadHelper fileUploadHelper;
@Autowired
private ProjectService projectservice;
@Autowired
private BillingTypeService billingtypeservice;
@Autowired
private BillingCycleService billingcycleservice;
@Autowired
private ClientService clientservice;
@Autowired
private TechnologyService technologyservice;
@Autowired
private PurchaseOrderService purchaseorderservice;
@Autowired
private ClientPurchaseOrderItemSerice clientPurchaseOrderItemSerice;
@Autowired 
private ValidationResponse response;

	
	@RequestMapping("/list")
	public String getProject(Model model) {
		List<ProjectDto>project=projectservice.getProject();
		System.out.println(project.toString());
		model.addAttribute("project",project);
		return "projectalllist";
	}
	
	@GetMapping("/jlist")
	@ResponseBody
	public List<ProjectDto> JProjectList() {
		List<ProjectDto>project=projectservice.getProject();
		List<ProjectDto>projectlist=new ArrayList<>();
		for(ProjectDto dto:project) {
			dto.getClient().setTax(null);
			dto.getClient().setCompany(null);
			dto.getClient().setPurchaseOrders(null);
			dto.getClient().setContact(null);
			dto.getClient().setAddress(null);
			dto.getPurchaseorder().setClientPurchaseOrderItem(null);
			dto.getPurchaseorder().setClient(null);
			dto.getPurchaseorder().setBillingType(null);
			dto.getPurchaseorder().setBillingCycle(null);
			dto.getPurchaseorder().setProject(null);
			projectlist.add(dto);
		}
		System.out.println("jason"+projectlist.toString());
		return projectlist;
	}
	
	
	
	@RequestMapping("/new")
	public String getNewProject(Model model) {
		
		List<BillingTypeDto>billingtype= billingtypeservice.findAll();
		List<BillingCycleDto>billingcycle=billingcycleservice.getAllBillingCycle();
		List<ClientDto>clientdto= clientservice.getClients();
		List<ClientDto>clientlistdto=new ArrayList<>();
		for(ClientDto temp:clientdto) {
			temp.setTax(null);
			temp.setPurchaseOrders(null);
			temp.setContact(null);
			temp.setCompanyType(null);
			temp.setAddress(null);
			clientlistdto.add(temp);
		}
		List<TechnologyDto> technologydto=technologyservice.findAll();
		List<PurchaseOrderDto>purchaseorderdto=purchaseorderservice.getAllPurchaseOrder();
		List<PurchaseOrderDto>purchaseorderlistdto=new ArrayList<>();
		for(PurchaseOrderDto temp:purchaseorderdto) {
			//temp.setInvoices(null);
			temp.setClientPurchaseOrderItem(null);
			temp.setClient(null);
			temp.setBillingType(null);
			temp.setBillingCycle(null);
			purchaseorderlistdto.add(temp);
			
		}
		
		model.addAttribute("billingtype",billingtype);
		model.addAttribute("billingcycle",billingcycle);
		model.addAttribute("client",clientlistdto);
		model.addAttribute("purchaseorder",purchaseorderlistdto);
		model.addAttribute("technology",technologydto);
		model.addAttribute("project",new ProjectDto());
		
		return "newProjectForm";
	}
	
	
	
	
	@RequestMapping("/delete/{id}") 
    @ResponseBody
	  public ProjectResponse delete(@PathVariable("id") int id) {
		
		  projectservice.delete(id);
		  
		  return new ProjectResponse("Sucessfully Deleted Project...");
	  }
	
	
	@RequestMapping(value="/saveProject")
	public ResponseEntity<?> saveProject(@Valid @ModelAttribute("project") ProjectDto project,BindingResult result,MultipartFile file) {
	
		System.out.println(file.getOriginalFilename());
		try {
			  
			 boolean uploadFile = fileUploadHelper.uploadClientFile(file);
			 System.out.println(uploadFile);
			 
			  }
			  catch(Exception e) {
			  System.out.println("file not found ");
			  
			  }
		if(!result.hasErrors()) {
			System.out.println("hello");
			   Map<String, String> errors = result.getFieldErrors().stream()
	                    .collect(
	                            Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage)
	                    );
	            response.setValidated(false);
	            response.setErrorMessages(errors);
		return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
	            
		}
		
	      
		ProjectResponse response=null;
               if(project.getId()>0) {
			
			response= new ProjectResponse("Sucessfully Updated Project Payment...");
			}
			else {
			response= new ProjectResponse("Sucessfully Saved Project Payment...");
			}
               
               projectservice.save(project,file);
			
		
               return new ResponseEntity<>(HttpStatus.OK);
		
	}
	
	@RequestMapping("/update/{id}") 
	public String updateProject(@PathVariable("id") int id,Model model) {
		List<BillingTypeDto>billingtype= billingtypeservice.findAll();
		List<BillingCycleDto>billingcycle=billingcycleservice.getAllBillingCycle();
		List<PurchaseOrderDto>purchaseorderdto=purchaseorderservice.getAllPurchaseOrder();
		List<ClientDto>clientdto= clientservice.getClients();
		List<TechnologyDto> technologydto=technologyservice.findAll();
		ProjectDto project=projectservice.getProject(id);
		
		model.addAttribute("billingtype",billingtype);
		model.addAttribute("billingcycle",billingcycle);
		model.addAttribute("client",clientdto);
		model.addAttribute("purchaseorder",purchaseorderdto);
		model.addAttribute("technology",technologydto);
	
		model.addAttribute("project",project);
		return "newProjectForm";
	}
	@GetMapping(value = "/getClientPurchaseOrder", produces = "application/json")
	@ResponseBody
	public  List<PurchaseOrderDto> findClientPurchaseOrderById(@RequestParam(value = "clientId") int id) {
		

		List<PurchaseOrderDto> purchaseOrderDto = purchaseorderservice.getAllPurchaseOrder();
		List<PurchaseOrderDto> newPurchaseOrder = new ArrayList<>();
		for (PurchaseOrderDto purchaseorder : purchaseOrderDto) {
			if(purchaseorder.getClient().getId()==id) {
			purchaseorder.setClient(null);
			purchaseorder.setClientPurchaseOrderItem(null);
			purchaseorder.setBillingType(null);
			purchaseorder.setBillingCycle(null);
			newPurchaseOrder.add(purchaseorder);
			}
		}
		
		
		return newPurchaseOrder;
	}

	
	
	
	 private class  ProjectResponse {
			
			private String msg;
			public ProjectResponse() {
				
			}
			public ProjectResponse( String msg) {
				
				
				this.msg = msg;
			}
			
			public String getMsg() {
				return msg;
			}
			public void setMsg(String msg) {
				this.msg = msg;
			}
			
	    }
}
