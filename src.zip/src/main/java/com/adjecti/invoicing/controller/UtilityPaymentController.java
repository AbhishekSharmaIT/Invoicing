package com.adjecti.invoicing.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.adjecti.invoicing.dto.PaymentModeDto;
import com.adjecti.invoicing.dto.UtilityPaymentDto;
import com.adjecti.invoicing.dto.UtilityTypeDto;
import com.adjecti.invoicing.response.Response;
import com.adjecti.invoicing.response.ValidationResponse;
import com.adjecti.invoicing.service.PaymentModeService;
import com.adjecti.invoicing.service.UtilityPaymentService;
import com.adjecti.invoicing.service.UtilityService;

@Controller
@RequestMapping("/utilityPayment")
public class UtilityPaymentController {
	@Autowired
	private UtilityPaymentService utilityPaymentService;
	
	@Autowired
	PaymentModeService paymentModeService;
	
	@Autowired
	UtilityService utilityTypeService;
	
	@Autowired 
	private ValidationResponse response;

	
	@RequestMapping(value="/form")
	private ModelAndView createUtilityPayment() {
		System.out.println("helloo");
		ModelAndView modelAndView = new ModelAndView();

		List<PaymentModeDto> paymentModes = paymentModeService.getAllPayment();
		List<UtilityTypeDto> utilityTypes = utilityTypeService.getUtilityTypes();
		
		modelAndView.addObject("paymentModes", paymentModes);
		modelAndView.addObject("utilityTypes", utilityTypes);
		modelAndView.addObject("utilityPayment", new UtilityPaymentDto());

		modelAndView.setViewName("Utility-payment-form");
		return modelAndView;
	}
	
	
	
	@RequestMapping(value="/add", method = {RequestMethod.POST,RequestMethod.GET}, produces = "application/json")
	@ResponseBody
	private ResponseEntity<?> saveUtilityPayment(@Valid @ModelAttribute("utilityPaymentDto")UtilityPaymentDto utilityPaymentDto, BindingResult result, MultipartFile file) {
		/*
		 * System.out.println("heloo controller");
		 * System.out.println(file.getOriginalFilename()); if(result.hasErrors()) {
		 * System.out.println("hello"); Map<String, String> errors =
		 * result.getFieldErrors().stream() .collect(
		 * Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage) );
		 * response.setValidated(false); response.setErrorMessages(errors); return new
		 * ResponseEntity<>(response,HttpStatus.BAD_REQUEST); }
		 */
		
		Response response=new Response();
		utilityPaymentService.createUtilityPayment(utilityPaymentDto,file);
		response.setStatusMessage("utility payment  has been Added Successfully!!");
		if (utilityPaymentDto.getId() > 0) {
			response.setStatusMessage("utility Payment has been Updated successfully !!");
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
		
	}
	
	@GetMapping("/list")
	@ResponseBody
	private ModelAndView getUtilityPayments(){
		ModelAndView modelAndView=new ModelAndView("utility-payment-list");
	   
		return modelAndView;
	}
	@GetMapping("/jlist")
	@ResponseBody
	private List<UtilityPaymentDto> jgetUtilityPayments(){
		return utilityPaymentService.getutilityPayments();
	}
	
	@GetMapping("/{id}")
	private UtilityPaymentDto getUtilityPayment(long id) {
		return null;
	}
	@RequestMapping("/delete/{id}")
	@ResponseBody
	private String deleteUtilityPayment(@PathVariable("id")long id)
	{
		utilityPaymentService.deleteUtilityPayment(id);
		return "Client has been deleted successfully!!";	
		
	}
	
	@RequestMapping(value = "/update/{id}", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView utilityPaymentUpdate(@PathVariable("id") long id) {

		ModelAndView modelAndView = new ModelAndView();
		
		List<PaymentModeDto> paymentModes = paymentModeService.getAllPayment();
		List<UtilityTypeDto> utilityTypes = utilityTypeService.getUtilityTypes();
		
		modelAndView.addObject("paymentModes", paymentModes);
		modelAndView.addObject("utilityTypes", utilityTypes);
		
		
		UtilityPaymentDto UtilityPayment = utilityPaymentService.getUtilityPayment(id);
		modelAndView.addObject("utilityPayment", UtilityPayment);

		modelAndView.setViewName("Utility-payment-form");
		return modelAndView;
	}
	

	@RequestMapping(value="/download")
	public ResponseEntity<Object> downloadFile(@RequestParam("path") String fileName) throws FileNotFoundException {
		System.out.println(fileName);
		File file=new File(fileName);
		InputStreamResource resource =new InputStreamResource(new FileInputStream(file));
		HttpHeaders headers=new HttpHeaders();
		headers.add("Content-Disposition", String.format("attachment;filename=\"%s\"", file.getName()));
		 headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
	        headers.add("Pragma", "no-cache");
	        headers.add("Expires", "0");
	        
	        ResponseEntity<Object> responseEntity=ResponseEntity.ok().headers(headers)
	        		.contentLength(file.length())
	        		.contentType(MediaType.parseMediaType("application/txt")).body(resource);
	        
	        return responseEntity;
		
		
	}

}
