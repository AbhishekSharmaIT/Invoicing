package com.adjecti.invoicing.controller;

import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.dto.YearlyLeaveDto;
import com.adjecti.invoicing.dto.PeopleDto;
import com.adjecti.invoicing.service.YearlyLeaveService;
import com.adjecti.invoicing.service.PeopleService;


@Controller
@RequestMapping("/yearlyleave")
public class YearlyLeaveController {
    @Autowired
	private YearlyLeaveService   yearlyleaveservice;
    
    @Autowired
    private PeopleService peopleservice;
    
    
    
    @RequestMapping("/list")
	public String getYearlyLeave(Model model) {
		List<YearlyLeaveDto> yearlyleave= yearlyleaveservice.getYearlyLeave();
		model.addAttribute("yearlyleave", yearlyleave);
		return "yearlyleave-list";
	}
    @GetMapping("/jlist")
	@ResponseBody
	public List<YearlyLeaveDto> JYearlyLeaveList() {
    	List<YearlyLeaveDto> yearlyleave= yearlyleaveservice.getYearlyLeave();
		
		return yearlyleave;
	}
    
    
    @RequestMapping("/new")
	public String getNewYearlyLeave(Model model) {
    	
    	List<PeopleDto>peopledto=peopleservice.getPeople();
		List<YearlyLeaveDto> yearlyleavedto=  yearlyleaveservice.getYearlyLeave();
		model.addAttribute("yearlyleavedto", yearlyleavedto);
		model.addAttribute("peopledto",peopledto); 
		model.addAttribute("yearlyleave",new YearlyLeaveDto());
		return "yearlyleave-form";
	}
        
    @RequestMapping("/delete/{id}") 
    @ResponseBody
	  public YearlyLeaveResponse delete(@PathVariable("id") int id) {		
    	yearlyleaveservice.delete(id);		  
    	return new YearlyLeaveResponse(null,"Sucessfully Deleted People...");
	  }
	 
    @RequestMapping(value = "/add", method = { RequestMethod.GET, RequestMethod.POST }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public YearlyLeaveResponse saveYearlyLeave(@Valid @ModelAttribute("people")  YearlyLeaveDto  yearlyleavedto,BindingResult result) {
		
    	YearlyLeaveResponse yearlyleaveresponse=new YearlyLeaveResponse();
    	yearlyleaveservice.save( yearlyleavedto);
		if( yearlyleavedto.getId()>0) {
		
		return new YearlyLeaveResponse(null,"Sucessfully Updated YearlyLeave...");
		}
		else {
			return new YearlyLeaveResponse(null,"Sucessfully Saved  YearlyLeave...");
		}		
	}
    	
    @RequestMapping("/update/{id}")
    public String  yearlyleaveUpdate(@PathVariable("id") int id,Model model) {    	
    	
		List<PeopleDto>people= peopleservice.getPeople();
		
		model.addAttribute("peopledto",people);
		
		YearlyLeaveDto  yearlyleavedto =  yearlyleaveservice.getYearlyLeave(id);		
   	model.addAttribute("yearlyleave",  yearlyleavedto);    	
    	return "yearlyleave-form";
    }
    
    @RequestMapping("/addYearlyLeave")
    public String addYearlyLeave(@RequestParam("id") int id,Model model) {
    	
		List<PeopleDto> people= peopleservice.getPeople();
		model.addAttribute("people",people);
		
		return "yearlyleave-form";
    }
    
  //  @RequestMapping("/updateproject")
  // 	@Transactional
   //	public String updateProject(@Valid @ModelAttribute("consultantpayment") ConsultantPaymentDto consultantpaymentdto,BindingResult result) {
   		
   		
    //   	consultantpaymentservice.save(consultantpaymentdto);
   		
     //  	 return "redirect:/ConsultantPayment/list";
   //	}
    
    
    
    private class YearlyLeaveResponse {
		private   YearlyLeaveDto yearlyleaveDto;
		private String msg;
		
		public YearlyLeaveResponse() {
			
		}
		public YearlyLeaveResponse(YearlyLeaveDto yearlyleaveDto, String msg) {
			
			this.yearlyleaveDto = yearlyleaveDto;
			this.msg = msg;
		}
		public YearlyLeaveDto getYearlyLeaveDto() {
			return yearlyleaveDto;
		}
		public void setPeopleDto(YearlyLeaveDto yearlyleaveDto) {
			this.yearlyleaveDto = yearlyleaveDto;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		
    }
    
}

