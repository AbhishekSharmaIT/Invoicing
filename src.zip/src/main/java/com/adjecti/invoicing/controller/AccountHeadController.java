package com.adjecti.invoicing.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.adjecti.invoicing.dto.AccountHeadDto;
import com.adjecti.invoicing.response.Response;
import com.adjecti.invoicing.service.AccountHeadService;

@Controller
@RequestMapping("/accountHead")
public class AccountHeadController {

	
	@Autowired
	AccountHeadService accountHeadService;
	

	@RequestMapping(value="/form")
	private ModelAndView createDaybook() {
		System.out.println("helloo");
		ModelAndView modelAndView = new ModelAndView();

		
		modelAndView.addObject("accountHead", new AccountHeadDto());

		modelAndView.setViewName("account-head-form");
		return modelAndView;
	}
	
	
	
	@RequestMapping(value="/add", method = {RequestMethod.POST,RequestMethod.GET}, produces = "application/json")
	@ResponseBody
	private ResponseEntity<?> saveAccountHead(@Valid @ModelAttribute("accountHead")AccountHeadDto accountHead, BindingResult result) {
		System.out.println("heloo controller");
		
		Response response=new Response();
		accountHeadService.createAccountHead(accountHead);
		
		response.setStatusMessage("utility payment  has been Added Successfully!!");
		if (accountHead.getId() > 0) {
			
			response.setStatusMessage("updated");
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
		
	}
	
	@GetMapping("/list")
	@ResponseBody
	private ModelAndView getDayBook(){
		ModelAndView modelAndView=new ModelAndView("account-head-list");
	   
		return modelAndView;
	}
	@GetMapping("/jlist")
	@ResponseBody
	private List<AccountHeadDto> jgetDayBooks(){
		return accountHeadService.getAccountHeads();
	}
	
	@GetMapping("/{id}")
	@ResponseBody
	private AccountHeadDto getAccountHead(@PathVariable("id")long id) {
		System.out.println("id"+id);
		return accountHeadService.getAccountHead(id);
	}
	@RequestMapping("/delete/{id}")
	@ResponseBody
	private String deleteAccountHead(@PathVariable("id")long id)
	{
		accountHeadService.deleteAccountHead(id);
		return "Account Head has been deleted successfully!!";	
		
	}
	
	@RequestMapping(value = "/update/{id}", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView dayBookUpdate(@PathVariable("id") long id) {
		System.out.println(id+"update controller");
		ModelAndView modelAndView = new ModelAndView();
		
		AccountHeadDto accountHeadDto = accountHeadService.getAccountHead(id);
		modelAndView.addObject("accountHeadDto", accountHeadDto);
		
		modelAndView.setViewName("account-head-form");
		return modelAndView;
	}
}
