package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.adjecti.invoicing.dto.TaxDto;
import com.adjecti.invoicing.response.Response;
import com.adjecti.invoicing.security.TaxValidator;
import com.adjecti.invoicing.service.TaxService;

@Controller
@RequestMapping("/tax")
public class TaxController {

	@Autowired
	private TaxService taxService;

	@Autowired
	private TaxValidator taxValidator;

	@GetMapping("/list")
	public String list(Model model) {

		List<TaxDto> taxes = taxService.findAll();

		System.out.println(taxes);

		model.addAttribute("taxes", taxes);

		return "tax-list";
	}
	
	@GetMapping("/load")
	@ResponseBody
	public List<TaxDto> loadTax(Model model) {

		List<TaxDto> taxes = taxService.findAll();

		System.out.println(taxes);
		return taxes;
	}

	@GetMapping("/new")
	public String showTaxForm(Model model) {

		model.addAttribute("tax", new TaxDto());
		return "tax-form";
	}

	@RequestMapping(value = "/save", method = { RequestMethod.GET, RequestMethod.POST }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<?> saveTax( @Valid @ModelAttribute TaxDto tax,BindingResult result) {

		System.out.println("-------------Printing the TaxDto in saveTax  :-------");
		System.out.println(tax);
		System.out.println("-------------Printing the TaxDto :-------");
		/*
		 * taxValidator.validate(tax, bindingResult); if (bindingResult.hasErrors()) {
		 * return "tax-form"; }
		 */
		
         List<Response> responseList=new ArrayList<>();
		
		if(result.hasErrors()) {
			System.out.println("inside binding result");
			List<FieldError> fieldErrors = result.getFieldErrors();
			for(FieldError temp:fieldErrors) {
				System.out.println(temp.getField()+"  "+temp.getDefaultMessage());
				 responseList.add(new Response(temp.getField(),temp.getDefaultMessage(),null));
			}
			
			return new ResponseEntity<>(responseList,HttpStatus.BAD_REQUEST);
		}
		
		TaxDto saveDto = null;
		//TaxResponse taxResponse = null;
		Response response=new Response();
		if (tax.getId() == 0) {
			saveDto = taxService.save(tax);
			if (saveDto != null) {
				response.setStatusMessage("Sucessfully Created Tax.");
				//taxResponse = new TaxResponse(saveDto, "Sucessfully Created Tax.");
			} else {
				response.setStatusMessage("Not Created Tax.");
				//taxResponse = new TaxResponse(saveDto, "Not Created Tax.");
			}

		} else {
			saveDto = taxService.save(tax);
			if (saveDto != null) {
				response.setStatusMessage("Sucessfully Updated Tax.");
				//taxResponse = new TaxResponse(saveDto, "Sucessfully Updated Tax.");
			} else {
				response.setStatusMessage("Not Created Tax.");
				//taxResponse = new TaxResponse(saveDto, "Not Created Tax.");
			}
		}
		return new ResponseEntity<>(response,HttpStatus.OK);
		//return taxResponse;
		// return "redirect:/tax/list";
	}

	@GetMapping("/delete")
	@ResponseBody
	public TaxResponse delete(@RequestParam("taxId") int theId) {

		taxService.delete(theId);

		return new TaxResponse(null,"Sucessfully Deleted Tax...");
	}

	@GetMapping("/update")
	public String update(@RequestParam("taxId") int theId, Model model) {

		TaxDto taxDto = taxService.findById(theId);

		System.out.println(taxDto);

		model.addAttribute("tax", taxDto);

		return "tax-form";
	}

	private class TaxResponse {
		private TaxDto taxDto;
		private String msg;

		public TaxResponse() {
		}

		public TaxResponse(TaxDto taxDto, String msg) {
			this.taxDto = taxDto;
			this.msg = msg;
		}

		public TaxDto getTaxDto() {
			return taxDto;
		}

		public void setTaxDto(TaxDto taxDto) {
			this.taxDto = taxDto;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

	}

}
