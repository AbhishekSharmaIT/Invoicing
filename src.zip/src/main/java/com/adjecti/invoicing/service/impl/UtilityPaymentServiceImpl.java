package com.adjecti.invoicing.service.impl;


import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.adjecti.invoicing.dto.UtilityPaymentDto;
import com.adjecti.invoicing.helper.FileUploadHelper;
import com.adjecti.invoicing.model.ConsultantInvoicDocument;
import com.adjecti.invoicing.model.UtilityPayment;
import com.adjecti.invoicing.repository.DocumentRepository;
import com.adjecti.invoicing.repository.UtilityPaymentRepository;
import com.adjecti.invoicing.service.UtilityPaymentService;

@Service
public class UtilityPaymentServiceImpl implements UtilityPaymentService{
	
	@Autowired
	private UtilityPaymentRepository utilityPaymentRepository;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private DocumentRepository documentRepository;
	 @Value("${upload.path}")
	 private String upload_path;
	
	@Autowired
	private FileUploadHelper fileUploadHelper;
		
	@Override
	public UtilityPaymentDto createUtilityPayment(UtilityPaymentDto utilityPaymentDto ,MultipartFile file ) {
		
		  boolean uploadConculatntInvoiceFile =
		  fileUploadHelper.uploadClientFile(file);
		  
		  String fileName = file.getOriginalFilename(); String contentType =
		  file.getContentType(); String name=file.getName();
		  System.out.println(uploadConculatntInvoiceFile + " " + fileName + " "+
		  contentType +" "+name +" "+upload_path);
		  ConsultantInvoicDocument  billDocument = utilityPaymentDto.getConsultantInvoicDocument();
		  billDocument.setMimeType(contentType); billDocument.setDocumentType(name);
		  billDocument.setName(fileName); billDocument.setTitle(fileName);
		  billDocument.setPath(upload_path);
		  utilityPaymentDto.setConsultantInvoicDocument(billDocument);
		  documentRepository.save(billDocument);
		 
		UtilityPayment utilityPayment =utilityPaymentRepository.save(modelMapper.map(utilityPaymentDto, UtilityPayment.class));
		utilityPaymentDto = modelMapper.map(utilityPayment, UtilityPaymentDto.class);
		return utilityPaymentDto;
	}

	@Override
	public List<UtilityPaymentDto> getutilityPayments() {
		return utilityPaymentRepository.findAll().stream().map(this:: convertUtilityPaymentDto).collect(Collectors.toList());
	}

	@Override
	public void deleteUtilityPayment(long id) {
		// TODO Auto-generated method stub
		
		utilityPaymentRepository.deleteById(id);
	}

	@Override
	public UtilityPaymentDto getUtilityPayment(long id) {
		UtilityPayment utilityPayment = utilityPaymentRepository.findById(id).get();
		if(null!=utilityPayment)
			return convertUtilityPaymentDto(utilityPayment);
		return null;
	}
	
	public UtilityPaymentDto convertUtilityPaymentDto(UtilityPayment utilityPayment ) {
		return modelMapper.map(utilityPayment, UtilityPaymentDto.class);
	}
}
