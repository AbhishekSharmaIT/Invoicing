package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.CurrencyDto;
import com.adjecti.invoicing.model.Currency;
import com.adjecti.invoicing.repository.CurrencyRespository;
import com.adjecti.invoicing.service.CurrencyService;

@Service
public class CurrencyServiceImpl implements CurrencyService {

	@Autowired
	private CurrencyRespository currencyRepository;
	@Autowired
    private ModelMapper modelMapper;

	@Override
	public CurrencyDto saveCurrency(CurrencyDto currencyDto) {		
		Currency currency =currencyRepository.save(modelMapper.map(currencyDto, Currency.class));
		CurrencyDto dto = modelMapper.map(currency, CurrencyDto.class);
		return dto;
	}

	@Override
	public List<CurrencyDto> findAll() {
		List<Currency> currency=currencyRepository.findAll();
		List<CurrencyDto> currencyDto=new ArrayList<>();
		currency.forEach(c->currencyDto.add(new CurrencyDto(c)));
		return currencyDto;
	}


	@Override
	public void delete(Integer id) {
		currencyRepository.deleteById(id);
		
	}

	@Override
	public void update(CurrencyDto currencyDto) {
		Currency currency= modelMapper.map(currencyDto, Currency.class);
		currencyRepository.save(currency);
		
	}

	@Override
	public CurrencyDto findById(Integer id) {
		Optional<Currency> currency= this.currencyRepository.findById(id);
		if(currency.isPresent()) {
		return modelMapper.map(currency.get(), CurrencyDto.class);}
		else {return null;}
	}

	

	
	

}
