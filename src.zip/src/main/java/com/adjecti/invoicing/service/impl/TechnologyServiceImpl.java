package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.TechnologyDto;
import com.adjecti.invoicing.model.Technology;
import com.adjecti.invoicing.repository.TechnologyRepository;
import com.adjecti.invoicing.service.TechnologyService;
@Service
public class TechnologyServiceImpl  implements TechnologyService{
	@Autowired
	private TechnologyRepository technologyRepository; 
	@Autowired
    private ModelMapper modelMapper;
	@Override
	public TechnologyDto save(TechnologyDto technologyDto) {
		Technology technology =technologyRepository.save(modelMapper.map(technologyDto, Technology.class));
		TechnologyDto dto = modelMapper.map(technology, TechnologyDto.class);
		return dto;
	}

	@Override
	public List<TechnologyDto> findAll() {
		List<TechnologyDto>  technologyDto=  technologyRepository.findAll() .stream() .map(this::converttechnologyDto) .collect(Collectors.toList());
		return technologyDto;
	}
	 private TechnologyDto converttechnologyDto(Technology technology) { 
		   
		 TechnologyDto technologyDto = modelMapper.map(technology, TechnologyDto.class);	
	        return technologyDto;
	    }
	@Override
	public void delete(Integer id) {
		technologyRepository.deleteById( id); 
	}

	@Override
	public void update(TechnologyDto technologydto) {
		Technology technology= modelMapper.map(technologydto, Technology.class);
		technologyRepository.save(technology);
		
	}

	@Override
	public TechnologyDto findById(int id) {
		Optional<Technology> technology=	technologyRepository.findById(id);
		if(technology.isPresent()) 
		return modelMapper.map(technology.get(), TechnologyDto.class);	
		return null;
		
	}

	

}
