package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.CountryDto;


public interface CountryService {

	public CountryDto save(CountryDto countryDto);

	public List<CountryDto> getCountryList();
	void delete(Integer id);


	void update(CountryDto countrydto);

	CountryDto findById(int id);

	
}
