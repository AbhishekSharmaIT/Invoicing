package com.adjecti.invoicing.service;


import java.util.List;

import com.adjecti.invoicing.dto.ConsultantDto;

	public interface ConsultantService {

	    public ConsultantDto save(ConsultantDto consultantDto);


	public List<ConsultantDto> findAll();
	void delete(Integer id);
	public ConsultantDto findById(int id);


	void update(ConsultantDto consultantDto);
}


