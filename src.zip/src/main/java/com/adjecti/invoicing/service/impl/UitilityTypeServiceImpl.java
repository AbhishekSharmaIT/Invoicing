package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.UtilityTypeDto;
import com.adjecti.invoicing.model.UtilityType;
import com.adjecti.invoicing.repository.UtilityTypeRepository;
import com.adjecti.invoicing.service.UtilityService;
@Service
public class UitilityTypeServiceImpl implements UtilityService{
	
	@Autowired
	private UtilityTypeRepository utilityTypeRepository; 
	@Autowired
    private ModelMapper modelMapper;
	@Override
	public List<UtilityTypeDto>getUtilityTypes() {
		List<UtilityTypeDto>  utilityTypeDto= utilityTypeRepository.findAll() .stream().map(this::convertUtilityTypeDto) .collect(Collectors.toList());
		return utilityTypeDto;
	}
	
	@Override
	public UtilityTypeDto save(UtilityTypeDto utilityTypedto) {
		
		 
		 UtilityType utilityType =utilityTypeRepository.save(modelMapper.map(utilityTypedto, UtilityType.class));
		 UtilityTypeDto dto = modelMapper.map(utilityType, UtilityTypeDto.class);
		 return dto;
	}
	
	@Override
	public void delete(int id) {
		utilityTypeRepository.deleteById(id);		
		
	}
	@Override
	public void update(UtilityTypeDto utilitypeDto) {
		UtilityType billingType= modelMapper.map(utilitypeDto, UtilityType.class);
		utilityTypeRepository.save(billingType);
	}
	@Override
	public UtilityTypeDto getUtilityType(int id) {
		UtilityType utilityType = utilityTypeRepository.findById(id).get();
		if(null!=utilityType)
		return modelMapper.map(utilityType, UtilityTypeDto.class);	
		return null;
	}
	 private UtilityTypeDto convertUtilityTypeDto(UtilityType utilityType) { 
		   
		 UtilityTypeDto utilityTypeDto = modelMapper.map(utilityType, UtilityTypeDto.class);	
	        return utilityTypeDto;
	 }
	 
	 

	
}
