package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.AccountHeadDto;
import com.adjecti.invoicing.model.AccountHead;
import com.adjecti.invoicing.repository.AccountHeadRepository;
import com.adjecti.invoicing.service.AccountHeadService;

@Service
public class AccountHeadServiceImpl implements AccountHeadService{

	@Autowired
	AccountHeadRepository accountHeadRepository;
	
	@Autowired
	ModelMapper modelMapper;
	
	
	@Override
	public AccountHeadDto createAccountHead(AccountHeadDto accountHeadDto) {
		AccountHead accountHead =accountHeadRepository.save(modelMapper.map(accountHeadDto, AccountHead.class));
		accountHeadDto = modelMapper.map(accountHead, AccountHeadDto.class);
			return accountHeadDto;
	}

	@Override
	public List<AccountHeadDto> getAccountHeads() {
		return accountHeadRepository.findAll().stream().map(this:: convertAccountHeadDto).collect(Collectors.toList());
	}

	@Override
	public void deleteAccountHead(long id) {
		accountHeadRepository.deleteById(id);
	}

	@Override
	public void updateAccountHead(AccountHeadDto accountHeadDto) {
		AccountHead accountHead= modelMapper.map(accountHeadDto, AccountHead.class);
		accountHeadRepository.save(accountHead);
		
	}

	@Override
	public AccountHeadDto getAccountHead(long id) {
		AccountHead accountHead = accountHeadRepository.findById(id).get();
		if(null!=accountHead)
			return convertAccountHeadDto(accountHead);
		return null;
	}

	public AccountHeadDto convertAccountHeadDto(AccountHead accountHead ) {
		return modelMapper.map(accountHead, AccountHeadDto.class);
	}

	@Override
	public List<AccountHeadDto> getByType(int type) {
		return accountHeadRepository.getByType(type).stream().map(this:: convertAccountHeadDto).collect(Collectors.toList());
	}
}
