package com.adjecti.invoicing.service.impl;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.ConsultantPaymentDto;
import com.adjecti.invoicing.model.ConsultantPayment;
import com.adjecti.invoicing.repository.ConsultantPaymentRepository;
import com.adjecti.invoicing.service.ConsultantPaymentService;
@Service
public class ConsultantPaymentServiceImpl implements  ConsultantPaymentService {
	@Autowired
	private  ConsultantPaymentRepository consultantpaymentrepository;
	@Autowired
	private ModelMapper modelMapper;
	
	
	
	@Override
	public List<ConsultantPaymentDto> getConsultantPayment() {
		List<ConsultantPayment> consultantpayment = consultantpaymentrepository.getConsultantPayment(true);
		List<ConsultantPaymentDto> consultantpaymentdto=new ArrayList<>();

		for(ConsultantPayment temp:consultantpayment) {
			ConsultantPaymentDto dto=modelMapper.map(temp,ConsultantPaymentDto.class);
			consultantpaymentdto.add(dto);
			
		}
	   
	   return consultantpaymentdto;
}
	
	 @Override 
	  public void delete(int id) {
		 consultantpaymentrepository.delete(false, id);
	  }
	 @Override
	public void save(ConsultantPaymentDto consultantpaymentdto) {
			consultantpaymentdto.setEnabled(true);
			 ConsultantPayment savepayment = modelMapper.map(consultantpaymentdto, ConsultantPayment.class);
			consultantpaymentrepository.saveAndFlush(savepayment );
		// ConsultantPayment savepayment= consultantpaymentrepository.save(consultantpaymentdto.ToEntity());
		// ConsultantPaymentDto consultantpaymentDto = new ConsultantPaymentDto(savepayment);
		
		}

	    @Override
		public ConsultantPaymentDto getConsultantPayment(int id) {
		// ConsultantPayment consultantpayment = consultantpaymentrepository.findById(id).get();
		// ConsultantPaymentDto consultantpaymentDto = new ConsultantPaymentDto(consultantpayment);
		//	 return consultantpaymentDto;
			 Optional<ConsultantPayment> optional = consultantpaymentrepository.findById(id);
			 ConsultantPayment consultantpayment = optional.get();
			 ConsultantPaymentDto consultantpaymentdto = modelMapper.map(consultantpayment, ConsultantPaymentDto.class);	
				return consultantpaymentdto;
		}
}
