package com.adjecti.invoicing.service;

import java.util.List;
import com.adjecti.invoicing.dto.ClientDto;

import ch.qos.logback.core.net.server.Client;


public interface ClientService {

	public ClientDto createClient(ClientDto clientDto);
	public List<ClientDto> getClients();
	public void deleteClient(int id);
	public ClientDto getClient(int id);
}
