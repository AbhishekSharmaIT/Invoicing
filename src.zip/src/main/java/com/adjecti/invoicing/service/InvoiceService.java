package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.InvoiceDto;
import com.adjecti.invoicing.model.Invoice;

public interface InvoiceService {

    public List<InvoiceDto> findAll();
	
	public InvoiceDto save(InvoiceDto invoiceDto);
	
	public void delete(int id);
	
	public InvoiceDto findById(int id);
	
	public Invoice lastInvoice(int id) ;
}
