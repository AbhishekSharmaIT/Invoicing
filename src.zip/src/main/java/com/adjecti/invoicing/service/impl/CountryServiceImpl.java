package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.CountryDto;
import com.adjecti.invoicing.model.Country;
import com.adjecti.invoicing.repository.CountryRepository;
import com.adjecti.invoicing.service.CountryService;
@Service
public class CountryServiceImpl implements CountryService{

	@Autowired
	private CountryRepository countryRepository;
	@Autowired
    private ModelMapper modelMapper;
	
	@Override
	public CountryDto save(CountryDto countryDto) {
		Country country =countryRepository.save(modelMapper.map(countryDto, Country.class));
		CountryDto dto = modelMapper.map(country, CountryDto.class);
		return dto;
	}

	@Override
	public List<CountryDto> getCountryList() {
		List<CountryDto> countryDto=countryRepository.findAll() .stream() .map(this::convertCountryDto) .collect(Collectors.toList());
		return countryDto;
	}
	
	 private CountryDto convertCountryDto(Country country) { 
	        CountryDto countryDto = modelMapper.map(country, CountryDto.class);	
	        return countryDto;
	    }

	@Override
	public void delete(Integer id) {
		this.countryRepository.deleteById(id);
	}

	@Override
	public void update(CountryDto countrydto) {
		Country country= modelMapper.map(countrydto, Country.class);
		countryRepository.save(country);
		
	}

	@Override
	public CountryDto findById(int id) {
		Optional<Country> country=	countryRepository.findById(id);
		if(country.isPresent()) 
		return modelMapper.map(country.get(), CountryDto.class);	
		return null;
		
	}


	
	


}
