package com.adjecti.invoicing.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.ClientDto;
import com.adjecti.invoicing.dto.TaxDto;
import com.adjecti.invoicing.model.Address;
import com.adjecti.invoicing.model.Client;
import com.adjecti.invoicing.model.Contact;
import com.adjecti.invoicing.model.Tax;
import com.adjecti.invoicing.repository.ClientRepository;
import com.adjecti.invoicing.repository.TaxRepository;
import com.adjecti.invoicing.service.ClientService;
import com.adjecti.invoicing.service.TaxService;


@Service
public class ClientServiceImpl implements ClientService {

	@Autowired
	ClientRepository clientRepository;
	
	@Autowired
	 TaxService taxService;
	
	
	@Autowired
	TaxRepository taxRepository;
	
	@Override
	 
	public ClientDto createClient(ClientDto clientDto) {
		System.out.println("hello");
		clientDto.setCreatedDate(LocalDate.now());
		Address address=clientDto.getAddress();
		Contact contact=clientDto.getContact();
		contact.setWebsite(address.getWebsite());
		contact.setName(contact.getFirstName()+"  "+contact.getLastName());
		contact.setTitle(contact.getDesignation());
		clientDto.setWebsite(address.getWebsite());
		clientDto.setEnabled((byte) 1);
		
		List<Tax> taxes=new ArrayList<>();
		if(clientDto.getTax()!=null) {
		  for(Tax tax :clientDto.getTax()) { 
			  TaxDto taxDto =taxService.findById(tax.getId()); 
			  if(taxDto!=null)
			  {
				 taxes.add(taxDto.toEntity());			 
			  }
			  }
		}
	    clientDto.setTax(taxes);
	    Client client = clientRepository.save(clientDto.ToEntity());
	    clientDto=new ClientDto(client);
	    return clientDto;
		
	}

	@Override
	public List<ClientDto> getClients() {
		List<Client> clients=clientRepository.getAllClient(); 
		List<ClientDto> clientsDto=new ArrayList<>();
		clients.forEach(c->clientsDto.add(new ClientDto(c)));
		return clientsDto;
	}

	@Override
	public void deleteClient(int id) {
	   
	    clientRepository.deleteClient(id);
	}

	@Override
	public  ClientDto getClient(int id) {
		 Client client = clientRepository.findById(id).get();
		 ClientDto clientDto = new ClientDto(client);
		 return clientDto;
	}

	
}
