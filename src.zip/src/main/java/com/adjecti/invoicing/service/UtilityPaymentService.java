package com.adjecti.invoicing.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.adjecti.invoicing.dto.UtilityPaymentDto;

public interface UtilityPaymentService {

	public UtilityPaymentDto createUtilityPayment(UtilityPaymentDto utilityPaymentDto , MultipartFile file );
	public List<UtilityPaymentDto> getutilityPayments();
	public void deleteUtilityPayment(long id);
	public UtilityPaymentDto getUtilityPayment(long id);
	
}
