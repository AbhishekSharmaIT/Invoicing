package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.MonthlyLeaveDto;


public interface MonthlyLeaveService {

	public List<MonthlyLeaveDto> getMonthlyLeave();

	public void delete(int id);
	public void save(MonthlyLeaveDto monthlyleavedto);
	public MonthlyLeaveDto getMonthlyLeave(int id);
	
	
}
