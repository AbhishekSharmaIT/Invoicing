package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.AccountHeadDto;


public interface AccountHeadService {
	
	public AccountHeadDto createAccountHead(AccountHeadDto accountHeadDto);
	public List<AccountHeadDto> getAccountHeads();
	public void deleteAccountHead(long id);
	public void updateAccountHead(AccountHeadDto accountHeadDto);
	public AccountHeadDto getAccountHead(long id);
	public List<AccountHeadDto> getByType(int type);
}
