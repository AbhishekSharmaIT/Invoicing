package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.JobOpeningDto;

import com.adjecti.invoicing.model.JobOpening;

import com.adjecti.invoicing.repository.JobOpeningRepository;

import com.adjecti.invoicing.service.JobOpeningService;

@Service
public class JobOpeningServiceImpl implements JobOpeningService {

	@Autowired
	private  JobOpeningRepository jobopeningrepository;
	@Autowired
	private ModelMapper modelMapper;
	
	
	
	@Override
	public List<JobOpeningDto> getJobOpening() {
		List<JobOpening>  jobopening =jobopeningrepository.getJobOpening(true);
		List<JobOpeningDto> jobopeningdto=new ArrayList<>();

		for(JobOpening temp: jobopening) {
			JobOpeningDto jobopeningDto=modelMapper.map(temp,JobOpeningDto.class);
			jobopeningdto.add(jobopeningDto);
			
		}
	   
	   return jobopeningdto;
}
	
	 @Override 
	  public void delete(int id) {
		 jobopeningrepository.delete(false, id);
	  }
	 @Override
	public void save(JobOpeningDto jobopeningdto) {
		 jobopeningdto.setEnabled(true);
			JobOpening savejobopening = modelMapper.map(jobopeningdto,JobOpening.class);
			jobopeningrepository.saveAndFlush(savejobopening );
		
		
		}

	    @Override
		public JobOpeningDto getJobOpening(int id) {
		
			 Optional<JobOpening> optional = jobopeningrepository.findById(id);
			 JobOpening jobopening = optional.get();
			 JobOpeningDto jobopeningdto = modelMapper.map(jobopening, JobOpeningDto.class);	
				return jobopeningdto;
		}
	
}
