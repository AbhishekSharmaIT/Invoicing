package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.model.Tax;
import com.adjecti.invoicing.dto.TaxDto;
import com.adjecti.invoicing.repository.TaxRepository;
import com.adjecti.invoicing.service.TaxService;

@Service
public class TaxServiceImpl implements TaxService {

	@Autowired
	TaxRepository taxRepository;

	@Autowired
	ModelMapper mapper;

	@Override
	public List<TaxDto> findAll() {

		List<Tax> taxes = taxRepository.findAll();
		List<TaxDto> taxDtos = new ArrayList<>();

		taxes.forEach(tax -> taxDtos.add(mapper.map(tax, TaxDto.class)));
		/*
		 * for(Tax tax:taxes){ taxDtos.add(new TaxDto(tax)); }
		 */
		return taxDtos;
	}

	@Override
	public TaxDto save(TaxDto taxDto) {

		System.out.println("-------------Printing the TaxDto in save method in TaxService  :-------");
		// System.out.println(taxDto.toEntity());
		System.out.println("-------------Printing the TaxDto :-------");
		// Tax save = taxRepository.save(tax.toEntity());
		Tax tax = mapper.map(taxDto, Tax.class);

		tax = taxRepository.save(tax);
		taxDto = mapper.map(tax, TaxDto.class);

		return taxDto;
	}

	@Override
	public void delete(int id) {

		TaxDto taxDto = findById(id);

		if (taxDto != null) {
			// taxRepository.delete(tax.toEntity());
			Tax tax = mapper.map(taxDto, Tax.class);

			taxRepository.delete(tax);
		}
		// taxRepository.delete(taxDto.toEntity());
	}

	@Override
	public TaxDto findById(int id) {
		Optional<Tax> tax = taxRepository.findById(id);
		Tax tempTax = null;

		if (tax.isPresent()) {

			tempTax = tax.get();
			// return new TaxDto(tempTax);
			TaxDto taxDto = mapper.map(tempTax, TaxDto.class);
			return taxDto;
		} else {
			return null;
		}

	}

	@Override
	public Tax findByName(String name) {
		
		return taxRepository.findByName(name);
	}

}
