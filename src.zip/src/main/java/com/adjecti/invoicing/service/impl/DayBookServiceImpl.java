package com.adjecti.invoicing.service.impl;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.DayBookDto;
import com.adjecti.invoicing.dto.UtilityPaymentDto;
import com.adjecti.invoicing.model.DayBook;
import com.adjecti.invoicing.model.UtilityPayment;
import com.adjecti.invoicing.repository.DayBookRepository;
import com.adjecti.invoicing.service.DayBookService;
@Service
public class DayBookServiceImpl implements DayBookService{
	
	@Autowired
	DayBookRepository dayBookRepository;
	@Autowired
	ModelMapper modelMapper;
	

	@Override
	public DayBookDto createDayBook(DayBookDto dayBookDto) {
		System.out.println("created date"+dayBookDto.getCreatedDate());
		if(dayBookDto.getId()==0) {
		    dayBookDto.setCreatedDate(LocalDate.now());
		}
		
		DayBook daybook1 =dayBookRepository.getRuningBalance();
	    if(daybook1!=null) {
	    	float runingBalance = daybook1.getRuningBalance();
	    	float amount = dayBookDto.getAmount();
		
	    	if(Integer.parseInt(dayBookDto.getDebitCredit())==-1)
			 runingBalance=runingBalance-amount;
	    	else
			 runingBalance=runingBalance+amount;
	  
		dayBookDto.setRuningBalance(runingBalance);
	    }
	    else {
	    	if(Integer.parseInt(dayBookDto.getDebitCredit())==-1)
	    		dayBookDto.setRuningBalance(0-dayBookDto.getAmount());
		    	if(Integer.parseInt(dayBookDto.getDebitCredit())==1)
		    		dayBookDto.setRuningBalance(dayBookDto.getAmount());
		    	
		  
	    }
		DayBook dayBook =dayBookRepository.save(modelMapper.map(dayBookDto, DayBook.class));
		dayBook.setSerialNo((int)dayBook.getId());
		dayBook =dayBookRepository.save(dayBook);
		
		dayBookDto = modelMapper.map(dayBook, DayBookDto.class);
			return dayBookDto;
	}

	
	  @Override 
	  public List<DayBookDto> getDayBooks()
	  {
		  return dayBookRepository.findAll().stream().map(this:: convertDayBookDto).collect(Collectors.toList()); 
	  }
	 
	 
	  

	@Override
	public void deleteDayBook(long id) {
		dayBookRepository.deleteById(id);
	}

	@Override
	public DayBookDto getDayBook(long id) {
		DayBook dayBook = dayBookRepository.findById(id).get();
		if(null!=dayBook)
			return convertDayBookDto(dayBook);
		return null;
	}
	
	public DayBookDto convertDayBookDto(DayBook dayBook ) {
		return modelMapper.map(dayBook, DayBookDto.class);
	}

	@Override
	public List<DayBookDto> getTodaysDayBookList(LocalDate Date) {
		
		return dayBookRepository.findBYTodaysDate(Date).stream().map(this:: convertDayBookDto).collect(Collectors.toList());
	}

	@Override
	public List<DayBookDto> getDayBookTillDate(LocalDate fromDate, LocalDate toDate) {
	return dayBookRepository.findByDates(fromDate,toDate).stream().map(this:: convertDayBookDto).collect(Collectors.toList());
	
	}
	
	
	@Override
	public Boolean reconcile(LocalDate fromDate) {
		/*
		 * Calendar cal=Calendar.getInstance(); cal.setTime(new
		 * Date(fromDate.getTime())); cal.set(cal.get(Calendar.YEAR),
		 * cal.get(Calendar.MONTH), cal.get(Calendar.DATE), 0, 0, 0); fromDate=new
		 * Date(cal.getTime().getTime());
		 * 
		 * cal.setTime(new Date()); cal.set(cal.get(Calendar.YEAR),
		 * cal.get(Calendar.MONTH), cal.get(Calendar.DATE)+1, 0, 0, 0);
		 */
		
		LocalDate toDate=LocalDate.now();
		
		List<DayBook> dayBooks= (List<DayBook>)dayBookRepository.findByDates(fromDate,toDate);
		float runingBalance=0f;
		
		for(DayBook db:dayBooks){
			
			if(Integer.parseInt(db.getDebitCredit())==1){
				
				runingBalance=runingBalance+ db.getAmount();
				//System.out.println("credit  "+runingBalance);
			}else{
				//System.out.println("running balance"+runingBalance+ "  "+j++);
				
				runingBalance=runingBalance- db.getAmount();
				
			}
			db.setRuningBalance(runingBalance);
			dayBookRepository.save(db);
		}
		
		
		return true;
		
	}
	
	
}
