package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.BillingTypeDto;

public interface BillingTypeService {
	public BillingTypeDto save(BillingTypeDto billingTypeDto);
	public List<BillingTypeDto> findAll();
	public void delete(Integer id);
	
	void update(BillingTypeDto billingTypedto);
	public BillingTypeDto findById(int id);
}
