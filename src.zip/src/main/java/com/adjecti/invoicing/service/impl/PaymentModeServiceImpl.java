package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.BillingTypeDto;
import com.adjecti.invoicing.dto.PaymentModeDto;
import com.adjecti.invoicing.model.BillingType;
import com.adjecti.invoicing.model.PaymentMode;
import com.adjecti.invoicing.repository.PaymentModeRepository;
import com.adjecti.invoicing.service.PaymentModeService;
;
@Service
public class PaymentModeServiceImpl  implements PaymentModeService {
	@Autowired
	private PaymentModeRepository paymentmoderepository;
	@Autowired
    private ModelMapper modelMapper;
	@Override
	public List<PaymentModeDto> getAllPayment(){
		List<PaymentMode>paymentmode=(List<PaymentMode>) paymentmoderepository.findAll();
		ArrayList<PaymentModeDto>paymentmodedto=new ArrayList<PaymentModeDto>();
		for(PaymentMode paymentmode1:paymentmode) {
			paymentmodedto.add(new PaymentModeDto(paymentmode1));
		}
		return paymentmodedto;
	}
	@Override
	public PaymentModeDto save(PaymentModeDto paymentmodedto) {
		PaymentMode paymentModeDto =paymentmoderepository.save(modelMapper.map(paymentmodedto, PaymentMode.class));
		PaymentModeDto dto = modelMapper.map(paymentModeDto, PaymentModeDto.class);
		return dto;
	}
	@Override
	public PaymentModeDto findById(int id) {
		Optional<PaymentMode> paymentMode=	paymentmoderepository.findById(Long.valueOf(id));
		if(paymentMode.isPresent()) 
		return modelMapper.map(paymentMode.get(), PaymentModeDto.class);	
		return null;
	}
	@Override
	public void update(PaymentModeDto paymentmode) {
		System.out.println(paymentmode.getName());
		this.save(paymentmode);
		
	}
	
	@Override 
	  public void delete(int id) {
		paymentmoderepository.deleteById(Long.valueOf(id));
	  }
}
                          