package com.adjecti.invoicing.service;

import java.util.List;


import com.adjecti.invoicing.dto.YearlyLeaveDto;

public interface YearlyLeaveService {
	
		public List <YearlyLeaveDto> getYearlyLeave();

		public void delete(int id);
		public void save( YearlyLeaveDto  YearlyLeavedto);
		public  YearlyLeaveDto getYearlyLeave(int id);
		
		
	
}
