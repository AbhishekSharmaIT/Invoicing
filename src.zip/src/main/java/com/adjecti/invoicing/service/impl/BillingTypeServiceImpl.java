package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.BillingTypeDto;
import com.adjecti.invoicing.model.BillingType;
import com.adjecti.invoicing.repository.BillingTypeRepository;
import com.adjecti.invoicing.service.BillingTypeService;

@Service
public class BillingTypeServiceImpl implements BillingTypeService {
	
	@Autowired
	private BillingTypeRepository billingTypeRepository; 
	@Autowired
    private ModelMapper modelMapper;
	@Override
	public BillingTypeDto save(BillingTypeDto billingTypedto) {
		BillingType billingType =billingTypeRepository.save(modelMapper.map(billingTypedto, BillingType.class));
		BillingTypeDto dto = modelMapper.map(billingType, BillingTypeDto.class);
		return dto;
	}
	@Override
	public List<BillingTypeDto> findAll() {
		List<BillingTypeDto>  billingTypeDto=  billingTypeRepository.findAll() .stream() .map(this::convertBillingTypeDto) .collect(Collectors.toList());
		return billingTypeDto;
		}
	    private BillingTypeDto convertBillingTypeDto(BillingType billingType) { 
	   
	        BillingTypeDto billingTypeDto = modelMapper.map(billingType, BillingTypeDto.class);	
	        return billingTypeDto;
	    }
		@Override
		public void delete(Integer id) {
			billingTypeRepository.deleteById(id);			
		}
		@Override
		public void update(BillingTypeDto billingTypedto) {
			BillingType billingType= modelMapper.map(billingTypedto, BillingType.class);
			billingTypeRepository.save(billingType);
			
		}

		@Override
		public BillingTypeDto findById(int id) {
			Optional<BillingType> billingType=	billingTypeRepository.findById(id);
			if(billingType.isPresent()) 
			return modelMapper.map(billingType.get(), BillingTypeDto.class);	
			return null;
			
		}
	
	
}