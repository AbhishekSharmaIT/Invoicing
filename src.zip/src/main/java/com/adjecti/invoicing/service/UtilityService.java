package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.UtilityTypeDto;

public interface UtilityService {

	
	public UtilityTypeDto save(UtilityTypeDto utilitypeDto);
	public void delete(int id);
	void update(UtilityTypeDto utilitypeDto);
	
	public UtilityTypeDto getUtilityType(int id);
	public List<UtilityTypeDto> getUtilityTypes();

}
