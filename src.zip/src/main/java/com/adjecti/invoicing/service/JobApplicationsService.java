package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.JobApplicationsDto;

public interface JobApplicationsService {

	public List<JobApplicationsDto> getJobApplications();

	public void delete(int id);
	public void save(JobApplicationsDto jobapplicationsdto);
	public JobApplicationsDto getJobApplications(int id);
	
}
