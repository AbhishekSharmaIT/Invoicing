package com.adjecti.invoicing.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.adjecti.invoicing.dto.ProjectDto;

public interface ProjectService {
	
public List<ProjectDto> getProject();

public void delete(int id);
public void save(ProjectDto projectdto, MultipartFile file);
public ProjectDto getProject(int id);
}
