package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.ConsultantPaymentDto;

public interface ConsultantPaymentService {
	
	public List<ConsultantPaymentDto> getConsultantPayment();
	 public void delete(int id);
	 public void save(ConsultantPaymentDto consultantpaymentdto);
	 public ConsultantPaymentDto getConsultantPayment(int id);
}
