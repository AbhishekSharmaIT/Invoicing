package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.PeopleDto;

public interface PeopleService {

	public List<PeopleDto> getPeople();

	public void delete(int id);
	public void save(PeopleDto peopledto);
	public PeopleDto getPeople(int id);
	
	
}
