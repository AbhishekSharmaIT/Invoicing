package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.ClientPurchaseOrderItemDto;
import com.adjecti.invoicing.model.ClientPurchaseOrderItem;
import com.adjecti.invoicing.repository.ClientPurchaseOrderItemRepository;
import com.adjecti.invoicing.service.ClientPurchaseOrderItemSerice;

@Service
public class ClientPurchaseOrderItemServiceImpl implements ClientPurchaseOrderItemSerice {

	@Autowired
	private ClientPurchaseOrderItemRepository clientPurchaseOrderItemRepository; 
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Override
	public List<ClientPurchaseOrderItemDto> getAllCLientPoItem() {

		List<ClientPurchaseOrderItem> list = clientPurchaseOrderItemRepository.findAll();
		List<ClientPurchaseOrderItemDto> dtoList=new ArrayList<>();
		list.forEach(a->dtoList.add(modelMapper.map(list, ClientPurchaseOrderItemDto.class)));
		return dtoList;
	}

	@Override
	public void save(ClientPurchaseOrderItemDto clientPurchaseOrderItemDto) {
		
		clientPurchaseOrderItemRepository.save(modelMapper.map(clientPurchaseOrderItemDto, ClientPurchaseOrderItem.class));
	}

	@Override
	public void delete(int id) {
		
		clientPurchaseOrderItemRepository.deleteById(id);
	}

	@Override
	public ClientPurchaseOrderItemDto getAllCLientPoItem(int id) {
		Optional<ClientPurchaseOrderItem> list = clientPurchaseOrderItemRepository.findById(id);
		    ClientPurchaseOrderItem clientPurchaseOrderItem = list.get();
		    ClientPurchaseOrderItemDto map = modelMapper.map(clientPurchaseOrderItem, ClientPurchaseOrderItemDto.class);
		return map;
	}

}
