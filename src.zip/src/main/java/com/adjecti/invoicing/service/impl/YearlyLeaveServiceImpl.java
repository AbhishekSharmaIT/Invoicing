package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.YearlyLeaveDto;

import com.adjecti.invoicing.model.YearlyLeave;

import com.adjecti.invoicing.repository.YearlyLeaveRepository;

import com.adjecti.invoicing.service.YearlyLeaveService;

@Service
public class YearlyLeaveServiceImpl implements YearlyLeaveService {
	@Autowired
	private YearlyLeaveRepository yearlyleaverepository;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public List<YearlyLeaveDto> getYearlyLeave() {
		List<YearlyLeave> yearlyleave = yearlyleaverepository.getYearlyLeave(true);
		List<YearlyLeaveDto> yearlyleavedto = new ArrayList<>();

		for (YearlyLeave temp : yearlyleave) {
			YearlyLeaveDto yearlyleaveDto = modelMapper.map(temp, YearlyLeaveDto.class);
			yearlyleavedto.add(yearlyleaveDto);

		}

		return yearlyleavedto;
	}

	@Override
	public void delete(int id) {
		yearlyleaverepository.delete(false, id);
	}

	@Override
	public void save(YearlyLeaveDto yearlyleavedto) {
		yearlyleavedto.setEnabled(true);
		YearlyLeave saveyearlyleave = modelMapper.map(yearlyleavedto, YearlyLeave.class);
		yearlyleaverepository.saveAndFlush(saveyearlyleave);

	}

	@Override
	public YearlyLeaveDto getYearlyLeave(int id) {

		Optional<YearlyLeave> optional = yearlyleaverepository.findById(id);
		YearlyLeave yearlyleave = optional.get();
		YearlyLeaveDto yearlyleavedto = modelMapper.map(yearlyleave, YearlyLeaveDto.class);
		return yearlyleavedto;
	}
}
