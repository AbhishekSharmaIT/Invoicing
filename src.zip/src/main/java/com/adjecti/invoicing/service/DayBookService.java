package com.adjecti.invoicing.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.adjecti.invoicing.dto.DayBookDto;

public interface DayBookService {
	public DayBookDto createDayBook(DayBookDto dayBookDto );
	public List<DayBookDto> getDayBooks();
	public void deleteDayBook(long id);
	public DayBookDto getDayBook(long id);
	public List<DayBookDto> getTodaysDayBookList(LocalDate Date);
	public List<DayBookDto> getDayBookTillDate(LocalDate fromDate ,LocalDate toDate);
	Boolean reconcile(LocalDate fromDate);
	
	
}
