package com.adjecti.invoicing.dto;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.adjecti.invoicing.model.BillingCycle;
import com.adjecti.invoicing.model.BillingType;
import com.adjecti.invoicing.model.Client;
import com.adjecti.invoicing.model.Project;
import com.adjecti.invoicing.model.PurchaseOrder;
import com.adjecti.invoicing.model.Technology;

import lombok.Data;

@Data
public class ProjectDto {
	
    private int id; 
    @NotEmpty
	private String description;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date endDate;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date startDate;
	@NotEmpty
	private String name;
	private String sowUrl;
	@NotNull
	private BillingCycle billingcycle;
	private BillingType billingtype;
	private Client client;
	private PurchaseOrder purchaseorder;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date createdDate;
	private List<Technology> technology;
    private Boolean enabled;
	
	public Boolean getEnabled() {
		return enabled;
	}




	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}




	public List<Technology> getTechnology() {
		return technology;
	}

	public void setTechnology(List<Technology> technology) {
		this.technology = technology;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	

	public Date getEndDate() {
		return endDate;
	}




	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}




	public Date getStartDate() {
		return startDate;
	}




	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}




	



	public Date getCreatedDate() {
		return createdDate;
	}




	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}




	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSowUrl() {
		return sowUrl;
	}

	public void setSowUrl(String sowUrl) {
		this.sowUrl = sowUrl;
	}

	
	public BillingCycle getBillingcycle() {
		return billingcycle;
	}

	public void setBillingcycle(BillingCycle billingcycle) {
		this.billingcycle = billingcycle;
	}

	public BillingType getBillingtype() {
		return billingtype;
	}

	public void setBillingtype(BillingType billingtype) {
		this.billingtype = billingtype;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	
	public PurchaseOrder getPurchaseorder() {
		return purchaseorder;
	}

	public void setPurchaseorder(PurchaseOrder purchaseorder) {
		this.purchaseorder = purchaseorder;
	}




	@Override
	public String toString() {
		return "ProjectDto [id=" + id + ", description=" + description + ", endDate=" + endDate + ", startDate="
				+ startDate + ", name=" + name + ", sowUrl=" + sowUrl + ", billingcycle=" + billingcycle
				+ ", billingtype=" + billingtype + ", client=" + client + ", purchaseorder=" + purchaseorder
				+ ", createdDate=" + createdDate + ", technology=" + technology + ", enabled=" + enabled + "]";
	}

	
	
}  


