package com.adjecti.invoicing.dto;

import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

import com.adjecti.invoicing.model.CompanyType;
import com.adjecti.invoicing.model.Consultant;

public class ConsultantDto {

	
	private int id;
	@NotEmpty(message = "Please fill address")
	private String address;
	private String bankdetails;
	@NotEmpty(message = "Must be filled")
	private String businessname;
	private byte enabled;
	@NotEmpty(message = "Consultant name must be filled")
	private String name;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date registeredDate;	
	private String taxdocno1;
	private String taxdocno2;
	private String contactno;
	private String email;
	private CompanyType company;

	public ConsultantDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ConsultantDto(Consultant entity) {

		this.id=entity.getId();
		this.address = entity.getAddress();
		this.bankdetails = entity.getBankdetails();
		this.enabled = entity.getEnabled();
		this.name = entity.getName();
		this.businessname=entity.getBusinessname();
		this.registeredDate = entity.getRegisteredDate();
		this.taxdocno1 = entity.getTaxdocno1();
		this.taxdocno2 = entity.getTaxdocno2();
		this.contactno = entity.getContactno();
		this.email = entity.getEmail();
		this.company = entity.getCompany();
	}
	
	public Consultant ToEntity()
	{ Consultant entity = new Consultant();
	entity.setId(this.getId());
	entity.setAddress(this.getAddress());
	entity.setBankdetails(this.getBankdetails());
	entity.setEnabled(this.getEnabled());
	entity.setBusinessname(this.getBusinessname());
	entity.setName(this.getName());
	entity.setRegisteredDate(this.getRegisteredDate());
	entity.setTaxdocno1(this.getTaxdocno1());
	entity.setTaxdocno2(this.getTaxdocno2());
	entity.setContactno(this.getContactno());
	entity.setEmail(this.getEmail());
	entity.setCompany(this.getCompany());
	return entity;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBankdetails() {
		return bankdetails;
	}

	public void setBankdetails(String bankdetails) {
		this.bankdetails = bankdetails;
	}
	
	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public byte getEnabled() {
		return enabled;
	}

	public void setEnabled(byte enabled) {
		this.enabled = enabled;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getRegisteredDate() {
		return registeredDate;
	}

	public void setRegisteredDate(Date registeredDate) {
		this.registeredDate = registeredDate;
	}

	public String getTaxdocno1() {
		return taxdocno1;
	}

	public void setTaxdocno1(String taxdocno1) {
		this.taxdocno1 = taxdocno1;
	}

	public String getTaxdocno2() {
		return taxdocno2;
	}

	public void setTaxdocno2(String taxdocno2) {
		this.taxdocno2 = taxdocno2;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public CompanyType getCompany() {
		return company;
	}

	public void setCompany(CompanyType company) {
		this.company = company;
	}


	
}
