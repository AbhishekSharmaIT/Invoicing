package com.adjecti.invoicing.dto;

import java.util.Date;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.adjecti.invoicing.model.ConsultantInvoicDocument;
import com.adjecti.invoicing.model.PaymentMode;
import com.adjecti.invoicing.model.UtilityType;

public class UtilityPaymentDto {


	
	private long id;
	@Min(value=1, message="Must be equal or greater than 1") 
	private float amount;
	@NotEmpty
	private String billNo; 
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@NotNull(message = "Please provide a date.")
	private Date dueDate; 
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@NotNull(message = "Please provide a date.")
	private Date fromDate;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@NotNull(message = "Please provide a date.")
	private Date paymentDate;
	
	private String remark; 
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@NotNull(message = "Please provide a date.")
	private Date toDate; 
	
	private ConsultantInvoicDocument consultantInvoicDocument;
	@NotNull
	private PaymentMode paymentMode;
	
	@NotNull
	private UtilityType utilityType;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getBillNo() {
		return billNo;
	}
	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	
	public ConsultantInvoicDocument getConsultantInvoicDocument() {
		return consultantInvoicDocument;
	}
	public void setConsultantInvoicDocument(ConsultantInvoicDocument consultantInvoicDocument) {
		this.consultantInvoicDocument = consultantInvoicDocument;
	}
	public PaymentMode getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(PaymentMode paymentMode) {
		this.paymentMode = paymentMode;
	}
	public UtilityType getUtilityType() {
		return utilityType;
	}
	public void setUtilityType(UtilityType utilityType) {
		this.utilityType = utilityType;
	}
	
	
}
