package com.adjecti.invoicing.dto;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.adjecti.invoicing.model.Client;
import com.adjecti.invoicing.model.InvoiceItem;
import com.adjecti.invoicing.model.PurchaseOrder;
import com.adjecti.invoicing.model.TaxItem;

public class InvoiceDto {

	
    private int id;
        
    private String termsConditions;
    
    private double subTotal;
    
    private int serialNo;
    
    private String invoiceUpload;
    
    private String invoiceNo;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date invoiceDate;
    
    private String instructions;
    
    private double grandTotal;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date dueDate;
    
    private String currency;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createdDate;
    
    private int cancelled;
    
    private double balanceDue;
    
    private double amountReceived;
    
    private double advancePaid;
    
    private int enabled;
    
    private List<InvoiceItem> invoiceItems;
    
    private Client client;
    
    private PurchaseOrder purchaseOrder;
    
    private List<TaxItem> taxItems;
    
    public List<TaxItem> getTaxItems() {
		return taxItems;
	}


	public void setTaxItems(List<TaxItem> taxItems) {
		this.taxItems = taxItems;
	}


	public InvoiceDto() {
    	
    }


	public int getId() {
		return id;
	}


	public void setId(int id) {
		 this.id = id;
	}


	public String getTermsConditions() {
		return termsConditions;
	}


	public void setTermsConditions(String termsConditions) {
		this.termsConditions = termsConditions;
	}


	public double getSubTotal() {
		return subTotal;
	}


	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}


	public int getSerialNo() {
		return serialNo;
	}


	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}


	public String getInvoiceUpload() {
		return invoiceUpload;
	}


	public void setInvoiceUpload(String invoiceUpload) {
		this.invoiceUpload = invoiceUpload;
	}


	public String getInvoiceNo() {
		return invoiceNo;
	}


	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}


	public Date getInvoiceDate() {
		return invoiceDate;
	}


	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}


	public String getInstructions() {
		return instructions;
	}


	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}


	public double getGrandTotal() {
		return grandTotal;
	}


	public void setGrandTotal(double grandTotal) {
		this.grandTotal = grandTotal;
	}


	public Date getDueDate() {
		return dueDate;
	}


	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public int getCancelled() {
		return cancelled;
	}


	public void setCancelled(int cancelled) {
		this.cancelled = cancelled;
	}


	public double getBalanceDue() {
		return balanceDue;
	}


	public void setBalanceDue(double balanceDue) {
		this.balanceDue = balanceDue;
	}


	public double getAmountReceived() {
		return amountReceived;
	}


	public void setAmountReceived(double amountReceived) {
		this.amountReceived = amountReceived;
	}


	public double getAdvancePaid() {
		return advancePaid;
	}


	public void setAdvancePaid(double advancePaid) {
		this.advancePaid = advancePaid;
	}


	public int getEnabled() {
		return enabled;
	}


	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}


	public List<InvoiceItem> getInvoiceItems() {
		return invoiceItems;
	}


	public void setInvoiceItems(List<InvoiceItem> invoiceItems) {
		this.invoiceItems = invoiceItems;
	}


	public Client getClient() {
		return client;
	}


	public void setClient(Client client) {
		this.client = client;
	}


	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}


	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("InvoiceDto [id=").append(id).append(", termsConditions=").append(termsConditions)
				.append(", subTotal=").append(subTotal).append(", serialNo=").append(serialNo)
				.append(", invoiceUpload=").append(invoiceUpload).append(", invoiceNo=").append(invoiceNo)
				.append(", invoiceDate=").append(invoiceDate).append(", instructions=").append(instructions)
				.append(", grandTotal=").append(grandTotal).append(", dueDate=").append(dueDate).append(", currency=")
				.append(currency).append(", createdDate=").append(createdDate).append(", cancelled=").append(cancelled)
				.append(", balanceDue=").append(balanceDue).append(", amountReceived=").append(amountReceived)
				.append(", advancePaid=").append(advancePaid).append(", enabled=").append(enabled)
				.append(", invoiceItems=").append(invoiceItems).append(", client=").append(client)
				.append(", purchaseOrder=").append(purchaseOrder).append(", taxItems=").append(taxItems).append("]");
		return builder.toString();
	}


	/*
	 * @Override public String toString() { StringBuilder builder = new
	 * StringBuilder();
	 * builder.append("InvoiceDto [id=").append(id).append(", termsConditions=").
	 * append(termsConditions)
	 * .append(", subTotal=").append(subTotal).append(", serialNo=").append(
	 * serialNo)
	 * .append(", invoiceUpload=").append(invoiceUpload).append(", invoiceNo=").
	 * append(invoiceNo)
	 * .append(", invoiceDate=").append(invoiceDate).append(", instructions=").
	 * append(instructions)
	 * .append(", grandTotal=").append(grandTotal).append(", dueDate=").append(
	 * dueDate).append(", currency=")
	 * .append(currency).append(", createdDate=").append(createdDate).
	 * append(", cancelled=").append(cancelled)
	 * .append(", balanceDue=").append(balanceDue).append(", amountReceived=").
	 * append(amountReceived)
	 * .append(", advancePaid=").append(advancePaid).append(", enabled=").append(
	 * enabled)
	 * .append(", invoiceItems=").append(invoiceItems).append(", client=").append(
	 * client) .append(", purchaseOrder=").append(purchaseOrder).append("]"); return
	 * builder.toString(); }
	 */

   
    
    
	/*
	 * @ManyToOne(cascade =
	 * {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH
	 * })
	 * 
	 * @JoinColumn(name = "purchaseOrderId") private PurchaseOrder purchaseOrder;
	 */
	/*
	 * public InvoiceDto(Invoice invoice) {
	 * 
	 * id=invoice.getId(); termsConditions=invoice.getTermsConditions();
	 * subTotal=invoice.getSubTotal(); serialNo=invoice.getSerialNo();
	 * invoiceUpload=invoice.getInvoiceUpload(); invoiceNo=invoice.getInvoiceNo();
	 * invoiceDate=invoice.getInvoiceDate() ;
	 * instructions=invoice.getInstructions(); grandTotal=invoice.getGrandTotal();
	 * dueDate=invoice.getDueDate() ; currency=invoice.getCurrency();
	 * createdDate=invoice.getCreatedDate() ; cancelled=invoice.getCancelled();
	 * balanceDue=invoice.getBalanceDue();
	 * amountReceived=invoice.getAmountReceived();
	 * advancePaid=invoice.getAdvancePaid(); enabled=invoice.getEnabled();
	 * invoiceItems = getInvoiceItems(); client=invoice.getClient(); }
	 * 
	 * public Invoice toEntity() { Invoice invoice = new Invoice();
	 * 
	 * invoice.setId(id); invoice.setTermsConditions(termsConditions);
	 * invoice.setSubTotal(subTotal); invoice.setSerialNo(serialNo);
	 * invoice.setInvoiceUpload(invoiceUpload); invoice.setInvoiceNo(invoiceNo);
	 * invoice.setInvoiceDate(invoiceDate) ; invoice.setInstructions(instructions);
	 * invoice.setGrandTotal(grandTotal); invoice.setDueDate(dueDate) ;
	 * invoice.setCurrency(currency); invoice.setCreatedDate(createdDate) ;
	 * invoice.setCancelled(cancelled); invoice.setBalanceDue(balanceDue);
	 * invoice.setAmountReceived(amountReceived);
	 * invoice.setAdvancePaid(advancePaid); invoice.setEnabled(enabled);
	 * invoice.setInvoiceItems(invoiceItems); invoice.setClient(client);
	 * 
	 * return invoice; }
	 */
}
