package com.adjecti.invoicing.dto;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.adjecti.invoicing.model.Tax;

import lombok.Data;

@Data
public class TaxDto {
	 
    private int id;
    
    
    private Integer active;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createdDate;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date effectiveDate;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date ineffectiveDate;
    
    
    private String name;
    
    
    private double rate;
    
    
    private String type;

    public TaxDto() {
		
	}
    
	
	  public TaxDto(Tax tax){
	  
	  this.id = tax.getId(); this.name =tax.getName(); this.type = tax.getType();
	  this.effectiveDate = tax.getEffectiveDate(); this.ineffectiveDate =
	  tax.getIneffectiveDate(); this.active = tax.getActive(); this.createdDate =
	  tax.getCreatedDate(); this.rate = tax.getRate();
	  
	  }
	  
	  public Tax toEntity() { Tax tax = new Tax(); tax.setId(id);
	  tax.setCreatedDate(createdDate); tax.setEffectiveDate(effectiveDate);
	  tax.setIneffectiveDate(ineffectiveDate); tax.setActive(active);
	  tax.setRate(rate); tax.setCreatedDate(createdDate); tax.setName(name);
	  tax.setType(type); return tax; }
	 
    
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Integer getActive() {
		return active;
	}


	public void setActive(Integer active) {
		this.active = active;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public Date getEffectiveDate() {
		return effectiveDate;
	}


	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}


	public Date getIneffectiveDate() {
		return ineffectiveDate;
	}


	public void setIneffectiveDate(Date ineffectiveDate) {
		this.ineffectiveDate = ineffectiveDate;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getRate() {
		return rate;
	}


	public void setRate(double rate) {
		this.rate = rate;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TaxDto [id=");
		builder.append(id);
		builder.append(", active=");
		builder.append(active);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", effectiveDate=");
		builder.append(effectiveDate);
		builder.append(", ineffectiveDate=");
		builder.append(ineffectiveDate);
		builder.append(", name=");
		builder.append(name);
		builder.append(", rate=");
		builder.append(rate);
		builder.append(", type=");
		builder.append(type);
		builder.append("]");
		return builder.toString();
	}
	 
}