package com.adjecti.invoicing.dto;

import java.time.LocalDate;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.adjecti.invoicing.model.AccountHead;
import com.adjecti.invoicing.model.PaymentMode;

public class DayBookDto {
	private long id;
	private AccountHead accountHead;
	private float amount;
	private String bankName; 
	private String billRefNo; 
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date chqDrftTrnDate;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date chqDrftTrnDrawnDate;
	
	private String chqDrftTrnRefNo;
	private LocalDate createdDate;
	private String debitCredit; 
	private String description; 
	private String payee ; 
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date paymentDate; 
	private PaymentMode paymentMode; 
	private float runingBalance;
	private int serialNo;
	private int userId;
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBillRefNo() {
		return billRefNo;
	}
	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}
	public Date getChqDrftTrnDate() {
		return chqDrftTrnDate;
	}
	public void setChqDrftTrnDate(Date chqDrftTrnDate) {
		this.chqDrftTrnDate = chqDrftTrnDate;
	}
	public Date getChqDrftTrnDrawnDate() {
		return chqDrftTrnDrawnDate;
	}
	public void setChqDrftTrnDrawnDate(Date chqDrftTrnDrawnDate) {
		this.chqDrftTrnDrawnDate = chqDrftTrnDrawnDate;
	}
	public String getChqDrftTrnRefNo() {
		return chqDrftTrnRefNo;
	}
	public void setChqDrftTrnRefNo(String chqDrftTrnRefNo) {
		this.chqDrftTrnRefNo = chqDrftTrnRefNo;
	}
	public LocalDate getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}
	public String getDebitCredit() {
		return debitCredit;
	}
	public void setDebitCredit(String debitCredit) {
		this.debitCredit = debitCredit;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPayee() {
		return payee;
	}
	public void setPayee(String payee) {
		this.payee = payee;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public AccountHead getAccountHead() {
		return accountHead;
	}
	public void setAccountHead(AccountHead accountHead) {
		this.accountHead = accountHead;
	}
	public PaymentMode getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(PaymentMode paymentMode) {
		this.paymentMode = paymentMode;
	}
	public float getRuningBalance() {
		return runingBalance;
	}
	public void setRuningBalance(float runingBalance) {
		this.runingBalance = runingBalance;
	}
	public int getSerialNo() {
		return serialNo;
	}
	
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	@Override
	public String toString() {
		return "DayBookDto [id=" + id + ", accountHeadCode=" + accountHead + ", amount=" + amount + ", bankName="
				+ bankName + ", billRefNo=" + billRefNo + ", chqDrftTrnDate=" + chqDrftTrnDate
				+ ", chqDrftTrnDrawnDate=" + chqDrftTrnDrawnDate + ", chqDrftTrnRefNo=" + chqDrftTrnRefNo
				+ ", createdDate=" + createdDate + ", debitCredit=" + debitCredit + ", description=" + description
				+ ", payee=" + payee + ", paymentDate=" + paymentDate + ", paymentMode=" + paymentMode
				+ ", runingBalance=" + runingBalance + ", serialNo=" + serialNo + ", userId=" + userId + "]";
	}
	
}
