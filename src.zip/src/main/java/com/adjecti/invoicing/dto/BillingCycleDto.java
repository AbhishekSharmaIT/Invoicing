package com.adjecti.invoicing.dto;


import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.adjecti.invoicing.model.BillingCycle;

public class BillingCycleDto {

	private int id;
	@NotEmpty(message = "Type must not be empty")
	private String type;
		
	public BillingCycleDto() {
		super();
	}

	public BillingCycleDto(BillingCycle billingCycle) {
		super();
		id = billingCycle.getId();
		type = billingCycle.getType();
	}
	
	public BillingCycle toEntity() {

		BillingCycle billingCycle=new BillingCycle();
		billingCycle.setId(id);
		billingCycle.setType(type);
		return billingCycle;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}

}