package com.adjecti.invoicing.response;

import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
@Component
public class ValidationResponse  {

	private static final long serialVersionUID = 6984812367745100968L;
	private boolean validated;
    private Map<String, String> errorMessages;
 
    public boolean isValidated() {
        return validated;
    }
 
    public void setValidated(boolean validated) {
        this.validated = validated;
    }
 
    public void setErrorMessages(Map<String, String> errorMessages) {
        this.errorMessages = errorMessages;
    }
 
    public Map<String, String> getErrorMessages() {
        return errorMessages;
    }
}
