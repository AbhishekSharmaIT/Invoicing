package com.adjecti.invoicing.helper;

import java.io.FileOutputStream;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class FileUploadHelper {
	@Value("${upload.path}")
    private String uploadPath;
  public boolean uploadClientFile(MultipartFile multipartFile) {
   	boolean f=false; 	
    	try {
    		InputStream is=multipartFile.getInputStream();
    		
    		byte[] data=new byte[is.available()];
    		System.out.println("file length "+data.length);
    		if(data.length>0) {
    		is.read(data);
    		FileOutputStream fos=new FileOutputStream(uploadPath+"//"+ multipartFile.getOriginalFilename());
    		fos.write(data);  		
    		fos.flush();
    		fos.close();
    		f=true;
    		}
     	}
    	catch(Exception e) {
    		
    		e.printStackTrace();
    		
    	}
    	
    	return f;
    	
    }
}
