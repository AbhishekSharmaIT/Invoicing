package com.adjecti.invoicing.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="tbl_consultant_invoice")
public class ConsultantInvoicing {
	
	public ConsultantInvoicing() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private float amount;
	private String description;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date duedate;
	private byte enabled;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date invoicedate;
	private String invoiceNo;
	private float taxAmount;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="consultant_id")
	private Consultant consultantid;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "billDocument_id")
    private ConsultantInvoicDocument consultantInvoicDocument;
	
	public ConsultantInvoicDocument getConsultantInvoicDocument() {
		return consultantInvoicDocument;
	}
	public void setConsultantInvoicDocument(ConsultantInvoicDocument consultantInvoicDocument) {
		this.consultantInvoicDocument = consultantInvoicDocument;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	public Date getDuedate() {
		return duedate;
	}
	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}
	public Date getInvoicedate() {
		return invoicedate;
	}
	public void setInvoicedate(Date invoicedate) {
		this.invoicedate = invoicedate;
	}
	public byte getEnabled() {
		return enabled;
	}
	public void setEnabled(byte enabled) {
		this.enabled = enabled;
	}
	
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public float getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(float taxAmount) {
		this.taxAmount = taxAmount;
	}

	public Consultant getConsultantid() {
		return consultantid;
	}
	public void setConsultantid(Consultant consultantid) {
		this.consultantid = consultantid;
	}
	public ConsultantInvoicing(int id, float amount, String description, Date duedate, byte enabled, Date invoicedate,
			String invoiceNo, float taxAmount, Integer billdocumentid, Consultant consultantid,
			ConsultantInvoicDocument consultantInvoicDocument) {
		super();
		this.id = id;
		this.amount = amount;
		this.description = description;
		this.duedate = duedate;
		this.enabled = enabled;
		this.invoicedate = invoicedate;
		this.invoiceNo = invoiceNo;
		this.taxAmount = taxAmount;
		this.consultantid = consultantid;
		this.consultantInvoicDocument = consultantInvoicDocument;
	}
	@Override
	public String toString() {
		return "ConsultantInvoicing [id=" + id + ", amount=" + amount + ", description=" + description + ", duedate="
				+ duedate + ", enabled=" + enabled + ", invoicedate=" + invoicedate + ", invoiceNo=" + invoiceNo
				+ ", taxAmount=" + taxAmount + ", consultantid=" + consultantid
				+ ", consultantInvoicDocument=" + consultantInvoicDocument + "]";
	}
	
	
	

}
