package com.adjecti.invoicing.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_document")
public class ConsultantInvoicDocument {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String documentType;
	private String mimeType;
	private String name;
	private String path;
	private String title;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

	public ConsultantInvoicDocument(int id, String documentType, String mimeType, String name, String path,
			String title) {
		super();
		this.id = id;
		this.documentType = documentType;
		this.mimeType = mimeType;
		this.name = name;
		this.path = path;
		this.title = title;
	}
	public ConsultantInvoicDocument() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ConsultantInvoicDocument [id=" + id + ", documenttype=" + documentType + ", mimetype=" + mimeType
				+ ", name=" + name + ", path=" + path + ", title=" + title + "]";
	}

	
}
