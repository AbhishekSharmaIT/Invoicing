package com.adjecti.invoicing.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
@Table(name="tbl_utility_payment")
public class UtilityPayment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private float amount;
	private String billNo;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dueDate; 
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fromDate;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date paymentDate;
	
	private String remark; 
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date toDate; 
	@OneToOne
	@JoinColumn(name="billDocument_id")
	private ConsultantInvoicDocument consultantInvoicDocument;
	
	@OneToOne
	@JoinColumn(name="paymentMode_id")
	private PaymentMode paymentMode;
	
	@OneToOne
	@JoinColumn(name = "utilityType_id")
	private UtilityType utilityType;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getBillNo() {
		return billNo;
	}

	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}



	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	
	public ConsultantInvoicDocument getConsultantInvoicDocument() {
		return consultantInvoicDocument;
	}

	public void setConsultantInvoicDocument(ConsultantInvoicDocument consultantInvoicDocument) {
		this.consultantInvoicDocument = consultantInvoicDocument;
	}

	

	
	
	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public PaymentMode getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(PaymentMode paymentMode) {
		this.paymentMode = paymentMode;
	}

	public UtilityType getUtilityType() {
		return utilityType;
	}

	public void setUtilityType(UtilityType utilityType) {
		this.utilityType = utilityType;
	}



	
	
	
}
