package com.adjecti.invoicing.model;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "tbl_jobOpening")
public class JobOpening {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "minExp")
	private String minExp;

	@Column(name = "maxExp")
	private String maxExp;

	@Column(name = "minSalary")
	private String minSalary;

	@Column(name = "maxSalary")
	private String maxSalary;

	@Column(name = "description")
	private String Description;

	@Column(name = "enabled")
	private Boolean enabled;

	public JobOpening() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JobOpening(int id, String name, String minExp, String maxExp, String minSalary, String maxSalary,
			String description, Boolean enabled) {
		super();
		this.id = id;
		this.name = name;
		this.minExp = minExp;
		this.maxExp = maxExp;
		this.minSalary = minSalary;
		this.maxSalary = maxSalary;
		Description = description;
		this.enabled = enabled;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMinExp() {
		return minExp;
	}

	public void setMinExp(String minExp) {
		this.minExp = minExp;
	}

	public String getMaxExp() {
		return maxExp;
	}

	public void setMaxExp(String maxExp) {
		this.maxExp = maxExp;
	}

	public String getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(String minSalary) {
		this.minSalary = minSalary;
	}

	public String getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(String maxSalary) {
		this.maxSalary = maxSalary;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "JobOpening [id=" + id + ", name=" + name + ", minExp=" + minExp + ", maxExp=" + maxExp + ", minSalary="
				+ minSalary + ", maxSalary=" + maxSalary + ", Description=" + Description + ", enabled=" + enabled
				+ "]";
	}

	
	
}
