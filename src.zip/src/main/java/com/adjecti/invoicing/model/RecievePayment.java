package com.adjecti.invoicing.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tbl_recievePayment")
public class RecievePayment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "clientId")
	private Client client;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "invoiceId")
	private Invoice invoice;

	@Column(name = "payableTotal")
	private double payableTotal;

	@Column(name = "balanceDue")
	private double balanceDue;

	@Column(name = "amountReceived")
	private double amountReceived;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "paymentModeId")
	private PaymentMode paymentMode;

	@Column(name = "dateOfPayment")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dateOfPayment;

	@Column(name = "exchangeRate")
	private float exchangeRate;

	@Column(name = "transactionDetails")
	private String transactionDetails;
	
	@Column(name = "amountPaid")
	private double amountPaid;

	@Column(name = "enabled")
	private Boolean enabled;

	public RecievePayment() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public RecievePayment(int id, Client client, Invoice invoice, double payableTotal, double balanceDue,
			double amountReceived, PaymentMode paymentMode, Date dateOfPayment, float exchangeRate,
			String transactionDetails, double amountPaid, Boolean enabled) {
		super();
		this.id = id;
		this.client = client;
		this.invoice = invoice;
		this.payableTotal = payableTotal;
		this.balanceDue = balanceDue;
		this.amountReceived = amountReceived;
		this.paymentMode = paymentMode;
		this.dateOfPayment = dateOfPayment;
		this.exchangeRate = exchangeRate;
		this.transactionDetails = transactionDetails;
		this.amountPaid = amountPaid;
		this.enabled = enabled;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	public double getPayableTotal() {
		return payableTotal;
	}

	public void setPayableTotal(double payableTotal) {
		this.payableTotal = payableTotal;
	}

	public double getBalanceDue() {
		return balanceDue;
	}

	public void setBalanceDue(double balanceDue) {
		this.balanceDue = balanceDue;
	}

	public double getAmountReceived() {
		return amountReceived;
	}

	public void setAmountReceived(double amountReceived) {
		this.amountReceived = amountReceived;
	}

	public PaymentMode getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(PaymentMode paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Date getDateOfPayment() {
		return dateOfPayment;
	}

	public void setDateOfPayment(Date dateOfPayment) {
		this.dateOfPayment = dateOfPayment;
	}

	public float getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(float exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getTransactionDetails() {
		return transactionDetails;
	}

	public void setTransactionDetails(String transactionDetails) {
		this.transactionDetails = transactionDetails;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}
	
	
	
	public double getAmountPaid() {
		return amountPaid;
	}



	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}



	@Override
	public String toString() {
		return "RecievePayment [id=" + id + ", client=" + client + ", invoice=" + invoice + ", payableTotal="
				+ payableTotal + ", balanceDue=" + balanceDue + ", amountReceived=" + amountReceived + ", paymentMode="
				+ paymentMode + ", dateOfPayment=" + dateOfPayment + ", exchangeRate=" + exchangeRate
				+ ", transactionDetails=" + transactionDetails + ", amountPaid=" + amountPaid + ", enabled=" + enabled
				+ "]";
	}



	

}
