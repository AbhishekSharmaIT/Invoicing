package com.adjecti.invoicing.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tbl_purchase_order")
public class PurchaseOrder {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private float advancePaid;
	private float balanceDue;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date createdDate;
	
	private String currency;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date deliveryDate;
	private Boolean enabled;
	
	private float grandTotal;
	private String instructions;
	private float otherAmount;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date poDate;

	private String poFileUrl;
	private String poNumber;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date receivedDate;
    
	private float subTotal;
	private float taxAmount;
	private String termsConditions;
	
		
	private Boolean sow;
	private String title;
	private String hsnSac;
	private String billingAddress;
	private String shippingAddress;

	@ManyToOne
	@JoinColumn(name = "clientId")
	private Client client;

	@ManyToOne
	@JoinColumn(name = "billingCycleId")
	private BillingCycle billingCycle;

	@ManyToOne
	@JoinColumn(name = "billingTypeId")
	private BillingType billingType;


	@OneToMany(targetEntity = ClientPurchaseOrderItem.class,cascade = CascadeType.ALL ,
			/*
			 * cascade ={CascadeType.DETACH,CascadeType.MERGE, CascadeType.REFRESH},
			 */
			  fetch = FetchType.LAZY, orphanRemoval = false)
	 @JoinColumn(name = "purchaseOrderId", referencedColumnName = "Id")
	private List<ClientPurchaseOrderItem> clientPurchaseOrderItem;

	
	  @OneToMany(mappedBy = "purchaseorder", cascade = { CascadeType.DETACH,
	  CascadeType.MERGE, CascadeType.PERSIST,CascadeType.REFRESH })
	  private List<Project> project;
	  
	  public List<Project> getProject() { return project; } public void
	  setProject(List<Project> project) { this.project = project; }
	 
	public void setSow(Boolean sow) {
		this.sow = sow;
	}
	public Boolean getSow() {
		return sow;
	}

	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getAdvancePaid() {
		return advancePaid;
	}

	public void setAdvancePaid(float advancePaid) {
		this.advancePaid = advancePaid;
	}

	public float getBalanceDue() {
		return balanceDue;
	}

	public void setBalanceDue(float balanceDue) {
		this.balanceDue = balanceDue;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public float getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(float grandTotal) {
		this.grandTotal = grandTotal;
	}

	public String getInstructions() {
		return instructions;
	}

	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	public float getOtherAmount() {
		return otherAmount;
	}

	public void setOtherAmount(float otherAmount) {
		this.otherAmount = otherAmount;
	}

	public String getPoFileUrl() {
		return poFileUrl;
	}

	public void setPoFileUrl(String poFileUrl) {
		this.poFileUrl = poFileUrl;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public Date getPoDate() {
		return poDate;
	}

	public void setPoDate(Date poDate) {
		this.poDate = poDate;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public float getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(float subTotal) {
		this.subTotal = subTotal;
	}

	public float getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(float taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getTermsConditions() {
		return termsConditions;
	}

	public void setTermsConditions(String termsConditoins) {
		this.termsConditions = termsConditoins;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getHsnSac() {
		return hsnSac;
	}

	public void setHsnSac(String hsnSac) {
		this.hsnSac = hsnSac;
	}

	public String getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {

		this.client = client;
	}

	public BillingCycle getBillingCycle() {
		return billingCycle;
	}

	public void setBillingCycle(BillingCycle billingCycle) {
		this.billingCycle = billingCycle;
	}

	public BillingType getBillingType() {
		return billingType;
	}

	public void setBillingType(BillingType billingType) {
		this.billingType = billingType;
	}

	public List<ClientPurchaseOrderItem> getClientPurchaseOrderItem() {

		return clientPurchaseOrderItem;
	}

	public void setClientPurchaseOrderItem(List<ClientPurchaseOrderItem> clientPurchaseOrderItem) {

		this.clientPurchaseOrderItem = clientPurchaseOrderItem;
	}
	@Override
	public String toString() {
		return "PurchaseOrder [id=" + id + ", advancePaid=" + advancePaid + ", balanceDue=" + balanceDue
				+ ", createdDate=" + createdDate + ", currency=" + currency + ", deliveryDate=" + deliveryDate
				+ ", enabled=" + enabled + ", grandTotal=" + grandTotal + ", instructions=" + instructions
				+ ", otherAmount=" + otherAmount + ", poDate=" + poDate + ", poFileUrl=" + poFileUrl + ", poNumber="
				+ poNumber + ", receivedDate=" + receivedDate + ", subTotal=" + subTotal + ", taxAmount=" + taxAmount
				+ ", termsConditions=" + termsConditions + ", sow=" + sow + ", title=" + title + ", hsnSac=" + hsnSac
				+ ", billingAddress=" + billingAddress + ", shippingAddress=" + shippingAddress + ", client=" + client
				+ ", billingCycle=" + billingCycle + ", billingType=" + billingType + ", clientPurchaseOrderItem="
				+ clientPurchaseOrderItem + "]";
	}

}