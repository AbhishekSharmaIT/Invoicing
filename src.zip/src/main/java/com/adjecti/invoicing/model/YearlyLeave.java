package com.adjecti.invoicing.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_yearlyleave")
public class YearlyLeave {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "peopleId")
	private People people;
	
	@Column(name = "year")
	private int year;

	@Column(name = "clTaken")
	private int clTaken;

	@Column(name = "plTaken")
	private int plTaken;

	@Column(name = "plEncashed")
	private int plEncashed;

	@Column(name = "clBalance")
	private int clBalance;

	@Column(name = "plBalance")
	private int plBalance;
	
	@Column(name = "parentalLeaveTaken")
	private int parentalLeaveTaken;
    
	@Column(name = "enabled")
	private Boolean enabled;
	public YearlyLeave() {
		super();
		// TODO Auto-generated constructor stub
	}
	public YearlyLeave(int id, People people, int year, int clTaken, int plTaken, int plEncashed, int clBalance,
			int plBalance, int parentalLeaveTaken, Boolean enabled) {
		super();
		this.id = id;
		this.people = people;
		this.year = year;
		this.clTaken = clTaken;
		this.plTaken = plTaken;
		this.plEncashed = plEncashed;
		this.clBalance = clBalance;
		this.plBalance = plBalance;
		this.parentalLeaveTaken = parentalLeaveTaken;
		this.enabled = enabled;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public People getPeople() {
		return people;
	}

	public void setPeople(People people) {
		this.people = people;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getClTaken() {
		return clTaken;
	}

	public void setClTaken(int clTaken) {
		this.clTaken = clTaken;
	}

	public int getPlTaken() {
		return plTaken;
	}

	public void setPlTaken(int plTaken) {
		this.plTaken = plTaken;
	}

	public int getPlEncashed() {
		return plEncashed;
	}

	public void setPlEncashed(int plEncashed) {
		this.plEncashed = plEncashed;
	}

	public int getClBalance() {
		return clBalance;
	}

	public void setClBalance(int clBalance) {
		this.clBalance = clBalance;
	}

	public int getPlBalance() {
		return plBalance;
	}

	public void setPlBalance(int plBalance) {
		this.plBalance = plBalance;
	}

	public int getParentalLeaveTaken() {
		return parentalLeaveTaken;
	}

	public void setParentalLeaveTaken(int parentalLeaveTaken) {
		this.parentalLeaveTaken = parentalLeaveTaken;
	}

	public Boolean getEnabled() {
		return enabled;
	}
	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}
	@Override
	public String toString() {
		return "YearlyLeave [id=" + id + ", people=" + people + ", year=" + year + ", clTaken=" + clTaken + ", plTaken="
				+ plTaken + ", plEncashed=" + plEncashed + ", clBalance=" + clBalance + ", plBalance=" + plBalance
				+ ", parentalLeaveTaken=" + parentalLeaveTaken + ", enabled=" + enabled + "]";
	}
	


}
