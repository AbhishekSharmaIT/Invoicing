package com.adjecti.invoicing.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tbl_people")
public class People {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "firstName")
	private String firstName;

	@Column(name = "lastName")
	private String lastName;

	@Column(name = "fatherName")
	private String fatherName;

	@Column(name = "motherName")
	private String motherName;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "dateOfBirth")
	private Date dateOfBirth;

	@Column(name = "lastDesignation")
	private String lastDesignation;

	@Column(name = "phoneNo")
	private String phoneNo;

	@Column(name = "email")
	private String email;

	@Column(name = "extn")
	private String extn;

	@Column(name = "mobileNo")
	private String mobileNo;

	@Column(name = "profileUrl")
	private String profileUrl;

	@Column(name = "messageChannel")
	private String messageChannel;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "countryId")
	private Country country;

	@Column(name = "bloodGroup")
	private String bloodGroup;

	@Column(name = "identityMark")
	private String identityMark;

	@Column(name = "gender")
	private String gender;

	@Column(name = "maritalStatus")
	private String maritalStatus;

	@Column(name = "enabled")
	private Boolean enabled;

	public People() {
		super();
		// TODO Auto-generated constructor stub
	}

	public People(int id, String firstName, String lastName, String fatherName, String motherName, Date dateOfBirth,
			String lastDesignation, String phoneNo, String email, String extn, String mobileNo, String profileUrl,
			String messageChannel, Country country, String bloodGroup, String identityMark, String gender,
			String maritalStatus, Boolean enabled) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.fatherName = fatherName;
		this.motherName = motherName;
		this.dateOfBirth = dateOfBirth;
		this.lastDesignation = lastDesignation;
		this.phoneNo = phoneNo;
		this.email = email;
		this.extn = extn;
		this.mobileNo = mobileNo;
		this.profileUrl = profileUrl;
		this.messageChannel = messageChannel;
		this.country = country;
		this.bloodGroup = bloodGroup;
		this.identityMark = identityMark;
		this.gender = gender;
		this.maritalStatus = maritalStatus;
		this.enabled = enabled;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getLastDesignation() {
		return lastDesignation;
	}

	public void setLastDesignation(String lastDesignation) {
		this.lastDesignation = lastDesignation;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getExtn() {
		return extn;
	}

	public void setExtn(String extn) {
		this.extn = extn;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getProfileUrl() {
		return profileUrl;
	}

	public void setProfileUrl(String profileUrl) {
		this.profileUrl = profileUrl;
	}

	public String getMessageChannel() {
		return messageChannel;
	}

	public void setMessageChannel(String messageChannel) {
		this.messageChannel = messageChannel;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getIdentityMark() {
		return identityMark;
	}

	public void setIdentityMark(String identityMark) {
		this.identityMark = identityMark;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "People [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", fatherName=" + fatherName
				+ ", motherName=" + motherName + ", dateOfBirth=" + dateOfBirth + ", lastDesignation=" + lastDesignation
				+ ", phoneNo=" + phoneNo + ", email=" + email + ", extn=" + extn + ", mobileNo=" + mobileNo
				+ ", profileUrl=" + profileUrl + ", messageChannel=" + messageChannel + ", country=" + country
				+ ", bloodGroup=" + bloodGroup + ", identityMark=" + identityMark + ", gender=" + gender
				+ ", maritalStatus=" + maritalStatus + ", enabled=" + enabled + "]";
	}

}
