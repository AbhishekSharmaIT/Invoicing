package com.adjecti.invoicing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_contact")
public class Contact {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String designation ;
	private String email;
	private String extension;
	
	@Column(name="firstName")
	private String firstName ;
	
	@Column(name="lastName")
	private String lastName;
	
	@Column(name="messageChannel")
	private String messageChannel;
	
	@Column(name="mobileNo")
	private String	mobileNo; 
	
	private String	name ;
	
	@Column(name="phoneNo")
	private String phoneNo ;
	
	@Column(name="profileUrl")
	private String	profileUrl; 
	
	private String title ;
	private String website;
	
	
	public Contact() {
		super();
		
	}

	
	public Contact(int id, String designation, String email, String extension, String firstName, String lastName,
			String messageChannel, String mobileNo, String name, String phoneNo, String profileUrl, String title,
			String website) {
		super();
		this.id = id;
		this.designation = designation;
		this.email = email;
		this.extension = extension;
		this.firstName = firstName;
		this.lastName = lastName;
		this.messageChannel = messageChannel;
		this.mobileNo = mobileNo;
		this.name = name;
		this.phoneNo = phoneNo;
		this.profileUrl = profileUrl;
		this.title = title;
		this.website = website;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMessageChannel() {
		return messageChannel;
	}

	public void setMessageChannel(String messageChannel) {
		this.messageChannel = messageChannel;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getProfileUrl() {
		return profileUrl;
	}

	public void setProfileUrl(String profileUrl) {
		this.profileUrl = profileUrl;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}
	
	
	
	
}
