package com.adjecti.invoicing.model;

import java.time.LocalDate;
import java.util.List;
import com.adjecti.invoicing.model.*;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tbl_client")
public class Client {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String businessName;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate createdDate;

	private byte enabled;
	private int paymentNetDays;
	private Integer taxExemptable;
	private String website;

	private String name;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "addressId")
	private Address address;

	private String primaryBusiness;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "companyTypeId")
	
	private CompanyType companyType;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "primaryContactId")
	private Contact contact;

	
	private String taxDocNo1;
	private String taxDocNo2;

	@ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.MERGE })
	@JoinTable(name = "tbl_client_tax", joinColumns = {
			@JoinColumn(name = "clientId", referencedColumnName = "id") }, inverseJoinColumns = {
					@JoinColumn(name = "taxId", referencedColumnName = "id", unique = false) })
	private List<Tax> tax;
	
	  
	  @OneToMany(mappedBy = "client",fetch = FetchType.LAZY, 
	            cascade = {CascadeType.DETACH, CascadeType.MERGE,
	        CascadeType.PERSIST, CascadeType.REFRESH})
	    private List<PurchaseOrder> purchaseOrders;
	  
	  
	  
	  public List<PurchaseOrder> getPurchaseOrders() {
		return purchaseOrders;
	}

	public void setPurchaseOrders(List<PurchaseOrder> purchaseOrders) {
		this.purchaseOrders = purchaseOrders;
	}

	public Client() {
		super();

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public byte getEnabled() {
		return enabled;
	}

	public void setEnabled(byte enabled) {
		this.enabled = enabled;
	}

	public int getPaymentNetDays() {
		return paymentNetDays;
	}

	public void setPaymentNetDays(int paymentNetDays) {
		this.paymentNetDays = paymentNetDays;
	}

	public Integer getTaxExemptable() {
		return taxExemptable;
	}

	public void setTaxExemptable(Integer taxExemptable) {
		this.taxExemptable = taxExemptable;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getPrimaryBusiness() {
		return primaryBusiness;
	}

	public void setPrimaryBusiness(String primaryBusiness) {
		this.primaryBusiness = primaryBusiness;
	}

	public CompanyType getCompany() {
		return companyType;
	}

	public void setCompany(CompanyType company) {
		this.companyType = company;
	}

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	public String getTaxDocNo1() {
		return taxDocNo1;
	}

	public void setTaxDocNo1(String taxDocNo1) {
		this.taxDocNo1 = taxDocNo1;
	}

	public String getTaxDocNo2() {
		return taxDocNo2;
	}

	public void setTaxDocNo2(String taxDocNo2) {
		this.taxDocNo2 = taxDocNo2;
	}


	public List<Tax> getTax() {
		return tax;
	}


	public void setTax(List<Tax> tax) {
		this.tax = tax;
	}

/*
	@Override
	public String toString() {
		return "Client [id=" + id + ", businessName=" + businessName + ", createdDate=" + createdDate + ", enabled="
				+ enabled + ", paymentNetDays=" + paymentNetDays + ", taxExemptable=" + taxExemptable + ", website="
				+ website + ", name=" + name + ", address=" + address + ", primaryBusiness=" + primaryBusiness
				+ ", company=" + companyType + ", contact=" + contact + ", taxDocNo1=" + taxDocNo1 + ", taxDocNo2="
				+ taxDocNo2 + ", tax=" + tax +  ", purchaseOrders=" + purchaseOrders + "]";
	}
*/
}
