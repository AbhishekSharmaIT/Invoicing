
package com.adjecti.invoicing.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="tbl_address")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;	
	@NotEmpty(message="Please enter address")
	private String address1; 
	private String address2; 
	@NotBlank(message="Please enter city")
	private String city ; 
	@NotBlank(message="Please enter email ")
	@Email(message="enter valid email")
	private String email; 
	private String fax ;
	//@NotBlank(message = " Please enter Mobile no")
	//@Pattern(regexp="(^$|[0-9]{10})" ,message = "Enter valid mobile number")
	private String mobile; 
	@NotBlank(message = "Please enter phone number")
	@Pattern(regexp="(^$|[0-9]{10})" ,message = "Enter valid phone number")
	private String phone;
	
	@NotBlank(message = " Please enter Pincode")
	private String pincode; 
	private String state;
	@NotBlank(message = "Please enter website name")
	private String website;
	
	

	@OneToOne
	@JoinColumn(name="type_id")
	@NotNull(message="Please select address type")
	
	private AddressType addressType;
	
	@NotNull
	@NotBlank(message="Please select country")
	private String country;
	
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}


	public AddressType getAddressType() {
		return addressType;
	}


	public void setAddressType(AddressType addressType) {
		this.addressType = addressType;
	}
	
	public String getWebsite() {
		return website;
	}


	public void setWebsite(String website) {
		this.website = website;
	}
}
