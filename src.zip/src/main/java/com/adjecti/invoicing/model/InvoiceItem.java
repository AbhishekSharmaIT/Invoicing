package com.adjecti.invoicing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author DELL PC
 */
@Entity
@Table(name = "tbl_invoice_item")
public class InvoiceItem {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "amount")
	private double amount;

	@Column(name = "description")
	private String descrition;

	@Column(name = "name")
	private String name;

	@Column(name = "part")
	private double part;

	@Column(name = "qty")
	private int quantity;

	@ManyToOne
	@JoinColumn(name = "poItemId")
	private ClientPurchaseOrderItem clientPurchaseOrderItem;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getDescrition() {
		return descrition;
	}

	public void setDescrition(String descrition) {
		this.descrition = descrition;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPart() {
		return part;
	}

	public void setPart(double part) {
		this.part = part;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public ClientPurchaseOrderItem getClientPurchaseOrderItem() {
		return clientPurchaseOrderItem;
	}

	public void setClientPurchaseOrderItem(ClientPurchaseOrderItem clientPurchaseOrderItem) {
		this.clientPurchaseOrderItem = clientPurchaseOrderItem;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("InvoiceItem [id=").append(id).append(", amount=").append(amount).append(", descrition=")
				.append(descrition).append(", name=").append(name).append(", part=").append(part).append(", quantity=")
				.append(quantity).append(", clientPurchaseOrderItem=").append(clientPurchaseOrderItem).append("]");
		return builder.toString();
	}

	


}
