package com.adjecti.invoicing.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adjecti.invoicing.model.AccountHead;

public interface AccountHeadRepository  extends JpaRepository<AccountHead, Long>{
	
	List<AccountHead>getByType(int type);
}
