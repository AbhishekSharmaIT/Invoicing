package com.adjecti.invoicing.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.adjecti.invoicing.model.PurchaseOrder;

public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Integer> {

	@Transactional
	@Modifying
	@Query(value = "update tbl_purchase_order set enabled=?1 WHERE id = ?2", nativeQuery = true)
	void deletePurchaseOrder(Boolean status,int id);
	
	@Query(value="select * from tbl_purchase_order where enabled=?1",nativeQuery = true)
	public List<PurchaseOrder> getAllPurchaseOrder(Boolean enabled);
}