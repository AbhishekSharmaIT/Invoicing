package com.adjecti.invoicing.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adjecti.invoicing.model.Technology;

public interface TechnologyRepository extends JpaRepository<Technology,Integer>{

}
