package com.adjecti.invoicing.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.adjecti.invoicing.model.DayBook;

public interface DayBookRepository extends JpaRepository<DayBook, Long>{
	@Query("SELECT d FROM DayBook d where d.createdDate = :createdDate") 
	public List<DayBook> findBYTodaysDate(@Param("createdDate") LocalDate createdDate);
	
	
	  @Query("SELECT d FROM DayBook d WHERE d.createdDate BETWEEN :fromDate AND :toDate" ) 
	  public List<DayBook> findByDates(@Param("fromDate") LocalDate fromDate,@Param("toDate") LocalDate toDate);
		
	  @Query(value="select * from tbl_daybook d ORDER BY d.id DESC LIMIT 1 " ,nativeQuery = true)
	  public DayBook getRuningBalance();
	 
}
