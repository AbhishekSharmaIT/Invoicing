package com.adjecti.invoicing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.adjecti.invoicing.model.Country;

public interface CountryRepository extends JpaRepository<Country, Integer>{
	@Query("select c from Country c where c.id=:id")
	public Country getCountryById(@Param("id") Integer id);
	
	

}
