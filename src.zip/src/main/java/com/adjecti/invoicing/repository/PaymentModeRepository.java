package com.adjecti.invoicing.repository;
import org.springframework.data.repository.CrudRepository;

import com.adjecti.invoicing.model.PaymentMode; 

public interface PaymentModeRepository extends CrudRepository<PaymentMode,Long>{

}
