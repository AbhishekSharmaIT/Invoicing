package com.adjecti.invoicing.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.adjecti.invoicing.model.Client;

public interface ClientRepository extends JpaRepository<Client, Integer>{


	
	
	/*
	 * @Query( value="select tbl_client.name,tbl_client.businessName," +
	 * "tbl_address.address1,tbl_contact.mobileNo,tbl_contact.email" +
	 * " from tbl_client inner join tbl_address on tbl_address.id=tbl_client.addressId "
	 * +
	 * "inner join tbl_contact on tbl_contact.id=tbl_client.primaryContactId where tbl_client.enabled=1"
	 * ,nativeQuery = true)
	 */
	 
	
	@Query("select c from Client c where c.enabled=1")
    public List<Client> getAllClient();
	
	@Transactional
	@Modifying
	@Query("update Client c set c.enabled=0  where c.id =:id ")
	public void deleteClient(@Param("id")int id);

}
