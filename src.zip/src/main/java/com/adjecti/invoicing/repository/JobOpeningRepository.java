package com.adjecti.invoicing.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.adjecti.invoicing.model.JobOpening;


public interface JobOpeningRepository extends JpaRepository<JobOpening,Integer> {
	
		@Transactional
		@Modifying
		@Query(value = "update tbl_jobOpening set enabled=?1 WHERE id = ?2", nativeQuery = true)
		public void delete(Boolean status,int id);
		
		@Query(value="select * from tbl_jobOpening where enabled=?1",nativeQuery = true)
		public List<JobOpening> getJobOpening(Boolean enabled);
}

